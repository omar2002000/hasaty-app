// lib/domain/usecases/student/charge_student_usecase.dart
// Business logic: charging a student updates XP and logs a payment.
import '../../entities/student.dart';
import '../../entities/payment.dart';
import '../../repositories/student_repository.dart';
import '../../repositories/finance_repository.dart';

String _today() { final n = DateTime.now(); return '${n.day}/${n.month}/${n.year}'; }

class ChargeStudentUseCase {
  final StudentRepository  _studentRepo;
  final FinanceRepository  _financeRepo;

  ChargeStudentUseCase(this._studentRepo, this._financeRepo);

  Future<Student> execute(Student student, double amount, String note) async {
    Student updated = student.copyWith(balance: student.balance + amount);
    if (updated.balance >= 0) {
      updated = updated.copyWith(xp: updated.xp + 5);
    }
    await _studentRepo.updateStudent(updated);
    await _financeRepo.addPayment(Payment(
      studentId:   student.id!,
      studentName: student.name,
      amount:      amount,
      date:        _today(),
      note:        note,
      type:        'charge',
    ));
    return updated;
  }
}
