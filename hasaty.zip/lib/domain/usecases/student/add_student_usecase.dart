// lib/domain/usecases/student/add_student_usecase.dart
import '../../entities/student.dart';
import '../../repositories/student_repository.dart';

class AddStudentUseCase {
  final StudentRepository _repo;
  AddStudentUseCase(this._repo);

  Future<int> execute(Student student) => _repo.addStudent(student);
}
