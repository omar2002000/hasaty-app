// lib/domain/usecases/student/student_usecases.dart
// Barrel export — كل student usecases في مكان واحد.
export 'get_students_usecase.dart';
export 'get_student_by_id_usecase.dart';
export 'add_student_usecase.dart';
export 'update_student_usecase.dart';
export 'archive_student_usecase.dart';
export 'charge_student_usecase.dart';
export 'analyze_students_usecase.dart';
