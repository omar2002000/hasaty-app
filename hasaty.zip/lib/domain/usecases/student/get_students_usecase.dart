// lib/domain/usecases/student/get_students_usecase.dart
import '../../entities/student.dart';
import '../../repositories/student_repository.dart';

class GetStudentsUseCase {
  final StudentRepository _repo;
  GetStudentsUseCase(this._repo);

  Future<List<Student>> execute({bool includeArchived = false}) =>
      _repo.getStudents(includeArchived: includeArchived);
}
