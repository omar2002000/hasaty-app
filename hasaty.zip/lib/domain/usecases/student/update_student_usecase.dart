// lib/domain/usecases/student/update_student_usecase.dart
import '../../entities/student.dart';
import '../../repositories/student_repository.dart';

class UpdateStudentUseCase {
  final StudentRepository _repo;
  UpdateStudentUseCase(this._repo);

  Future<int> execute(Student student) => _repo.updateStudent(student);
}
