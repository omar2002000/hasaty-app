// lib/domain/usecases/student/analyze_students_usecase.dart
import '../../entities/student.dart';

class AnalyzeStudentsUseCase {
  Map<String, dynamic> execute(List<Student> students) {
    final risky = <Student>[];
    final late  = <Student>[];
    final top   = <Student>[];

    for (final s in students) {
      if (s.balance < -100)              risky.add(s);
      if (s.balance < 0 && s.balance >= -100) late.add(s);
      if (s.xp >= 200)                   top.add(s);
    }

    risky.sort((a, b) => a.balance.compareTo(b.balance));
    late.sort((a, b)  => a.balance.compareTo(b.balance));
    top.sort((a, b)   => b.xp.compareTo(a.xp));

    return {
      'risky': risky,
      'late':  late,
      'top':   top.take(5).toList(),
    };
  }
}
