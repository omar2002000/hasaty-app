// lib/domain/usecases/student/archive_student_usecase.dart
import '../../repositories/student_repository.dart';

class ArchiveStudentUseCase {
  final StudentRepository _repo;
  ArchiveStudentUseCase(this._repo);

  Future<void> archive(int id)  => _repo.archiveStudent(id);
  Future<void> restore(int id)  => _repo.restoreStudent(id);
}
