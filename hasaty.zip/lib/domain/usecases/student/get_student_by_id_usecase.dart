// lib/domain/usecases/student/get_student_by_id_usecase.dart
import '../../entities/student.dart';
import '../../repositories/student_repository.dart';

class GetStudentByIdUseCase {
  final StudentRepository _repo;
  GetStudentByIdUseCase(this._repo);

  Future<Student?> execute(int id) => _repo.getStudentById(id);
}
