// lib/domain/usecases/attendance/mark_attendance_usecase.dart
import '../../repositories/attendance_repository.dart';

class MarkAttendanceByQRUseCase {
  final AttendanceRepository _repo;
  MarkAttendanceByQRUseCase(this._repo);

  Future<Map<String, dynamic>> execute(
          int studentId, String groupName, double price) =>
      _repo.markByQR(studentId, groupName, price);
}
