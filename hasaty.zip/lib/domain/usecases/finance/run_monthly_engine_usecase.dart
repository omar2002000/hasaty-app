// lib/domain/usecases/finance/run_monthly_engine_usecase.dart
import '../../repositories/finance_repository.dart';

class RunMonthlyEngineUseCase {
  final FinanceRepository _repo;
  RunMonthlyEngineUseCase(this._repo);

  Future<Map<String, int>> execute(int month, int year) =>
      _repo.runMonthlyEngine(month, year);
}
