// lib/domain/usecases/finance/get_smart_report_usecase.dart
import '../../repositories/finance_repository.dart';
import '../../repositories/student_repository.dart';
import '../../repositories/attendance_repository.dart';

class GetSmartReportUseCase {
  final StudentRepository    _studentRepo;
  final FinanceRepository    _financeRepo;
  final AttendanceRepository _attendanceRepo;

  GetSmartReportUseCase(
      this._studentRepo, this._financeRepo, this._attendanceRepo);

  Future<Map<String, dynamic>> execute() async {
    final students = await _studentRepo.getStudents();
    final payments = await _financeRepo.getAllPayments();
    final now      = DateTime.now();
    final suffix   = '/${now.month}/${now.year}';

    final monthlyPay = payments.where((p) => p.date.endsWith(suffix)).toList();

    // Build attendance stats
    final stats = <Map<String, dynamic>>[];
    for (final s in students) {
      final pct = await _attendanceRepo.getAttendancePercentage(s.id!);
      stats.add({'student': s, 'percentage': pct});
    }
    stats.sort((a, b) =>
        (b['percentage'] as double).compareTo(a['percentage'] as double));

    final debts = students.where((s) => s.balance < 0).toList();
    final subs  = await _financeRepo.getSubscriptions(
        month: now.month, year: now.year);

    final expected = subs.fold<double>(0.0, (s, x) => s + x.amount);
    final actual   = monthlyPay.fold<double>(0.0, (s, p) => s + p.amount);

    final risks = <Map<String, dynamic>>[];
    for (final e in stats) {
      final s   = e['student'];
      final pct = e['percentage'] as double;
      final r   = s.riskLevel(pct);
      if (r != 'ملتزم') risks.add({'student': s, 'risk': r, 'attendance': pct});
    }

    return {
      'bestAttendance': stats.take(3).toList(),
      'mostAbsent':     stats.reversed.take(3).toList(),
      'monthlyIncome':  actual,
      'expectedIncome': expected,
      'collectionRate': expected > 0 ? actual / expected * 100 : 0.0,
      'debtStudents':   debts,
      'totalDebt':      debts.fold<double>(0.0, (s, st) => s + st.balance.abs()),
      'weekStar':       students.isNotEmpty ? students.first : null,
      'totalStudents':  students.length,
      'monthlyPayCount': monthlyPay.length,
      'riskStudents':   risks,
    };
  }
}
