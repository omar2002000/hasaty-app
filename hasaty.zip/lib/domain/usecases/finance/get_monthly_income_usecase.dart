// lib/domain/usecases/finance/get_monthly_income_usecase.dart
import '../../repositories/finance_repository.dart';

class GetMonthlyIncomeUseCase {
  final FinanceRepository _repo;
  GetMonthlyIncomeUseCase(this._repo);

  Future<double> execute() => _repo.getTotalThisMonth();
}
