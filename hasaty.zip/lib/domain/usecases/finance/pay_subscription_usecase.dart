// lib/domain/usecases/finance/pay_subscription_usecase.dart
import '../../entities/subscription.dart';
import '../../entities/student.dart';
import '../../../data/repositories/finance_repository_impl.dart';

class PaySubscriptionUseCase {
  final FinanceRepositoryImpl _repo;
  PaySubscriptionUseCase(this._repo);

  Future<void> execute(Subscription sub, double amount, Student student) =>
      _repo.paySubscription(sub, amount, student);
}
