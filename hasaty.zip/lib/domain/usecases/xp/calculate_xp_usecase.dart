// lib/domain/usecases/xp/calculate_xp_usecase.dart
import '../../entities/xp_level.dart';

class CalculateXpUseCase {
  Map<String, dynamic> execute(int xp) {
    final level    = getXpLevel(xp);
    final progress = level.progressFor(xp);
    return {
      'level':     level,
      'progress':  progress,
      'levelName': level.nameAr,
      'emoji':     level.emoji,
      'nextXp':    level.maxXp,
    };
  }
}
