// lib/domain/entities/payment.dart
// Stage 3A: added paymentMethod field.
class Payment {
  final int? id;
  final int? studentId;
  final String studentName;
  final double amount;
  final String date;
  final String note;
  /// 'charge' | 'subscription' | 'session'
  final String type;
  /// 'cash' | 'vodafone' | 'instapay' | 'bank'
  final String paymentMethod;

  const Payment({
    this.id,
    required this.studentId,
    required this.studentName,
    required this.amount,
    required this.date,
    this.note          = '',
    this.type          = 'charge',
    this.paymentMethod = 'cash',
  });

  String get typeLabel {
    switch (type) {
      case 'subscription': return 'اشتراك شهري';
      case 'session':      return 'حضور جلسة';
      default:             return 'شحن رصيد';
    }
  }

  String get methodLabel {
    switch (paymentMethod) {
      case 'vodafone': return 'فودافون كاش 📱';
      case 'instapay': return 'إنستاباي 💳';
      case 'bank':     return 'تحويل بنكي 🏦';
      default:         return 'نقدي 💵';
    }
  }
}
