// lib/domain/entities/academic_grade.dart
class AcademicGrade {
  final int? id;
  final int? studentId;
  final String studentName;
  final String groupName;
  final String type; // 'recitation' | 'homework' | 'exam'
  final String grade; // 'excellent' | 'good' | 'acceptable' | 'weak'
  final int score;
  final String note;
  final String date;
  final String sessionTopic;

  const AcademicGrade({
    this.id,
    required this.studentId,
    required this.studentName,
    required this.groupName,
    required this.type,
    required this.grade,
    this.score = 0,
    this.note = '',
    required this.date,
    this.sessionTopic = '',
  });

  String get typeLabel {
    switch (type) {
      case 'recitation': return 'تسميع';
      case 'homework':   return 'واجب';
      case 'exam':       return 'اختبار';
      default:           return type;
    }
  }

  String get gradeLabel {
    switch (grade) {
      case 'excellent':  return 'ممتاز';
      case 'good':       return 'جيد';
      case 'acceptable': return 'مقبول';
      case 'weak':       return 'ضعيف';
      default:           return grade;
    }
  }

  String get gradeEmoji {
    switch (grade) {
      case 'excellent':  return '🌟';
      case 'good':       return '✅';
      case 'acceptable': return '⚠️';
      case 'weak':       return '❌';
      default:           return '📝';
    }
  }

  int get xpReward {
    switch (grade) {
      case 'excellent':  return 15;
      case 'good':       return 10;
      case 'acceptable': return 5;
      default:           return 0;
    }
  }
}
