// lib/domain/entities/group.dart
class Group {
  final int? id;
  final String name;
  final double monthlyPrice;
  final String days;
  final String time;

  const Group({
    this.id,
    required this.name,
    required this.monthlyPrice,
    this.days = '',
    this.time = '',
  });

  Group copyWith({
    int? id,
    String? name,
    double? monthlyPrice,
    String? days,
    String? time,
  }) {
    return Group(
      id: id ?? this.id,
      name: name ?? this.name,
      monthlyPrice: monthlyPrice ?? this.monthlyPrice,
      days: days ?? this.days,
      time: time ?? this.time,
    );
  }
}
