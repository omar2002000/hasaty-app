// lib/domain/entities/student.dart
// ─────────────────────────────────────────────────────────────
// Canonical domain entity — immutable, no DB/Flutter imports.
// All business logic lives HERE.
//
// Stage 1A: added qrToken field.
//   Format: 'HASATY-{id}'  ('' = not yet generated)
//   Generated once after DB insert, stored permanently.
// ─────────────────────────────────────────────────────────────

class Student {
  final int? id;
  final String name;
  final String phone;
  final String parentPhone;
  final String groupName;
  final String joinDate;
  final double balance;
  final int xp;
  final int coins;
  final bool archived;

  /// QR token — unique per student, stored in DB.
  /// Empty means token not yet generated (legacy row).
  final String qrToken;

  const Student({
    this.id,
    required this.name,
    required this.phone,
    this.parentPhone = '',
    required this.groupName,
    required this.joinDate,
    this.balance  = 0.0,
    this.xp       = 0,
    this.coins    = 0,
    this.archived = false,
    this.qrToken  = '',   // safe default — generated after DB insert
  });

  // ─── QR ───────────────────────────────────────────────────────
  bool get hasQrToken => qrToken.isNotEmpty;

  // ─── XP / Level ──────────────────────────────────────────────
  String get levelName {
    if (xp >= 500) return 'نجم';
    if (xp >= 200) return 'متقدم';
    if (xp >= 50)  return 'متوسط';
    return 'مبتدئ';
  }

  String get levelEmoji {
    if (xp >= 500) return '⭐';
    if (xp >= 200) return '🔥';
    if (xp >= 50)  return '📈';
    return '🌱';
  }

  int get nextLevelXp {
    if (xp >= 500) return 500;
    if (xp >= 200) return 500;
    if (xp >= 50)  return 200;
    return 50;
  }

  double get levelProgress => (xp / nextLevelXp).clamp(0.0, 1.0);

  // ─── Risk ─────────────────────────────────────────────────────
  String riskLevel(double attendancePct) {
    if (attendancePct >= 75 && balance >= 0) return 'ملتزم';
    if (attendancePct >= 50 && balance >= -200) return 'متأخر';
    return 'خطر';
  }

  bool get isFinancialRisk => balance < -100;
  bool get isCriticalRisk  => balance <= -200;

  // ─── Helpers ──────────────────────────────────────────────────
  String get displayInitial => name.isNotEmpty ? name[0] : '؟';

  Student copyWith({
    int?    id,
    String? name,
    String? phone,
    String? parentPhone,
    String? groupName,
    String? joinDate,
    double? balance,
    int?    xp,
    int?    coins,
    bool?   archived,
    String? qrToken,
  }) {
    return Student(
      id:          id          ?? this.id,
      name:        name        ?? this.name,
      phone:       phone       ?? this.phone,
      parentPhone: parentPhone ?? this.parentPhone,
      groupName:   groupName   ?? this.groupName,
      joinDate:    joinDate    ?? this.joinDate,
      balance:     balance     ?? this.balance,
      xp:          xp          ?? this.xp,
      coins:       coins       ?? this.coins,
      archived:    archived    ?? this.archived,
      qrToken:     qrToken     ?? this.qrToken,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) || (other is Student && id == other.id);

  @override
  int get hashCode => id.hashCode;
}
