// lib/domain/entities/app_notification.dart
class AppNotification {
  final int? id;
  final int? studentId;
  final String title;
  final String body;
  final String type; // 'debt' | 'absence' | 'excellence'
  final String date;
  final bool isRead;

  const AppNotification({
    this.id,
    this.studentId,
    required this.title,
    required this.body,
    required this.type,
    required this.date,
    this.isRead = false,
  });

  String get typeIcon {
    switch (type) {
      case 'debt':       return '💰';
      case 'absence':    return '📵';
      case 'excellence': return '🏆';
      default:           return '🔔';
    }
  }
}
