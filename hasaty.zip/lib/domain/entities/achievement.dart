// lib/domain/entities/achievement.dart
class Achievement {
  final String id;
  final String title;
  final String emoji;
  final String description;

  const Achievement({
    required this.id,
    required this.title,
    required this.emoji,
    required this.description,
  });
}

class Achievements {
  static const all = [
    Achievement(id: 'xp_50',           title: 'بداية ممتازة',  emoji: '🌱', description: 'وصل إلى 50 XP'),
    Achievement(id: 'xp_200',          title: 'طالب متقدم',    emoji: '🔥', description: 'وصل إلى 200 XP'),
    Achievement(id: 'xp_500',          title: 'نجم الفصل',     emoji: '⭐', description: 'وصل إلى 500 XP'),
    Achievement(id: 'regular_payment', title: 'ملتزم مالياً',  emoji: '💎', description: 'رصيده دائماً إيجابي'),
    Achievement(id: 'attend_10',       title: '10 حصص',        emoji: '🎯', description: '10 حضور متتالي'),
    Achievement(id: 'sub_paid_3',      title: '3 أشهر ملتزم', emoji: '🏆', description: 'دفع 3 اشتراكات متتالية'),
  ];

  static Achievement? getById(String id) {
    try {
      return all.firstWhere((a) => a.id == id);
    } catch (_) {
      return null;
    }
  }
}
