// lib/domain/entities/subscription.dart
class Subscription {
  final int? id;
  final int? studentId;
  final int? groupId;
  final String studentName;
  final String groupName;
  final int month;
  final int year;
  final double amount;
  final String status; // 'unpaid' | 'partial' | 'paid'
  final double paidAmount;
  final String? paidDate;

  const Subscription({
    this.id,
    required this.studentId,
    required this.groupId,
    required this.studentName,
    required this.groupName,
    required this.month,
    required this.year,
    required this.amount,
    this.status = 'unpaid',
    this.paidAmount = 0,
    this.paidDate,
  });

  double get remainingAmount => amount - paidAmount;

  String get statusLabel {
    switch (status) {
      case 'paid':
        return 'مدفوع';
      case 'partial':
        return 'جزئي';
      default:
        return 'غير مدفوع';
    }
  }

  static const List<String> monthNames = [
    '',
    'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
    'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
  ];

  String get monthName =>
      (month >= 1 && month <= 12) ? monthNames[month] : '';

  Subscription copyWith({
    String? status,
    double? paidAmount,
    String? paidDate,
  }) {
    return Subscription(
      id: id,
      studentId: studentId,
      groupId: groupId,
      studentName: studentName,
      groupName: groupName,
      month: month,
      year: year,
      amount: amount,
      status: status ?? this.status,
      paidAmount: paidAmount ?? this.paidAmount,
      paidDate: paidDate ?? this.paidDate,
    );
  }
}
