// lib/domain/entities/xp_level.dart
class XpLevel {
  final String name;
  final String nameAr;
  final String emoji;
  final int minXp;
  final int maxXp;

  const XpLevel({
    required this.name,
    required this.nameAr,
    required this.emoji,
    required this.minXp,
    required this.maxXp,
  });

  double progressFor(int xp) {
    if (maxXp == minXp) return 1.0;
    return ((xp - minXp) / (maxXp - minXp)).clamp(0.0, 1.0);
  }
}

const List<XpLevel> kXpLevels = [
  XpLevel(name: 'Beginner', nameAr: 'مبتدئ',  emoji: '🌱', minXp: 0,    maxXp: 50),
  XpLevel(name: 'Student',  nameAr: 'متوسط',   emoji: '📈', minXp: 50,   maxXp: 200),
  XpLevel(name: 'Pro',      nameAr: 'متقدم',   emoji: '🔥', minXp: 200,  maxXp: 500),
  XpLevel(name: 'Master',   nameAr: 'نجم',     emoji: '⭐', minXp: 500,  maxXp: 1500),
  XpLevel(name: 'Legend',   nameAr: 'أسطورة',  emoji: '🏆', minXp: 1500, maxXp: 999999),
];

XpLevel getXpLevel(int xp) {
  return kXpLevels.lastWhere((l) => xp >= l.minXp, orElse: () => kXpLevels.first);
}
