// lib/domain/entities/audit_log.dart
// Stage 8 — Audit log entry. Immutable domain entity.
class AuditLog {
  final int?   id;
  final String actionType;  // 'add' | 'edit' | 'archive' | 'delete' | 'attendance' | 'payment'
  final int?   studentId;
  final String studentName;
  final String description;
  final String timestamp;   // ISO-like: 'dd/MM/yyyy HH:mm'

  const AuditLog({
    this.id,
    required this.actionType,
    this.studentId,
    this.studentName = '',
    required this.description,
    required this.timestamp,
  });

  String get actionIcon {
    switch (actionType) {
      case 'add':        return '➕';
      case 'edit':       return '✏️';
      case 'archive':    return '📦';
      case 'delete':     return '🗑️';
      case 'attendance': return '✅';
      case 'payment':    return '💰';
      default:           return '🔔';
    }
  }

  String get actionLabel {
    switch (actionType) {
      case 'add':        return 'إضافة';
      case 'edit':       return 'تعديل';
      case 'archive':    return 'أرشفة';
      case 'delete':     return 'حذف';
      case 'attendance': return 'حضور';
      case 'payment':    return 'دفعة';
      default:           return 'عملية';
    }
  }
}
