// lib/domain/entities/attendance_record.dart
class AttendanceRecord {
  final int? id;
  final int? studentId;
  final String studentName;
  final String groupName;
  final String date;
  final bool present;

  const AttendanceRecord({
    this.id,
    required this.studentId,
    required this.studentName,
    required this.groupName,
    required this.date,
    required this.present,
  });
}
