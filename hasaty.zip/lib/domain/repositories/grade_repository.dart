// lib/domain/repositories/grade_repository.dart
import '../entities/academic_grade.dart';

abstract class GradeRepository {
  Future<int> addGrade(AcademicGrade grade);
  Future<List<AcademicGrade>> getAllGrades();
  Future<List<AcademicGrade>> getStudentGrades(int studentId);
  Future<Map<String, dynamic>> getGradeSummary(int studentId);
}
