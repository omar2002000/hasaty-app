// lib/domain/repositories/achievement_repository.dart
abstract class AchievementRepository {
  Future<List<String>> getStudentAchievements(int studentId);
  Future<void> checkAndGrantAchievements(int studentId);
}
