// lib/domain/repositories/student_repository.dart
import '../entities/student.dart';

abstract class StudentRepository {
  Future<List<Student>> getStudents({bool includeArchived = false});
  Future<Student?> getStudentById(int id);
  Future<int> addStudent(Student student);
  Future<int> updateStudent(Student student);
  Future<void> archiveStudent(int id);
  Future<void> restoreStudent(int id);
  Future<List<Student>> getStudentsWithDebt();
  Future<List<Student>> getArchivedStudents();
  /// Stage 2B: permanent deletion including all related records.
  Future<void> hardDeleteStudent(int id);
}
