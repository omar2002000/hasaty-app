// lib/domain/repositories/other_repositories.dart
// Barrel export — لا تعريفات هنا، فقط re-exports للتوافق مع أي import قديم.
export 'group_repository.dart';
export 'grade_repository.dart';
export 'notification_repository.dart';
export 'achievement_repository.dart';
export 'coin_repository.dart';
