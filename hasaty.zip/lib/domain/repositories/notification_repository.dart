// lib/domain/repositories/notification_repository.dart
import '../entities/app_notification.dart';

abstract class NotificationRepository {
  Future<void> addNotification(AppNotification notification);
  Future<List<AppNotification>> getAllNotifications();
  Future<int> getUnreadCount();
  Future<void> markAllRead();
  Future<void> generateSmartNotifications();
}
