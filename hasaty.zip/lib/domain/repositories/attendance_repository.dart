// lib/domain/repositories/attendance_repository.dart
import '../entities/attendance_record.dart';

abstract class AttendanceRepository {
  Future<void> addRecord(AttendanceRecord record);
  Future<List<AttendanceRecord>> getByStudent(int studentId);
  Future<double> getAttendancePercentage(int studentId);

  /// Stage 1C: mark attendance via QR scan.
  /// Returns: {success, message, student?}
  Future<Map<String, dynamic>> markByQR(
      int studentId, String groupName, double price);
}
