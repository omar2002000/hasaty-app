// lib/domain/repositories/group_repository.dart
import '../entities/group.dart';

abstract class GroupRepository {
  Future<List<Group>> getAll();
  Future<int> addGroup(Group group);
  Future<void> updateGroup(Group group);
  Future<int> deleteGroup(int id);
}
