// lib/domain/repositories/coin_repository.dart
abstract class CoinRepository {
  Future<void> awardCoins(int studentId, String name, int amount, String reason);
  Future<void> spendCoins(int studentId, String name, int amount, String reason);
  Future<int> getStudentCoins(int studentId);
}
