// lib/domain/repositories/finance_repository.dart
import '../entities/subscription.dart';
import '../entities/payment.dart';

abstract class FinanceRepository {
  Future<int> addPayment(Payment payment);
  Future<List<Payment>> getAllPayments();
  Future<List<Payment>> getStudentPayments(int studentId);
  Future<double> getTotalThisMonth();

  Future<int> addSubscription(Subscription subscription);
  Future<List<Subscription>> getSubscriptions({int? month, int? year, int? studentId});
  Future<bool> subscriptionExists(int studentId, int groupId, int month, int year);
  Future<void> updateSubscription(Subscription subscription);

  Future<Map<String, int>> runMonthlyEngine(int month, int year);
}
