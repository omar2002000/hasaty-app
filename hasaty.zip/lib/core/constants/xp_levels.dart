// lib/core/constants/xp_levels.dart
// ─────────────────────────────────────────────────
// Compatibility shim — re-exports from domain entity.
// يُبقي على الـ imports القديمة تعمل بدون كسر.
// ─────────────────────────────────────────────────
export '../../domain/entities/xp_level.dart';
