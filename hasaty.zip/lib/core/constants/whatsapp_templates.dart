// lib/core/constants/whatsapp_templates.dart
class WhatsAppTemplates {
  static String absence(String name, String group) =>
      'أهلاً ولي أمر $name،\n'
      'لم يحضر نجلكم *$name* حصة اليوم بمجموعة $group.\n'
      'يُرجى التواصل معنا.\n'
      'معلمكم: مستر نصر علي 📚';

  static String debt(String name, String amount) =>
      'أهلاً ولي أمر $name،\n'
      'المبلغ المستحق على نجلكم *$name* هو *$amount ج.م*.\n'
      'يُرجى السداد.\n'
      'شكراً 🙏\n'
      'معلمكم: مستر نصر علي';

  static String gradeResult(String name, String grade, String type) =>
      '${grade == "ممتاز" || grade == "جيد" ? "🌟 مبروك!" : "⚠️ تنبيه:"}\n'
      'حصل *$name* على تقدير *$grade* في $type اليوم.\n'
      'معلمكم: مستر نصر علي';

  static String monthlyReport(
          String name, String month, String attendance, String balance, String xp) =>
      '📊 تقرير شهر $month:\n'
      'ملخص أداء *$name*:\n'
      '✅ الحضور: $attendance%\n'
      '💰 الرصيد: $balance ج.م\n'
      '⭐ النقاط: $xp XP\n'
      'معلمكم: مستر نصر علي';

  static String excellence(String name, String level) =>
      '🏆 تهنئة!\n'
      'وصل *$name* إلى مستوى *$level*!\n'
      'استمر يا نجم ⭐\n'
      'معلمكم: مستر نصر علي';
}
