// lib/core/security/auth_service.dart
// ─────────────────────────────────────────────────────────────
// Stage 7 — App lock service.
//
// PIN storage:
//   PIN is hashed (XOR + simple checksum) and stored in
//   SharedPreferences under key 'hasaty_pin_hash'.
//   Not cryptographically strong — suitable for a teacher's
//   attendance app where threat model is casual access only.
//
// Biometric:
//   Uses local_auth package. Falls back to PIN if unavailable.
//
// Lock state:
//   'hasaty_lock_enabled'  → bool
//   'hasaty_lock_type'     → 'pin' | 'biometric'
// ─────────────────────────────────────────────────────────────

import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AuthService {
  static final AuthService instance = AuthService._();
  AuthService._();

  static const _kEnabled  = 'hasaty_lock_enabled';
  static const _kPinHash  = 'hasaty_pin_hash';
  static const _kLockType = 'hasaty_lock_type';

  final _auth = LocalAuthentication();

  // ── Lock state ──────────────────────────────────────────────

  Future<bool> get isLockEnabled async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_kEnabled) ?? false;
  }

  Future<String> get lockType async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_kLockType) ?? 'pin';
  }

  Future<bool> get hasPinSet async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.containsKey(_kPinHash);
  }

  // ── PIN management ──────────────────────────────────────────

  /// Saves PIN hash to SharedPreferences. Enables lock.
  Future<void> setPin(String pin) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt(_kPinHash, _hashPin(pin));
    await prefs.setBool(_kEnabled, true);
    await prefs.setString(_kLockType, 'pin');
  }

  /// Verifies PIN against stored hash.
  Future<bool> verifyPin(String pin) async {
    final prefs = await SharedPreferences.getInstance();
    final stored = prefs.getInt(_kPinHash);
    if (stored == null) return false;
    return _hashPin(pin) == stored;
  }

  /// Disables lock and removes stored PIN.
  Future<void> disableLock() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kEnabled, false);
    await prefs.remove(_kPinHash);
    await prefs.remove(_kLockType);
  }

  // ── Biometric ───────────────────────────────────────────────

  Future<bool> get isBiometricAvailable async {
    try {
      final canCheck = await _auth.canCheckBiometrics;
      final isAvail  = await _auth.isDeviceSupported();
      return canCheck && isAvail;
    } on PlatformException {
      return false;
    }
  }

  Future<List<BiometricType>> get availableBiometrics async {
    try {
      return await _auth.getAvailableBiometrics();
    } on PlatformException {
      return [];
    }
  }

  /// Triggers system biometric prompt.
  /// Returns true on success, false on failure / cancel.
  Future<bool> authenticateWithBiometric() async {
    try {
      return await _auth.authenticate(
        localizedReason: 'افتح تطبيق حصتي',
        options: const AuthenticationOptions(
          biometricOnly:  false, // allow device PIN fallback
          stickyAuth:     true,
          useErrorDialogs: true,
        ),
      );
    } on PlatformException {
      return false;
    }
  }

  /// Enable biometric lock (requires biometric to be available first).
  Future<void> enableBiometricLock() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kEnabled, true);
    await prefs.setString(_kLockType, 'biometric');
  }

  // ── Simple PIN hash (not cryptographic — casual security only) ─

  static int _hashPin(String pin) {
    // XOR-based hash with position multiplier
    int h = 0x1234ABCD;
    for (int i = 0; i < pin.length; i++) {
      h = ((h << 5) ^ (h >> 3) ^ pin.codeUnitAt(i) * (i + 7)) & 0x7FFFFFFF;
    }
    return h;
  }
}
