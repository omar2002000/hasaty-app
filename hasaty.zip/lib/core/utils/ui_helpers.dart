// lib/core/utils/ui_helpers.dart
import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

class AppUI {
  static void showToast(BuildContext context, String message,
      {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(children: [
          Icon(isError ? Icons.error_outline : Icons.check_circle_outline,
              color: Colors.white),
          const SizedBox(width: 10),
          Expanded(child: Text(message, style: const TextStyle(color: Colors.white))),
        ]),
        backgroundColor: isError ? AppColors.danger : AppColors.success,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        margin: const EdgeInsets.all(10),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  static Widget fadeSlide({
    required Widget child,
    required int index,
    int baseMs = 300,
  }) {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: Duration(milliseconds: baseMs + index * 80),
      curve: Curves.easeOut,
      builder: (_, v, w) => Opacity(
        opacity: v,
        child: Transform.translate(offset: Offset(0, 30 * (1 - v)), child: w),
      ),
      child: child,
    );
  }

  static String formatCurrency(double amount) =>
      '${amount.toStringAsFixed(0)} ج.م';

  static String today() {
    final n = DateTime.now();
    return '${n.day}/${n.month}/${n.year}';
  }
}
