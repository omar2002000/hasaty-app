// lib/core/cache/attendance_cache.dart
// ─────────────────────────────────────────────────────────────
// Stage 6C — In-memory attendance percentage cache.
//
// Problem solved:
//   dashboardProvider was calling getByStudent(id) for EVERY student
//   on every widget rebuild → N DB queries where N = student count.
//
// Solution:
//   Single cache map with TTL (5 min). Entries are populated lazily
//   via getOrFetch(). Invalidated on new attendance record (markByQR /
//   addRecord). Thread-safe for Dart's single-threaded model.
//
// Usage:
//   final pct = await AttendanceCache.instance.getOrFetch(
//     studentId: s.id!,
//     fetch: () => repo.getAttendancePercentage(s.id!),
//   );
// ─────────────────────────────────────────────────────────────

class _CacheEntry {
  final double value;
  final DateTime cachedAt;
  _CacheEntry(this.value) : cachedAt = DateTime.now();

  bool get isExpired =>
      DateTime.now().difference(cachedAt).inMinutes >= 5;
}

class AttendanceCache {
  static final AttendanceCache instance = AttendanceCache._();
  AttendanceCache._();

  final Map<int, _CacheEntry> _cache = {};

  /// Returns cached percentage or calls [fetch] to populate.
  Future<double> getOrFetch({
    required int studentId,
    required Future<double> Function() fetch,
  }) async {
    final entry = _cache[studentId];
    if (entry != null && !entry.isExpired) return entry.value;

    final value = await fetch();
    _cache[studentId] = _CacheEntry(value);
    return value;
  }

  /// Invalidates a single student's cache entry.
  /// Call after marking attendance for that student.
  void invalidate(int studentId) => _cache.remove(studentId);

  /// Invalidates all entries (e.g. after bulk operations).
  void invalidateAll() => _cache.clear();

  /// Returns null if not cached, avoiding a fetch.
  double? peek(int studentId) {
    final entry = _cache[studentId];
    return (entry != null && !entry.isExpired) ? entry.value : null;
  }
}
