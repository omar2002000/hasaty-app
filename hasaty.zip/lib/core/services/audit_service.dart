// lib/core/services/audit_service.dart
// ─────────────────────────────────────────────────────────────
// Stage 8 — logAction() convenience helper.
//
// Usage from any AsyncNotifier or ConsumerWidget:
//
//   await AuditService.log(
//     ref,
//     actionType:  'add',
//     studentId:   student.id,
//     studentName: student.name,
//     description: 'تم إضافة الطالب ${student.name}',
//   );
//
// The helper formats the timestamp, builds the AuditLog entity,
// and delegates to the auditLogRepositoryProvider.
// ─────────────────────────────────────────────────────────────

import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/entities/audit_log.dart';
import '../../providers/global_providers.dart';

class AuditService {
  AuditService._(); // static-only class

  static Future<void> log(
    Ref ref, {
    required String actionType,
    int?    studentId,
    String  studentName = '',
    required String description,
  }) async {
    try {
      final entry = AuditLog(
        actionType:  actionType,
        studentId:   studentId,
        studentName: studentName,
        description: description,
        timestamp:   _now(),
      );
      await ref.read(auditLogRepositoryProvider).log(entry);
    } catch (_) {
      // Audit logging must NEVER crash the main operation.
      // Silently swallow errors.
    }
  }

  static String _now() {
    final n = DateTime.now();
    final pad = (int v) => v.toString().padLeft(2, '0');
    return '${pad(n.day)}/${pad(n.month)}/${n.year} ${pad(n.hour)}:${pad(n.minute)}';
  }
}
