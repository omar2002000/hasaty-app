// lib/core/navigation/app_routes.dart
// ─────────────────────────────────────────────────
// مركز التنقل — كل مسارات التطبيق في مكان واحد.
// البرمبت يطلب core/navigation/ صريحاً.
// ─────────────────────────────────────────────────
import 'package:flutter/material.dart';
import '../../domain/entities/student.dart';
import '../../domain/entities/group.dart';
import '../../features/dashboard/dashboard_screen.dart';
import '../../features/students/screens/students_screen.dart';
import '../../features/students/student_profile_screen.dart';
import '../../features/finance/subscription_screen.dart';
import '../../features/reports/reports_screen.dart';
import '../../features/settings/settings_screen.dart';
import '../../features/settings/notifications_screen.dart';
import '../../features/settings/archive_screen.dart';
import '../../features/settings/nasr_coins_screen.dart';
import '../../features/settings/whatsapp_automation_screen.dart';
import '../../features/sessions/groups_screen.dart';
import '../../features/sessions/session_screen.dart';
import '../../features/sessions/session_picker_screen.dart';
import '../../features/sessions/academic_screen.dart';
import '../../features/sessions/qr_scanner_screen.dart';
import '../../features/xp/xp_screen.dart';
import '../../features/navigation/main_navigation.dart';

class AppRoutes {
  // ── Named routes ─────────────────────────────────
  static const String home         = '/';
  static const String students     = '/students';
  static const String profile      = '/profile';
  static const String finance      = '/finance';
  static const String reports      = '/reports';
  static const String settings     = '/settings';
  static const String notifications= '/notifications';
  static const String archive      = '/archive';
  static const String coins        = '/coins';
  static const String whatsapp     = '/whatsapp';
  static const String groups       = '/groups';
  static const String sessionPicker= '/session-picker';
  static const String academic     = '/academic';
  static const String xp           = '/xp';

  // ── Route generator ───────────────────────────────
  static Route<dynamic> onGenerateRoute(RouteSettings settings) {
    switch (settings.name) {
      case home:
        return _fade(const MainNavigation());

      case students:
        return _fade(const StudentsScreen());

      case profile:
        final student = settings.arguments as Student;
        return _slide(StudentProfileScreen(student: student));

      case finance:
        return _fade(const SubscriptionScreen());

      case reports:
        return _fade(const ReportsScreen());

      case AppRoutes.settings:
        return _fade(const SettingsScreen());

      case notifications:
        return _slide(const NotificationsScreen());

      case archive:
        return _slide(const ArchiveScreen());

      case coins:
        return _slide(const NasrCoinsScreen());

      case whatsapp:
        return _slide(const WhatsAppAutomationScreen());

      case groups:
        return _slide(const GroupsScreen());

      case sessionPicker:
        return _slide(const SessionPickerScreen());

      case academic:
        return _slide(const AcademicScreen());

      case xp:
        final student = settings.arguments as Student;
        return _slide(XpScreen(student: student));

      default:
        return _fade(const MainNavigation());
    }
  }

  // ── Transitions ───────────────────────────────────
  static PageRoute _fade(Widget page) => PageRouteBuilder(
        pageBuilder: (_, __, ___) => page,
        transitionsBuilder: (_, anim, __, child) =>
            FadeTransition(opacity: anim, child: child),
        transitionDuration: const Duration(milliseconds: 250),
      );

  static PageRoute _slide(Widget page) => PageRouteBuilder(
        pageBuilder: (_, __, ___) => page,
        transitionsBuilder: (_, anim, __, child) => SlideTransition(
          position: Tween<Offset>(
            begin: const Offset(1.0, 0.0),
            end: Offset.zero,
          ).animate(CurvedAnimation(parent: anim, curve: Curves.easeOut)),
          child: child,
        ),
        transitionDuration: const Duration(milliseconds: 280),
      );

  // ── Navigation helpers ────────────────────────────
  static void toProfile(BuildContext context, Student student) {
    Navigator.pushNamed(context, profile, arguments: student);
  }

  static void toXp(BuildContext context, Student student) {
    Navigator.pushNamed(context, xp, arguments: student);
  }

  static void toSession(BuildContext context, Group group) {
    Navigator.push(
      context,
      _slide(SessionScreen(group: group)),
    );
  }

  static void toQRScanner(BuildContext context, {
    required String groupName,
    required double sessionPrice,
  }) {
    Navigator.push(
      context,
      _slide(QRScannerScreen(groupName: groupName, sessionPrice: sessionPrice)),
    );
  }
}
