// lib/core/providers/usecase_providers.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/global_providers.dart';

import '../../domain/usecases/student/get_students_usecase.dart';
import '../../domain/usecases/student/get_student_by_id_usecase.dart';
import '../../domain/usecases/student/add_student_usecase.dart';
import '../../domain/usecases/student/update_student_usecase.dart';
import '../../domain/usecases/student/archive_student_usecase.dart';
import '../../domain/usecases/student/charge_student_usecase.dart';
import '../../domain/usecases/student/analyze_students_usecase.dart';
import '../../domain/usecases/finance/pay_subscription_usecase.dart';
import '../../domain/usecases/finance/get_monthly_income_usecase.dart';
import '../../domain/usecases/finance/run_monthly_engine_usecase.dart';
import '../../domain/usecases/finance/get_smart_report_usecase.dart';
import '../../domain/usecases/attendance/mark_attendance_usecase.dart';
import '../../domain/usecases/xp/calculate_xp_usecase.dart';

// ── Student ──────────────────────────────────────────────────
final getStudentsUseCaseProvider = Provider(
    (ref) => GetStudentsUseCase(ref.read(studentRepositoryProvider)));

final getStudentByIdUseCaseProvider = Provider(
    (ref) => GetStudentByIdUseCase(ref.read(studentRepositoryProvider)));

final addStudentUseCaseProvider = Provider(
    (ref) => AddStudentUseCase(ref.read(studentRepositoryProvider)));

final updateStudentUseCaseProvider = Provider(
    (ref) => UpdateStudentUseCase(ref.read(studentRepositoryProvider)));

final archiveStudentUseCaseProvider = Provider(
    (ref) => ArchiveStudentUseCase(ref.read(studentRepositoryProvider)));

final chargeStudentUseCaseProvider = Provider((ref) => ChargeStudentUseCase(
    ref.read(studentRepositoryProvider),
    ref.read(financeRepositoryProvider)));

final analyzeStudentsUseCaseProvider = Provider((_) => AnalyzeStudentsUseCase());

// ── Finance ──────────────────────────────────────────────────
final paySubscriptionUseCaseProvider = Provider(
    (ref) => PaySubscriptionUseCase(ref.read(financeRepoImplProvider)));

final getMonthlyIncomeUseCaseProvider = Provider(
    (ref) => GetMonthlyIncomeUseCase(ref.read(financeRepositoryProvider)));

final runMonthlyEngineUseCaseProvider = Provider(
    (ref) => RunMonthlyEngineUseCase(ref.read(financeRepositoryProvider)));

final getSmartReportUseCaseProvider = Provider((ref) => GetSmartReportUseCase(
    ref.read(studentRepositoryProvider),
    ref.read(financeRepositoryProvider),
    ref.read(attendanceRepositoryProvider)));

// ── Attendance ───────────────────────────────────────────────
final markAttendanceUseCaseProvider = Provider(
    (ref) => MarkAttendanceByQRUseCase(ref.read(attendanceRepositoryProvider)));

// ── XP ───────────────────────────────────────────────────────
final calculateXpUseCaseProvider = Provider((_) => CalculateXpUseCase());
