// lib/core/providers/analytics_provider.dart
// Stage 9: upgraded to use AnalyticsService for all 6 functions.
// Original analyticsProvider retained for backward compatibility.
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/global_providers.dart';
import '../../features/analytics/analytics_service.dart';

// ── Shared AnalyticsService instance ─────────────────────────
// One instance per ProviderScope — holds the in-memory cache.
final analyticsServiceProvider = Provider<AnalyticsService>((ref) =>
    AnalyticsService(
      ref.read(studentRepositoryProvider),
      ref.read(attendanceRepositoryProvider),
      ref.read(financeRepositoryProvider),
    ));

// ── Stage 9 providers ────────────────────────────────────────

/// Last 14 days: present count per day.
final dailyAttendanceProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) {
  ref.keepAlive();
  return ref.read(analyticsServiceProvider).getDailyAttendance();
});

/// Last 6 months: revenue per month.
final monthlyRevenueProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) {
  ref.keepAlive();
  return ref.read(analyticsServiceProvider).getMonthlyRevenue();
});

/// Per-student attendance rates, sorted by % descending.
final studentAttendanceRateProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) {
  ref.keepAlive();
  return ref.read(analyticsServiceProvider).getStudentAttendanceRate();
});

/// Top-N most absent students.
final mostAbsentStudentsProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) {
  ref.keepAlive();
  return ref.read(analyticsServiceProvider).getMostAbsentStudents();
});

/// Group comparison: avg attendance % per group.
final groupComparisonProvider =
    FutureProvider<List<Map<String, dynamic>>>((ref) {
  ref.keepAlive();
  return ref.read(analyticsServiceProvider).getGroupComparison();
});

/// Student category distribution: Regular / Irregular / Inactive.
final studentCategoryProvider =
    FutureProvider<Map<String, int>>((ref) {
  ref.keepAlive();
  return ref.read(analyticsServiceProvider).getStudentsByCategory();
});

// ── Backward-compatible basic provider (unchanged) ───────────
final analyticsProvider = FutureProvider<Map<String, dynamic>>((ref) async {
  final students = await ref.read(studentRepositoryProvider).getStudents();
  final payments = await ref.read(financeRepositoryProvider).getAllPayments();
  final now      = DateTime.now();
  final suffix   = '/\${now.month}/\${now.year}';

  final monthlyIncome = payments
      .where((p) => p.date.endsWith(suffix))
      .fold<double>(0.0, (s, p) => s + p.amount);

  return {
    'totalStudents': students.length,
    'monthlyIncome': monthlyIncome,
    'debtStudents':  students.where((s) => s.balance < 0).length,
    'totalBalance':  students.fold<double>(0.0, (s, st) => s + st.balance),
    'topXp':         students.isNotEmpty ? students.first.xp : 0,
    'activeGroups':  students.map((s) => s.groupName).toSet().length,
  };
});
