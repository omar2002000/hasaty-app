// lib/core/widgets/custom_button.dart
import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

enum ButtonVariant { primary, outlined, ghost, danger }

class CustomButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  final ButtonVariant variant;
  final bool loading;
  final bool fullWidth;
  final Color? color;

  const CustomButton({
    super.key,
    required this.label,
    this.icon,
    this.onTap,
    this.variant = ButtonVariant.primary,
    this.loading = false,
    this.fullWidth = false,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final c   = color ?? AppColors.primary;
    final bg  = variant == ButtonVariant.primary
        ? c
        : variant == ButtonVariant.danger
            ? AppColors.danger
            : Colors.transparent;
    final fg     = (variant == ButtonVariant.primary ||
            variant == ButtonVariant.danger)
        ? Colors.white
        : c;
    final border = variant == ButtonVariant.outlined
        ? BorderSide(color: c)
        : BorderSide.none;

    return SizedBox(
      width: fullWidth ? double.infinity : null,
      child: ElevatedButton(
        onPressed: loading ? null : onTap,
        style: ElevatedButton.styleFrom(
          backgroundColor: bg,
          foregroundColor: fg,
          elevation: 0,
          side: border,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 18),
        ),
        child: loading
            ? SizedBox(
                width: 18, height: 18,
                child: CircularProgressIndicator(strokeWidth: 2, color: fg))
            : Row(mainAxisSize: MainAxisSize.min, children: [
                if (icon != null) ...[
                  Icon(icon, size: 16),
                  const SizedBox(width: 6),
                ],
                Text(label,
                    style: TextStyle(
                        fontWeight: FontWeight.bold, color: fg)),
              ]),
      ),
    );
  }
}
