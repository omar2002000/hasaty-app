// lib/core/widgets/xp_progress_bar.dart
import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

class XpProgressBar extends StatelessWidget {
  final double progress; // 0.0 → 1.0
  final int currentXp;
  final int nextXp;

  const XpProgressBar({
    super.key,
    required this.progress,
    required this.currentXp,
    required this.nextXp,
  });

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text('XP: $currentXp',
              style: const TextStyle(
                  fontSize: 11, color: AppColors.textSecondary)),
          Text('$nextXp XP',
              style: const TextStyle(
                  fontSize: 11, color: AppColors.textSecondary)),
        ],
      ),
      const SizedBox(height: 4),
      ClipRRect(
        borderRadius: BorderRadius.circular(6),
        child: LinearProgressIndicator(
          value: progress,
          backgroundColor: AppColors.borderLight,
          color: AppColors.warning,
          minHeight: 8,
        ),
      ),
    ]);
  }
}
