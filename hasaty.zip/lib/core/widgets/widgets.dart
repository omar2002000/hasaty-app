// lib/core/widgets/widgets.dart
// Barrel export — import this single file to get all shared widgets.
export 'stat_card.dart';
export 'custom_app_bar.dart';
export 'custom_button.dart';
export 'xp_progress_bar.dart';
export 'shimmer_loading.dart';
export 'empty_state.dart';
