// lib/core/theme/app_colors.dart
import 'package:flutter/material.dart';

class AppColors {
  static const Color primary      = Color(0xFF1E3A8A);
  static const Color primaryLight = Color(0xFF3B5BDB);
  static const Color primaryDark  = Color(0xFF1E293B);
  static const Color success      = Color(0xFF10B981);
  static const Color warning      = Color(0xFFF59E0B);
  static const Color danger       = Color(0xFFEF4444);
  static const Color accent       = Color(0xFF06B6D4);
  static const Color purple       = Color(0xFF8B5CF6);
  static const Color bgLight      = Color(0xFFF8FAFC);
  static const Color bgCard       = Color(0xFFFFFFFF);
  static const Color bgDark       = Color(0xFF0F172A);
  static const Color bgCardDark   = Color(0xFF1E293B);
  static const Color textPrimary  = Color(0xFF0F172A);
  static const Color textSecondary= Color(0xFF64748B);
  static const Color textHint     = Color(0xFFCBD5E1);
  static const Color borderLight  = Color(0xFFE2E8F0);
  static const Color borderDark   = Color(0xFF334155);
}
