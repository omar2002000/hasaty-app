// lib/features/analytics/analytics_screen.dart
// ─────────────────────────────────────────────────────────────
// Stage 9 — Analytics screen: 5 charts in 3 tabs.
//   Tab 0: الحضور   → DailyAttendanceChart + MostAbsentChart
//   Tab 1: الإيراد   → MonthlyRevenueChart
//   Tab 2: الطلاب   → StudentCategoryChart + GroupComparisonChart
//
// Uses 6 typed Riverpod providers from analytics_provider.dart.
// Each tab fetches independently — no waterfall loading.
// ─────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/ui_helpers.dart';
import '../../core/providers/analytics_provider.dart';
import 'widgets/daily_attendance_chart.dart';
import 'widgets/monthly_revenue_chart.dart';
import 'widgets/student_category_chart.dart';
import 'widgets/most_absent_chart.dart';
import 'widgets/group_comparison_chart.dart';

class AnalyticsScreen extends ConsumerStatefulWidget {
  const AnalyticsScreen({super.key});

  @override
  ConsumerState<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends ConsumerState<AnalyticsScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  void _refresh() {
    // Invalidate all analytics providers — AnalyticsService clears its cache
    ref.read(analyticsServiceProvider).clearCache();
    ref.invalidate(dailyAttendanceProvider);
    ref.invalidate(monthlyRevenueProvider);
    ref.invalidate(studentAttendanceRateProvider);
    ref.invalidate(mostAbsentStudentsProvider);
    ref.invalidate(groupComparisonProvider);
    ref.invalidate(studentCategoryProvider);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('التحليلات'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            tooltip: 'تحديث البيانات',
            onPressed: _refresh,
          ),
        ],
        bottom: TabBar(
          controller: _tab,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          indicatorColor: Colors.white,
          tabs: const [
            Tab(icon: Icon(Icons.how_to_reg_rounded, size: 18),
                text: 'الحضور'),
            Tab(icon: Icon(Icons.payments_rounded, size: 18),
                text: 'الإيراد'),
            Tab(icon: Icon(Icons.people_rounded, size: 18),
                text: 'الطلاب'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          // ── Tab 0: Attendance ──────────────────────────────
          _AttendanceTab(),
          // ── Tab 1: Revenue ────────────────────────────────
          _RevenueTab(),
          // ── Tab 2: Students ───────────────────────────────
          _StudentsTab(),
        ],
      ),
    );
  }
}

// ── Tab 0: Attendance ─────────────────────────────────────────

class _AttendanceTab extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final daily     = ref.watch(dailyAttendanceProvider);
    final mostAbs   = ref.watch(mostAbsentStudentsProvider);

    return RefreshIndicator(
      color: AppColors.primary,
      onRefresh: () => Future.wait([
        ref.refresh(dailyAttendanceProvider.future),
        ref.refresh(mostAbsentStudentsProvider.future),
      ]),
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [

          // ── Summary strip ─────────────────────────────────
          daily.when(
            loading: () => _loadingCard('جارٍ تحليل الحضور...'),
            error:   (e, _) => _errorCard('$e'),
            data: (data) {
              final today = data.isNotEmpty ? data.last : null;
              final todayPresent = today?['presentCount'] ?? 0;
              final avgPresent   = data.isEmpty ? 0.0
                  : data.fold<int>(0, (s, d) => s + (d['presentCount'] as int))
                      / data.length;
              return AppUI.fadeSlide(index: 0, child: Row(children: [
                _SummaryTile('اليوم', '$todayPresent', AppColors.success),
                const SizedBox(width: 10),
                _SummaryTile('متوسط 14 يوم',
                    avgPresent.toStringAsFixed(1), AppColors.primary),
              ]));
            },
          ),
          const SizedBox(height: 16),

          // ── Daily bar chart ───────────────────────────────
          daily.when(
            loading: () => _loadingCard(''),
            error:   (e, _) => _errorCard('$e'),
            data: (data) => AppUI.fadeSlide(index: 1,
                child: DailyAttendanceChart(data: data)),
          ),
          const SizedBox(height: 16),

          // ── Most absent chart ─────────────────────────────
          mostAbs.when(
            loading: () => _loadingCard(''),
            error:   (e, _) => _errorCard('$e'),
            data: (data) => data.isEmpty
                ? const SizedBox.shrink()
                : AppUI.fadeSlide(index: 2,
                    child: MostAbsentChart(data: data)),
          ),
        ],
      ),
    );
  }
}

// ── Tab 1: Revenue ────────────────────────────────────────────

class _RevenueTab extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final monthly = ref.watch(monthlyRevenueProvider);

    return RefreshIndicator(
      color: AppColors.primary,
      onRefresh: () => ref.refresh(monthlyRevenueProvider.future),
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [

          monthly.when(
            loading: () => _loadingCard('جارٍ تحليل الإيراد...'),
            error:   (e, _) => _errorCard('$e'),
            data: (data) {
              final total = data.fold<double>(
                  0, (s, d) => s + (d['amount'] as double));
              final current = data.lastWhere(
                  (d) => d['isCurrent'] == true, orElse: () => data.last);
              final curAmt  = current['amount'] as double;
              final avg6    = data.isEmpty ? 0.0 : total / data.length;

              return Column(children: [
                AppUI.fadeSlide(index: 0, child: Row(children: [
                  _SummaryTile('هذا الشهر',
                      '${curAmt.toStringAsFixed(0)} ج', AppColors.accent),
                  const SizedBox(width: 10),
                  _SummaryTile('متوسط 6 أشهر',
                      '${avg6.toStringAsFixed(0)} ج', AppColors.primary),
                ])),
                const SizedBox(height: 16),
                AppUI.fadeSlide(index: 1,
                    child: MonthlyRevenueChart(data: data)),
                const SizedBox(height: 16),

                // Monthly breakdown table
                AppUI.fadeSlide(index: 2,
                    child: _MonthlyTable(data: data)),
              ]);
            },
          ),
        ],
      ),
    );
  }
}

class _MonthlyTable extends StatelessWidget {
  final List<Map<String, dynamic>> data;
  const _MonthlyTable({required this.data});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(
        children: data.reversed.map((d) {
          final amount  = d['amount'] as double;
          final isNow   = d['isCurrent'] == true;
          final color   = isNow ? AppColors.accent : AppColors.textSecondary;
          return ListTile(
            dense: true,
            leading: Text(d['monthLabel'] as String,
                style: TextStyle(fontWeight: FontWeight.bold, color: color)),
            title: Text('${d['year']}',
                style: const TextStyle(fontSize: 11,
                    color: AppColors.textSecondary)),
            trailing: Text('${amount.toStringAsFixed(0)} ج',
                style: TextStyle(fontWeight: FontWeight.bold, color: color)),
          );
        }).toList(),
      ),
    );
  }
}

// ── Tab 2: Students ───────────────────────────────────────────

class _StudentsTab extends ConsumerWidget {
  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final categories = ref.watch(studentCategoryProvider);
    final groups     = ref.watch(groupComparisonProvider);
    final rates      = ref.watch(studentAttendanceRateProvider);

    return RefreshIndicator(
      color: AppColors.primary,
      onRefresh: () => Future.wait([
        ref.refresh(studentCategoryProvider.future),
        ref.refresh(groupComparisonProvider.future),
        ref.refresh(studentAttendanceRateProvider.future),
      ]),
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [

          // Category donut
          categories.when(
            loading: () => _loadingCard(''),
            error:   (e, _) => _errorCard('$e'),
            data: (data) => AppUI.fadeSlide(index: 0,
                child: StudentCategoryChart(data: data)),
          ),
          const SizedBox(height: 16),

          // Group comparison
          groups.when(
            loading: () => _loadingCard(''),
            error:   (e, _) => _errorCard('$e'),
            data: (data) => data.isEmpty
                ? const SizedBox.shrink()
                : AppUI.fadeSlide(index: 1,
                    child: GroupComparisonChart(data: data)),
          ),
          const SizedBox(height: 16),

          // Top student table (best attendance)
          rates.when(
            loading: () => const SizedBox.shrink(),
            error:   (_, __) => const SizedBox.shrink(),
            data: (data) => data.isEmpty
                ? const SizedBox.shrink()
                : AppUI.fadeSlide(index: 2,
                    child: _TopStudentsTable(data: data.take(10).toList())),
          ),
        ],
      ),
    );
  }
}

class _TopStudentsTable extends StatelessWidget {
  final List<Map<String, dynamic>> data;
  const _TopStudentsTable({required this.data});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    const medals = ['🥇','🥈','🥉'];

    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('🏅 أفضل حضور',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 10),
        ...data.asMap().entries.map((e) {
          final s   = e.value['student'];
          final pct = e.value['percentage'] as double;
          final color = pct >= 75 ? AppColors.success : AppColors.warning;
          return Padding(
            padding: const EdgeInsets.only(bottom: 8),
            child: Row(children: [
              SizedBox(width: 24, child: Text(
                  e.key < 3 ? medals[e.key] : '${e.key + 1}',
                  style: const TextStyle(fontSize: 14))),
              Container(
                width: 30, height: 30,
                decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(9)),
                child: Center(child: Text(s.displayInitial,
                    style: TextStyle(color: color, fontSize: 12,
                        fontWeight: FontWeight.bold))),
              ),
              const SizedBox(width: 8),
              Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                Text(s.name,
                    style: const TextStyle(fontSize: 12,
                        fontWeight: FontWeight.bold),
                    overflow: TextOverflow.ellipsis),
                Text(s.groupName,
                    style: const TextStyle(fontSize: 9,
                        color: AppColors.textSecondary)),
              ])),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20)),
                child: Text('${pct.toStringAsFixed(0)}%',
                    style: TextStyle(fontSize: 11,
                        fontWeight: FontWeight.bold, color: color)),
              ),
            ]),
          );
        }),
      ]),
    );
  }
}

// ── Shared helpers ────────────────────────────────────────────

class _SummaryTile extends StatelessWidget {
  final String label, value;
  final Color color;
  const _SummaryTile(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: color.withOpacity(isDark ? 0.15 : 0.07),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(value, style: TextStyle(fontSize: 20,
              fontWeight: FontWeight.bold, color: color)),
          const SizedBox(height: 2),
          Text(label, style: const TextStyle(fontSize: 11,
              color: AppColors.textSecondary)),
        ]),
      ),
    );
  }
}

Widget _loadingCard(String msg) => Container(
  height: 80,
  decoration: BoxDecoration(
      color: AppColors.borderLight.withOpacity(0.3),
      borderRadius: BorderRadius.circular(14)),
  child: Center(child: Row(
      mainAxisAlignment: MainAxisAlignment.center, children: [
    const SizedBox(width: 16, height: 16,
        child: CircularProgressIndicator(
            strokeWidth: 2, color: AppColors.primary)),
    if (msg.isNotEmpty) ...[
      const SizedBox(width: 10),
      Text(msg, style: const TextStyle(
          fontSize: 11, color: AppColors.textSecondary)),
    ],
  ])),
);

Widget _errorCard(String msg) => Container(
  padding: const EdgeInsets.all(14),
  decoration: BoxDecoration(
      color: AppColors.danger.withOpacity(0.06),
      borderRadius: BorderRadius.circular(14)),
  child: Text('⚠️ $msg',
      style: const TextStyle(color: AppColors.danger, fontSize: 12)),
);
