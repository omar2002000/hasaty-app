// lib/features/analytics/analytics_service.dart
// ─────────────────────────────────────────────────────────────
// Stage 9 — Analytics Service.
//
// 4 core functions specified in the prompt:
//   getDailyAttendance()       → last 14 days, present count per day
//   getMonthlyRevenue()        → last 6 months totals
//   getStudentAttendanceRate() → per-student attendance %
//   getMostAbsentStudents()    → sorted by absence count
//
// Plus 2 bonus functions:
//   getGroupComparison()       → avg attendance % per group
//   getStudentsByCategory()    → Regular / Irregular / Inactive counts
//
// Rules:
//   • Pure Dart — no Flutter imports
//   • Uses existing repositories (no new DB tables)
//   • Results cached internally (simple TTL map)
//   • Every method guards against empty data
// ─────────────────────────────────────────────────────────────

import '../../domain/repositories/attendance_repository.dart';
import '../../domain/repositories/finance_repository.dart';
import '../../domain/repositories/student_repository.dart';
import '../../domain/entities/student.dart';

// ── Simple TTL cache ──────────────────────────────────────────

class _Entry {
  final dynamic data;
  final DateTime at;
  _Entry(this.data) : at = DateTime.now();
  bool get stale => DateTime.now().difference(at).inMinutes >= 5;
}

// ─────────────────────────────────────────────────────────────

class AnalyticsService {
  final StudentRepository    _studentRepo;
  final AttendanceRepository _attendanceRepo;
  final FinanceRepository    _financeRepo;

  AnalyticsService(this._studentRepo, this._attendanceRepo, this._financeRepo);

  final Map<String, _Entry> _cache = {};

  T? _hit<T>(String key) {
    final e = _cache[key];
    if (e != null && !e.stale) return e.data as T;
    return null;
  }

  void _set(String key, dynamic value) => _cache[key] = _Entry(value);

  // ════════════════════════════════════════════════════════════
  // 1. getDailyAttendance — last 14 days
  //
  // Returns: List of {date, presentCount, absentCount, totalSessions}
  //   ordered oldest → newest (left → right on chart)
  // ════════════════════════════════════════════════════════════

  Future<List<Map<String, dynamic>>> getDailyAttendance() async {
    const key = 'daily_att';
    final cached = _hit<List<Map<String, dynamic>>>(key);
    if (cached != null) return cached;

    final students = await _studentRepo.getStudents();
    final now      = DateTime.now();

    // Collect all attendance records for all students once
    final allRecords = <Map<String, dynamic>>[];
    for (final s in students) {
      final recs = await _attendanceRepo.getByStudent(s.id!);
      for (final r in recs) {
        allRecords.add({'date': r.date, 'present': r.present});
      }
    }

    // Build 14-day window
    final result = <Map<String, dynamic>>[];
    for (int i = 13; i >= 0; i--) {
      final day  = now.subtract(Duration(days: i));
      final dStr = '${day.day}/${day.month}/${day.year}';
      final recs = allRecords.where((r) => r['date'] == dStr).toList();
      result.add({
        'date':          dStr,
        'dayLabel':      '${day.day}/${day.month}',
        'presentCount':  recs.where((r) => r['present'] == true).length,
        'absentCount':   recs.where((r) => r['present'] == false).length,
        'totalSessions': recs.length,
      });
    }

    _set(key, result);
    return result;
  }

  // ════════════════════════════════════════════════════════════
  // 2. getMonthlyRevenue — last 6 months
  //
  // Returns: List of {monthLabel, amount, year, month}
  //   ordered oldest → newest
  // ════════════════════════════════════════════════════════════

  Future<List<Map<String, dynamic>>> getMonthlyRevenue() async {
    const key = 'monthly_rev';
    final cached = _hit<List<Map<String, dynamic>>>(key);
    if (cached != null) return cached;

    final payments = await _financeRepo.getAllPayments();
    final now      = DateTime.now();

    const monthNames = ['','يناير','فبراير','مارس','أبريل','مايو','يونيو',
        'يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];

    final result = <Map<String, dynamic>>[];
    for (int i = 5; i >= 0; i--) {
      int m = now.month - i;
      int y = now.year;
      if (m <= 0) { m += 12; y--; }

      final amount = payments
          .where((p) => p.date.endsWith('/$m/$y'))
          .fold<double>(0.0, (s, p) => s + p.amount);

      result.add({
        'month':      m,
        'year':       y,
        'monthLabel': monthNames[m],
        'amount':     amount,
        'isCurrent':  m == now.month && y == now.year,
      });
    }

    _set(key, result);
    return result;
  }

  // ════════════════════════════════════════════════════════════
  // 3. getStudentAttendanceRate — per student
  //
  // Returns: List of {student, percentage, present, absent, total}
  //   sorted by percentage descending
  // ════════════════════════════════════════════════════════════

  Future<List<Map<String, dynamic>>> getStudentAttendanceRate() async {
    const key = 'student_att_rate';
    final cached = _hit<List<Map<String, dynamic>>>(key);
    if (cached != null) return cached;

    final students = await _studentRepo.getStudents();
    final result   = <Map<String, dynamic>>[];

    for (final s in students) {
      final recs    = await _attendanceRepo.getByStudent(s.id!);
      final total   = recs.length;
      final present = recs.where((r) => r.present).length;
      final absent  = total - present;
      final pct     = total > 0 ? present / total * 100 : 0.0;
      result.add({
        'student':    s,
        'percentage': pct,
        'present':    present,
        'absent':     absent,
        'total':      total,
      });
    }

    result.sort((a, b) =>
        (b['percentage'] as double).compareTo(a['percentage'] as double));

    _set(key, result);
    return result;
  }

  // ════════════════════════════════════════════════════════════
  // 4. getMostAbsentStudents — top N by absence count
  //
  // Returns: List of {student, absentCount, percentage}
  //   sorted by absentCount descending, min 1 absence
  // ════════════════════════════════════════════════════════════

  Future<List<Map<String, dynamic>>> getMostAbsentStudents({
    int topN = 10,
  }) async {
    final key = 'most_absent_$topN';
    final cached = _hit<List<Map<String, dynamic>>>(key);
    if (cached != null) return cached;

    final rates  = await getStudentAttendanceRate();
    final result = rates
        .where((e) => (e['absent'] as int) > 0)
        .map((e) => {
              'student':    e['student'],
              'absentCount': e['absent'],
              'percentage':  e['percentage'],
            })
        .toList()
      ..sort((a, b) =>
          (b['absentCount'] as int).compareTo(a['absentCount'] as int));

    final limited = result.take(topN).toList();
    _set(key, limited);
    return limited;
  }

  // ════════════════════════════════════════════════════════════
  // 5. getGroupComparison — avg attendance % per group
  //
  // Returns: List of {group, avgPct, studentCount}
  //   sorted by avgPct descending
  // ════════════════════════════════════════════════════════════

  Future<List<Map<String, dynamic>>> getGroupComparison() async {
    const key = 'group_cmp';
    final cached = _hit<List<Map<String, dynamic>>>(key);
    if (cached != null) return cached;

    final rates  = await getStudentAttendanceRate();
    final groups = <String, List<double>>{};

    for (final e in rates) {
      final s = e['student'] as Student;
      groups.putIfAbsent(s.groupName, () => [])
          .add(e['percentage'] as double);
    }

    final result = groups.entries.map((e) => {
      'group':        e.key,
      'avgPct':       e.value.isEmpty ? 0.0
          : e.value.fold<double>(0, (s, v) => s + v) / e.value.length,
      'studentCount': e.value.length,
    }).toList()
      ..sort((a, b) =>
          (b['avgPct'] as double).compareTo(a['avgPct'] as double));

    _set(key, result);
    return result;
  }

  // ════════════════════════════════════════════════════════════
  // 6. getStudentsByCategory — Regular / Irregular / Inactive
  //
  // Uses Stage 8 Smart Status thresholds (attendance-only):
  //   >80% → Regular, 50–80% → Irregular, <50% → Inactive
  // ════════════════════════════════════════════════════════════

  Future<Map<String, int>> getStudentsByCategory() async {
    const key = 'student_categories';
    final cached = _hit<Map<String, int>>(key);
    if (cached != null) return cached;

    final rates   = await getStudentAttendanceRate();
    int regular   = 0, irregular = 0, inactive = 0;

    for (final e in rates) {
      final pct = e['percentage'] as double;
      if (pct > 80)       regular++;
      else if (pct >= 50) irregular++;
      else                inactive++;
    }

    final result = {
      'regular':   regular,
      'irregular': irregular,
      'inactive':  inactive,
    };
    _set(key, result);
    return result;
  }

  /// Clears all cached results (call after bulk operations).
  void clearCache() => _cache.clear();
}
