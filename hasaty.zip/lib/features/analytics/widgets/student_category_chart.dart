// lib/features/analytics/widgets/student_category_chart.dart
// Stage 9 — Student category donut chart.
// Regular / Irregular / Inactive based on Stage 8 Smart Status.
import 'dart:math';
import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';

class StudentCategoryChart extends StatelessWidget {
  final Map<String, int> data; // from getStudentsByCategory()
  const StudentCategoryChart({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final isDark   = Theme.of(context).brightness == Brightness.dark;
    final regular  = data['regular']   ?? 0;
    final irregular= data['irregular'] ?? 0;
    final inactive = data['inactive']  ?? 0;
    final total    = regular + irregular + inactive;

    if (total == 0) return const SizedBox.shrink();

    final sections = [
      _PieSection('ملتزم',    regular,   AppColors.success),
      _PieSection('متذبذب',   irregular, AppColors.warning),
      _PieSection('غير نشط',  inactive,  AppColors.danger),
    ];

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('🎯 توزيع الطلاب',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 16),
        Row(children: [
          // Donut chart
          SizedBox(
            width: 120, height: 120,
            child: CustomPaint(
              painter: _DonutPainter(sections: sections, total: total),
              child: Center(child: Column(
                  mainAxisSize: MainAxisSize.min, children: [
                Text('$total',
                    style: const TextStyle(
                        fontSize: 22, fontWeight: FontWeight.bold)),
                const Text('طالب',
                    style: TextStyle(
                        fontSize: 10, color: AppColors.textSecondary)),
              ])),
            ),
          ),
          const SizedBox(width: 20),
          // Legend
          Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: sections.map((s) {
                final pct = total > 0
                    ? (s.count / total * 100).toStringAsFixed(0) : '0';
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Row(children: [
                    Container(width: 12, height: 12,
                        decoration: BoxDecoration(
                            color: s.color, shape: BoxShape.circle)),
                    const SizedBox(width: 8),
                    Expanded(child: Text(s.label,
                        style: const TextStyle(fontSize: 12,
                            fontWeight: FontWeight.bold))),
                    Text('${s.count} ($pct%)',
                        style: TextStyle(fontSize: 11,
                            fontWeight: FontWeight.bold, color: s.color)),
                  ]),
                );
              }).toList())),
        ]),
      ]),
    );
  }
}

class _PieSection {
  final String label; final int count; final Color color;
  const _PieSection(this.label, this.count, this.color);
}

class _DonutPainter extends CustomPainter {
  final List<_PieSection> sections;
  final int total;
  const _DonutPainter({required this.sections, required this.total});

  @override
  void paint(Canvas canvas, Size size) {
    final cx     = size.width / 2;
    final cy     = size.height / 2;
    final radius = min(cx, cy) - 6;
    const hole   = 0.55; // donut hole ratio

    double startAngle = -pi / 2;
    for (final s in sections) {
      if (s.count == 0) continue;
      final sweep = 2 * pi * s.count / total;
      final paint = Paint()
        ..color     = s.color
        ..style     = PaintingStyle.stroke
        ..strokeWidth = radius * (1 - hole)
        ..strokeCap = StrokeCap.butt;
      canvas.drawArc(
        Rect.fromCircle(center: Offset(cx, cy),
            radius: radius - radius * (1 - hole) / 2),
        startAngle, sweep, false, paint,
      );
      // Gap
      startAngle += sweep + 0.02;
    }
  }

  @override
  bool shouldRepaint(_DonutPainter old) =>
      old.sections != sections || old.total != total;
}
