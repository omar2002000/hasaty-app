// lib/features/analytics/widgets/most_absent_chart.dart
// Stage 9 — Most absent students horizontal bar chart.
import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../domain/entities/student.dart';

class MostAbsentChart extends StatelessWidget {
  final List<Map<String, dynamic>> data; // from getMostAbsentStudents()
  const MostAbsentChart({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    if (data.isEmpty) return const SizedBox.shrink();

    final maxAbsent = (data.first['absentCount'] as int).toDouble()
        .clamp(1.0, double.infinity);
    final shown = data.take(7).toList();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('📵 أكثر الطلاب غياباً',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 14),
        ...shown.asMap().entries.map((e) {
          final entry   = e.value;
          final s       = entry['student'] as Student;
          final absent  = entry['absentCount'] as int;
          final pct     = entry['percentage'] as double;
          final barPct  = absent / maxAbsent;
          final color   = pct < 50 ? AppColors.danger : AppColors.warning;

          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(children: [
              // Rank
              SizedBox(width: 18,
                  child: Text('${e.key + 1}',
                      style: const TextStyle(fontSize: 11,
                          color: AppColors.textSecondary,
                          fontWeight: FontWeight.bold))),
              // Avatar
              Container(
                width: 28, height: 28,
                decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8)),
                child: Center(child: Text(s.displayInitial,
                    style: TextStyle(color: color, fontSize: 12,
                        fontWeight: FontWeight.bold))),
              ),
              const SizedBox(width: 8),
              // Name + bar
              Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Expanded(child: Text(s.name,
                        style: const TextStyle(fontSize: 12,
                            fontWeight: FontWeight.bold),
                        overflow: TextOverflow.ellipsis)),
                    Text('$absent غياب',
                        style: TextStyle(fontSize: 10,
                            fontWeight: FontWeight.bold, color: color)),
                  ],
                ),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(3),
                  child: LinearProgressIndicator(
                    value: barPct,
                    backgroundColor: AppColors.borderLight,
                    color: color,
                    minHeight: 5,
                  ),
                ),
              ])),
            ]),
          );
        }),
      ]),
    );
  }
}
