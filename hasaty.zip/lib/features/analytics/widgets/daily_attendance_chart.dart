// lib/features/analytics/widgets/daily_attendance_chart.dart
// Stage 9 — Daily attendance bar chart (last 14 days).
// Shows present count per day as stacked-style bars.
import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';

class DailyAttendanceChart extends StatelessWidget {
  final List<Map<String, dynamic>> data; // from getDailyAttendance()
  const DailyAttendanceChart({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final isDark   = Theme.of(context).brightness == Brightness.dark;
    if (data.isEmpty) return _empty(isDark);

    final maxVal = data
        .map((d) => (d['presentCount'] as int).toDouble())
        .fold(1.0, (a, b) => a > b ? a : b);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('📅 الحضور اليومي (14 يوم)',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
                color: AppColors.success.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10)),
            child: Text(
              'أعلى: ${maxVal.toStringAsFixed(0)} طالب',
              style: const TextStyle(fontSize: 10,
                  fontWeight: FontWeight.bold, color: AppColors.success),
            ),
          ),
        ]),
        const SizedBox(height: 14),
        SizedBox(
          height: 100,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: data.map((d) {
              final present = (d['presentCount'] as int).toDouble();
              final pct     = maxVal > 0 ? present / maxVal : 0.0;
              final isToday = d['isCurrent'] == true ||
                  data.last == d;
              return Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 1.5),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      AnimatedContainer(
                        duration: const Duration(milliseconds: 500),
                        curve: Curves.easeOut,
                        height: (pct * 80).clamp(3.0, 80.0),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: isToday
                                ? [AppColors.success,
                                    AppColors.success.withOpacity(0.6)]
                                : [AppColors.primary.withOpacity(0.7),
                                    AppColors.primary.withOpacity(0.3)],
                            begin: Alignment.topCenter,
                            end:   Alignment.bottomCenter,
                          ),
                          borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(4)),
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        (d['dayLabel'] as String),
                        style: TextStyle(
                          fontSize: 7,
                          color: isToday
                              ? AppColors.primary
                              : AppColors.textSecondary,
                          fontWeight: isToday
                              ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        const SizedBox(height: 10),
        // Legend
        Row(children: [
          _Legend('حاضر', AppColors.success),
          const SizedBox(width: 14),
          _Legend('اليوم', AppColors.primary),
        ]),
      ]),
    );
  }

  Widget _empty(bool isDark) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight)),
    child: const Center(child: Text('لا توجد بيانات حضور بعد',
        style: TextStyle(color: AppColors.textSecondary))),
  );
}

class _Legend extends StatelessWidget {
  final String label; final Color color;
  const _Legend(this.label, this.color);
  @override
  Widget build(BuildContext context) => Row(children: [
    Container(width: 10, height: 10,
        decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
    const SizedBox(width: 4),
    Text(label, style: const TextStyle(fontSize: 10,
        color: AppColors.textSecondary)),
  ]);
}
