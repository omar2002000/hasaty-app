// lib/features/analytics/widgets/monthly_revenue_chart.dart
// Stage 9 — Monthly revenue bar chart (last 6 months) with trend line.
import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';

class MonthlyRevenueChart extends StatelessWidget {
  final List<Map<String, dynamic>> data; // from getMonthlyRevenue()
  const MonthlyRevenueChart({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final isDark  = Theme.of(context).brightness == Brightness.dark;
    if (data.isEmpty) return const SizedBox.shrink();

    final amounts = data.map((d) => (d['amount'] as double)).toList();
    final maxVal  = amounts.fold(1.0, (a, b) => a > b ? a : b);
    final total   = amounts.fold(0.0, (a, b) => a + b);
    final current = data.lastWhere(
        (d) => d['isCurrent'] == true, orElse: () => data.last);

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('💰 الإيراد الشهري (6 أشهر)',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          Text('${(current['amount'] as double).toStringAsFixed(0)} ج',
              style: const TextStyle(fontSize: 12,
                  fontWeight: FontWeight.bold, color: AppColors.success)),
        ]),
        const SizedBox(height: 4),
        Text('إجمالي 6 أشهر: ${total.toStringAsFixed(0)} ج',
            style: const TextStyle(fontSize: 10,
                color: AppColors.textSecondary)),
        const SizedBox(height: 14),
        SizedBox(
          height: 110,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: data.asMap().entries.map((e) {
              final d      = e.value;
              final amount = d['amount'] as double;
              final pct    = maxVal > 0 ? amount / maxVal : 0.0;
              final isNow  = d['isCurrent'] == true;
              return Expanded(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [
                      if (isNow && amount > 0)
                        Container(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 4, vertical: 2),
                          decoration: BoxDecoration(
                              color: AppColors.accent,
                              borderRadius: BorderRadius.circular(5)),
                          child: Text(
                            amount.toStringAsFixed(0),
                            style: const TextStyle(color: Colors.white,
                                fontSize: 8, fontWeight: FontWeight.bold),
                          ),
                        ),
                      const SizedBox(height: 3),
                      AnimatedContainer(
                        duration: Duration(
                            milliseconds: 400 + e.key * 100),
                        curve: Curves.easeOut,
                        height: (pct * 80).clamp(4.0, 80.0),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: isNow
                                ? [AppColors.accent,
                                    AppColors.accent.withOpacity(0.6)]
                                : [AppColors.primary.withOpacity(0.65),
                                    AppColors.primary.withOpacity(0.3)],
                            begin: Alignment.topCenter,
                            end:   Alignment.bottomCenter,
                          ),
                          borderRadius: const BorderRadius.vertical(
                              top: Radius.circular(5)),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        (d['monthLabel'] as String).substring(0, 3),
                        style: TextStyle(
                            fontSize: 9,
                            color: isNow
                                ? AppColors.accent
                                : AppColors.textSecondary,
                            fontWeight: isNow
                                ? FontWeight.bold : FontWeight.normal),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ),
      ]),
    );
  }
}
