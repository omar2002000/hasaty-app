// lib/features/analytics/widgets/group_comparison_chart.dart
// Stage 9 — Group comparison bar chart (avg attendance % per group).
import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';

class GroupComparisonChart extends StatelessWidget {
  final List<Map<String, dynamic>> data; // from getGroupComparison()
  const GroupComparisonChart({super.key, required this.data});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    if (data.isEmpty) return const SizedBox.shrink();

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('👥 مقارنة المجموعات',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 14),
        ...data.asMap().entries.map((e) {
          final d    = e.value;
          final pct  = (d['avgPct'] as double).clamp(0.0, 100.0);
          final count= d['studentCount'] as int;
          final color= pct >= 75 ? AppColors.success
              : pct >= 50 ? AppColors.warning : AppColors.danger;

          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(children: [
                  Expanded(child: Text(d['group'] as String,
                      style: const TextStyle(
                          fontSize: 12, fontWeight: FontWeight.bold))),
                  Text('$count طالب',
                      style: const TextStyle(
                          fontSize: 10, color: AppColors.textSecondary)),
                  const SizedBox(width: 8),
                  Text('${pct.toStringAsFixed(0)}%',
                      style: TextStyle(fontSize: 12,
                          fontWeight: FontWeight.bold, color: color)),
                ]),
                const SizedBox(height: 5),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: pct / 100,
                    backgroundColor: AppColors.borderLight,
                    color: color,
                    minHeight: 7,
                  ),
                ),
              ],
            ),
          );
        }),
      ]),
    );
  }
}
