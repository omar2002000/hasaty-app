// lib/features/xp/xp_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/xp_progress_bar.dart';
import '../../domain/entities/student.dart';
import '../../domain/entities/achievement.dart';
import '../../domain/entities/xp_level.dart';
import '../../core/providers/usecase_providers.dart';
import '../../providers/global_providers.dart';
import 'widgets/achievement_card.dart';
import 'widgets/level_badge.dart';

final _xpAchievementsProvider = FutureProvider.family<List<String>, int>(
    (ref, sid) => ref.read(achievementRepositoryProvider)
        .getStudentAchievements(sid));

final leaderboardProvider = FutureProvider<List<Student>>((ref) async {
  final students = await ref.read(studentRepositoryProvider).getStudents();
  return [...students]..sort((a, b) => b.xp.compareTo(a.xp));
});

class XpScreen extends ConsumerStatefulWidget {
  final Student student;
  const XpScreen({super.key, required this.student});

  @override
  ConsumerState<XpScreen> createState() => _XpScreenState();
}

class _XpScreenState extends ConsumerState<XpScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s       = widget.student;
    final xpData  = ref.read(calculateXpUseCaseProvider).execute(s.xp);
    final level   = xpData['level'] as XpLevel;
    final achievements = ref.watch(_xpAchievementsProvider(s.id!));

    return Scaffold(
      appBar: AppBar(
        title: Text('XP — ${s.name}'),
        bottom: TabBar(
          controller: _tab,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          indicatorColor: Colors.white,
          tabs: const [Tab(text: 'ملف XP'), Tab(text: 'المتصدرون')],
        ),
      ),
      body: TabBarView(
        controller: _tab,
        children: [
          // ── XP Profile ─────────────────────────────────────
          SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(children: [

              // Level Card
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(24),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(
                      colors: [AppColors.primary, AppColors.primaryLight]),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Column(children: [
                  Text(level.emoji, style: const TextStyle(fontSize: 52)),
                  const SizedBox(height: 8),
                  LevelBadge(level: level, large: true),
                  const SizedBox(height: 16),
                  XpProgressBar(
                    progress: xpData['progress'],
                    currentXp: s.xp,
                    nextXp: level.maxXp,
                  ),
                  const SizedBox(height: 8),
                  Text('${s.xp} / ${level.maxXp == 999999 ? '∞' : level.maxXp} XP',
                      style: const TextStyle(color: Colors.white70, fontSize: 12)),
                ]),
              ),
              const SizedBox(height: 16),

              // Stats
              Row(children: [
                _StatPill(icon: Icons.stars_rounded,
                    value: '${s.xp}', label: 'نقاط XP',
                    color: AppColors.warning),
                const SizedBox(width: 10),
                _StatPill(icon: Icons.monetization_on_rounded,
                    value: '${s.coins}', label: 'عملات',
                    color: AppColors.accent),
              ]),
              const SizedBox(height: 20),

              // All Levels Map
              const Align(alignment: Alignment.centerRight,
                  child: Text('🗺️ خريطة المستويات',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15))),
              const SizedBox(height: 10),
              ...kXpLevels.map((l) {
                final unlocked = s.xp >= l.minXp;
                final current  = s.xp >= l.minXp &&
                    (l.maxXp == 999999 || s.xp < l.maxXp);
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: current
                        ? AppColors.primary.withOpacity(0.08)
                        : unlocked
                            ? AppColors.success.withOpacity(0.05)
                            : Colors.transparent,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                        color: current
                            ? AppColors.primary.withOpacity(0.3)
                            : unlocked
                                ? AppColors.success.withOpacity(0.2)
                                : AppColors.borderLight),
                  ),
                  child: Row(children: [
                    Text(l.emoji, style: const TextStyle(fontSize: 22)),
                    const SizedBox(width: 12),
                    Expanded(child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(l.nameAr,
                          style: TextStyle(
                              fontWeight: FontWeight.bold,
                              color: current ? AppColors.primary : null)),
                      Text(
                        '${l.minXp} – ${l.maxXp == 999999 ? '∞' : l.maxXp} XP',
                        style: const TextStyle(
                            fontSize: 11, color: AppColors.textSecondary),
                      ),
                    ])),
                    if (current)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                            color: AppColors.primary.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20)),
                        child: const Text('أنت هنا',
                            style: TextStyle(fontSize: 11,
                                fontWeight: FontWeight.bold,
                                color: AppColors.primary)),
                      )
                    else if (unlocked)
                      const Icon(Icons.check_circle_rounded,
                          color: AppColors.success, size: 20)
                    else
                      const Icon(Icons.lock_outline,
                          color: AppColors.textSecondary, size: 18),
                  ]),
                );
              }),
              const SizedBox(height: 20),

              // Achievements
              const Align(alignment: Alignment.centerRight,
                  child: Text('🏆 الإنجازات',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15))),
              const SizedBox(height: 10),
              achievements.when(
                loading: () => const CircularProgressIndicator(
                    color: AppColors.primary),
                error:   (_, __) => const SizedBox.shrink(),
                data: (unlockedIds) => Column(
                  children: Achievements.all.map((a) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: AchievementCard(
                      achievement: a,
                      unlocked:    unlockedIds.contains(a.id),
                    ),
                  )).toList(),
                ),
              ),
            ]),
          ),

          // ── Leaderboard ─────────────────────────────────────
          _LeaderboardTab(currentStudentId: s.id!),
        ],
      ),
    );
  }
}

class _LeaderboardTab extends ConsumerWidget {
  final int currentStudentId;
  const _LeaderboardTab({required this.currentStudentId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(leaderboardProvider);
    return state.when(
      loading: () => const Center(child: CircularProgressIndicator(
          color: AppColors.primary)),
      error:   (e, _) => Center(child: Text('$e')),
      data: (students) => ListView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: students.length,
        itemBuilder: (_, i) {
          final s       = students[i];
          final isMe    = s.id == currentStudentId;
          final isDark  = Theme.of(context).brightness == Brightness.dark;
          final medals  = ['🥇', '🥈', '🥉'];
          final medal   = i < 3 ? medals[i] : '${i + 1}';
          final maxXp   = students.first.xp.clamp(1, 99999);
          final pct     = s.xp / maxXp;

          return AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(
              color: isMe
                  ? AppColors.primary.withOpacity(0.08)
                  : isDark ? AppColors.bgCardDark : AppColors.bgCard,
              borderRadius: BorderRadius.circular(13),
              border: Border.all(
                  color: isMe
                      ? AppColors.primary.withOpacity(0.4)
                      : AppColors.borderLight,
                  width: isMe ? 1.5 : 1),
            ),
            child: Row(children: [
              SizedBox(
                width: 32,
                child: Text(medal,
                    style: TextStyle(
                        fontSize: i < 3 ? 20 : 14,
                        fontWeight: FontWeight.bold),
                    textAlign: TextAlign.center),
              ),
              const SizedBox(width: 10),
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(
                  color: isMe
                      ? AppColors.primary.withOpacity(0.15)
                      : AppColors.textSecondary.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(11),
                ),
                child: Center(child: Text(s.displayInitial,
                    style: TextStyle(
                        color: isMe ? AppColors.primary : AppColors.textSecondary,
                        fontWeight: FontWeight.bold))),
              ),
              const SizedBox(width: 10),
              Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  Text(s.name,
                      style: TextStyle(
                          fontWeight: FontWeight.bold, fontSize: 13,
                          color: isMe ? AppColors.primary : null)),
                  if (isMe) ...[
                    const SizedBox(width: 4),
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 1),
                      decoration: BoxDecoration(
                          color: AppColors.primary,
                          borderRadius: BorderRadius.circular(10)),
                      child: const Text('أنت',
                          style: TextStyle(color: Colors.white,
                              fontSize: 9, fontWeight: FontWeight.bold)),
                    ),
                  ],
                ]),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(
                    value: pct,
                    backgroundColor: AppColors.borderLight,
                    color: i == 0
                        ? AppColors.warning
                        : i < 3
                            ? AppColors.primary
                            : AppColors.textSecondary,
                    minHeight: 4,
                  ),
                ),
              ])),
              const SizedBox(width: 8),
              Text('${s.xp} XP',
                  style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: i < 3 ? AppColors.warning : AppColors.textSecondary)),
            ]),
          );
        },
      ),
    );
  }
}

class _StatPill extends StatelessWidget {
  final IconData icon;
  final String value, label;
  final Color color;
  const _StatPill({required this.icon, required this.value,
      required this.label, required this.color});

  @override
  Widget build(BuildContext context) => Expanded(
    child: Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Row(children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(width: 10),
        Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(value,
              style: TextStyle(fontSize: 18,
                  fontWeight: FontWeight.bold, color: color)),
          Text(label,
              style: const TextStyle(
                  fontSize: 11, color: AppColors.textSecondary)),
        ]),
      ]),
    ),
  );
}
