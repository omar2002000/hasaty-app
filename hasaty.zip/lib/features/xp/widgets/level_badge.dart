// lib/features/xp/widgets/level_badge.dart
import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../domain/entities/xp_level.dart';

class LevelBadge extends StatelessWidget {
  final XpLevel level;
  final bool large;

  const LevelBadge({super.key, required this.level, this.large = false});

  @override
  Widget build(BuildContext context) {
    final size = large ? 18.0 : 13.0;
    return Container(
      padding: EdgeInsets.symmetric(
          horizontal: large ? 14 : 10,
          vertical:   large ? 7  : 4),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
            colors: [AppColors.primary, AppColors.primaryLight]),
        borderRadius: BorderRadius.circular(large ? 16 : 20),
        boxShadow: large
            ? [BoxShadow(
                color: AppColors.primary.withOpacity(0.3),
                blurRadius: 8, offset: const Offset(0, 3))]
            : null,
      ),
      child: Row(mainAxisSize: MainAxisSize.min, children: [
        Text(level.emoji,
            style: TextStyle(fontSize: large ? 18 : 13)),
        const SizedBox(width: 5),
        Text(level.nameAr,
            style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: size)),
      ]),
    );
  }
}
