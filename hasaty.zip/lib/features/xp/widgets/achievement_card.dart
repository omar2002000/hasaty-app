// lib/features/xp/widgets/achievement_card.dart
import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../domain/entities/achievement.dart';

class AchievementCard extends StatelessWidget {
  final Achievement achievement;
  final bool unlocked;

  const AchievementCard({
    super.key,
    required this.achievement,
    required this.unlocked,
  });

  @override
  Widget build(BuildContext context) {
    final color = unlocked ? AppColors.warning : AppColors.textSecondary;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: unlocked
            ? AppColors.warning.withOpacity(0.08)
            : AppColors.borderLight.withOpacity(0.3),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(
          color: unlocked
              ? AppColors.warning.withOpacity(0.3)
              : AppColors.borderLight,
        ),
      ),
      child: Row(children: [
        // Icon / Emoji
        Container(
          width: 42, height: 42,
          decoration: BoxDecoration(
            color: color.withOpacity(0.12),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Center(
            child: Text(
              unlocked ? achievement.emoji : '🔒',
              style: const TextStyle(fontSize: 20),
            ),
          ),
        ),
        const SizedBox(width: 12),
        // Info
        Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(achievement.title,
              style: TextStyle(
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                  color: unlocked ? null : AppColors.textSecondary)),
          const SizedBox(height: 2),
          Text(achievement.description,
              style: const TextStyle(
                  fontSize: 11, color: AppColors.textSecondary)),
        ])),
        // Status badge
        if (unlocked)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
            decoration: BoxDecoration(
              color: AppColors.success.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Text('مُنجَز',
                style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    color: AppColors.success)),
          ),
      ]),
    );
  }
}
