// lib/features/xp/providers/xp_provider.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../domain/entities/student.dart';
import '../../../domain/entities/xp_level.dart';
import '../../../core/providers/usecase_providers.dart';

/// Provider scoped to a specific student — returns full XP data map.
final xpProvider = Provider.family<Map<String, dynamic>, Student>((ref, student) {
  return ref.read(calculateXpUseCaseProvider).execute(student.xp);
});

/// Provider for the current level of a student (by XP int)
final xpLevelProvider = Provider.family<XpLevel, int>((ref, xp) {
  return getXpLevel(xp);
});
