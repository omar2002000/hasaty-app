// lib/features/finance/widgets/payment_timeline.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/theme/app_colors.dart';
import '../../../domain/entities/subscription.dart';
import '../../../providers/global_providers.dart';

final _studentSubsProvider =
    FutureProvider.family<List<Subscription>, int>((ref, studentId) =>
        ref.read(financeRepositoryProvider)
            .getSubscriptions(studentId: studentId));

class PaymentTimeline extends ConsumerWidget {
  final int studentId;
  const PaymentTimeline({super.key, required this.studentId});

  static const _monthNames = ['', 'يناير', 'فبراير', 'مارس', 'أبريل',
      'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state  = ref.watch(_studentSubsProvider(studentId));
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return state.when(
      loading: () => const Center(child: CircularProgressIndicator(
          color: AppColors.primary)),
      error:   (e, _) => Center(child: Text('$e')),
      data: (subs) {
        if (subs.isEmpty) {
          return const Center(child: Text('لا توجد اشتراكات مسجّلة',
              style: TextStyle(color: AppColors.textSecondary)));
        }

        // Group by year
        final Map<int, List<Subscription>> byYear = {};
        for (final s in subs) {
          byYear.putIfAbsent(s.year, () => []).add(s);
        }
        final years = byYear.keys.toList()..sort((a, b) => b.compareTo(a));

        return ListView(
          padding: const EdgeInsets.all(16),
          children: years.map((year) {
            final yearSubs = byYear[year]!;
            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Year header
                Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Text('$year',
                      style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: AppColors.primary)),
                ),

                // 12-month grid
                GridView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4,
                    childAspectRatio: 1.4,
                    crossAxisSpacing: 8,
                    mainAxisSpacing: 8,
                  ),
                  itemCount: 12,
                  itemBuilder: (_, i) {
                    final month = i + 1;
                    final sub   = yearSubs.firstWhere(
                        (s) => s.month == month,
                        orElse: () => Subscription(
                            studentId: null, groupId: null,
                            studentName: '', groupName: '',
                            month: month, year: year, amount: 0));

                    final hasData = sub.id != null;
                    Color color;
                    String emoji;

                    if (!hasData) {
                      color = AppColors.borderLight;
                      emoji = '—';
                    } else {
                      switch (sub.status) {
                        case 'paid':
                          color = AppColors.success;
                          emoji = '✅';
                          break;
                        case 'partial':
                          color = AppColors.warning;
                          emoji = '⚠️';
                          break;
                        default:
                          color = AppColors.danger;
                          emoji = '❌';
                      }
                    }

                    return Tooltip(
                      message: hasData
                          ? '${_monthNames[month]} — ${sub.statusLabel}\n'
                            '${sub.paidAmount.toStringAsFixed(0)} / ${sub.amount.toStringAsFixed(0)} ج.م'
                          : _monthNames[month],
                      child: Container(
                        decoration: BoxDecoration(
                          color: hasData
                              ? color.withOpacity(0.1)
                              : (isDark
                                  ? AppColors.bgCardDark
                                  : AppColors.bgLight),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(
                              color: color.withOpacity(hasData ? 0.3 : 0.1)),
                        ),
                        child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                          Text(emoji, style: const TextStyle(fontSize: 14)),
                          const SizedBox(height: 2),
                          Text(
                            _monthNames[month].substring(0, 3),
                            style: TextStyle(
                              fontSize: 9,
                              fontWeight: FontWeight.bold,
                              color: hasData ? color : AppColors.textSecondary,
                            ),
                          ),
                        ]),
                      ),
                    );
                  },
                ),
                const SizedBox(height: 8),

                // Year summary
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    _YearStat('✅',
                        yearSubs.where((s) => s.status == 'paid').length,
                        AppColors.success),
                    _YearStat('⚠️',
                        yearSubs.where((s) => s.status == 'partial').length,
                        AppColors.warning),
                    _YearStat('❌',
                        yearSubs.where((s) => s.status == 'unpaid').length,
                        AppColors.danger),
                    _YearStat('💰',
                        (yearSubs.fold<double>(
                                0, (s, x) => s + x.paidAmount) ~/
                            1),
                        AppColors.primary,
                        suffix: 'ج'),
                  ],
                ),
                const Divider(height: 24),
              ],
            );
          }).toList(),
        );
      },
    );
  }
}

class _YearStat extends StatelessWidget {
  final String icon;
  final num value;
  final Color color;
  final String suffix;
  const _YearStat(this.icon, this.value, this.color, {this.suffix = ''});

  @override
  Widget build(BuildContext context) => Column(children: [
    Text(icon, style: const TextStyle(fontSize: 14)),
    Text('$value$suffix',
        style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: color)),
  ]);
}
