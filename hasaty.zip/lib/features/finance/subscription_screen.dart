// lib/features/finance/subscription_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/ui_helpers.dart';
import '../../domain/entities/subscription.dart';
import '../../domain/entities/student.dart';
import '../../providers/global_providers.dart';
import '../../core/providers/usecase_providers.dart';

// ── Providers ────────────────────────────────────────────────
final _subsProvider = FutureProvider.family<List<Subscription>, _SubsParams>(
  (ref, p) => ref
      .read(financeRepositoryProvider)
      .getSubscriptions(month: p.month, year: p.year),
);

class _SubsParams {
  final int month, year;
  const _SubsParams(this.month, this.year);
  @override
  bool operator ==(Object o) =>
      o is _SubsParams && o.month == month && o.year == year;
  @override
  int get hashCode => Object.hash(month, year);
}

// ─────────────────────────────────────────────────────────────

class SubscriptionScreen extends ConsumerStatefulWidget {
  const SubscriptionScreen({super.key});

  @override
  ConsumerState<SubscriptionScreen> createState() =>
      _SubscriptionScreenState();
}

class _SubscriptionScreenState extends ConsumerState<SubscriptionScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;
  int _month = DateTime.now().month;
  int _year  = DateTime.now().year;
  bool _running = false;

  final _monthNames = const [
    '', 'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
    'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
  ];

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final subState =
        ref.watch(_subsProvider(_SubsParams(_month, _year)));
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Scaffold(
      appBar: AppBar(
        title: const Text('الاشتراكات'),
        bottom: TabBar(
          controller: _tab,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          indicatorColor: Colors.white,
          tabs: const [Tab(text: 'الشهر'), Tab(text: 'متأخرون')],
        ),
      ),
      body: Column(children: [
        // ── Month picker + stats ────────────────────────────
        Container(
          color: isDark
              ? AppColors.bgCardDark
              : AppColors.primary.withOpacity(0.04),
          padding: const EdgeInsets.all(14),
          child: Column(children: [
            Row(children: [
              Expanded(
                child: GestureDetector(
                  onTap: _pickMonth,
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AppColors.primary.withOpacity(0.08),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: AppColors.primary.withOpacity(0.2)),
                    ),
                    child: Row(children: [
                      const Icon(Icons.calendar_month,
                          color: AppColors.primary, size: 16),
                      const SizedBox(width: 8),
                      Text(
                          '${_monthNames[_month]} $_year',
                          style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              color: AppColors.primary)),
                    ]),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              ElevatedButton.icon(
                icon: _running
                    ? const SizedBox(
                        width: 14, height: 14,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: Colors.white))
                    : const Icon(Icons.play_arrow, size: 16),
                label: const Text('توليد'),
                onPressed: _running ? null : _runEngine,
              ),
            ]),
            const SizedBox(height: 10),
            subState.when(
              loading: () => const SizedBox.shrink(),
              error:   (_, __) => const SizedBox.shrink(),
              data: (subs) {
                final expected =
                    subs.fold<double>(0, (s, x) => s + x.amount);
                final paid = subs
                    .fold<double>(0, (s, x) => s + x.paidAmount);
                final rate =
                    expected > 0 ? paid / expected * 100 : 0.0;
                return Row(children: [
                  _metric('${expected.toStringAsFixed(0)} ج',
                      'متوقع', AppColors.textSecondary),
                  _metric('${paid.toStringAsFixed(0)} ج',
                      'محصّل', AppColors.success),
                  _metric('${rate.toStringAsFixed(0)}%',
                      'نسبة التحصيل',
                      rate >= 70
                          ? AppColors.success
                          : AppColors.warning),
                ]);
              },
            ),
          ]),
        ),

        // ── Tabs ─────────────────────────────────────────────
        Expanded(
          child: TabBarView(
            controller: _tab,
            children: [
              subState.when(
                loading: () => const Center(
                    child: CircularProgressIndicator(
                        color: AppColors.primary)),
                error:   (e, _) => Center(child: Text('$e')),
                data: (subs) => subs.isEmpty
                    ? const Center(
                        child: Text('لا توجد اشتراكات لهذا الشهر'))
                    : RefreshIndicator(
                        color: AppColors.primary,
                        onRefresh: () => ref.refresh(
                            _subsProvider(_SubsParams(_month, _year))
                                .future),
                        child: ListView.builder(
                          padding: const EdgeInsets.all(14),
                          itemCount: subs.length,
                          itemBuilder: (_, i) =>
                              _SubCard(
                            sub: subs[i],
                            onPay: () => _payDialog(subs[i]),
                          ),
                        ),
                      ),
              ),
              subState.when(
                loading: () => const Center(
                    child: CircularProgressIndicator(
                        color: AppColors.primary)),
                error:   (e, _) => Center(child: Text('$e')),
                data: (subs) {
                  final late = subs
                      .where((s) => s.status != 'paid')
                      .toList();
                  return late.isEmpty
                      ? const Center(
                          child: Text('🎉 الكل ملتزم!'))
                      : ListView.builder(
                          padding: const EdgeInsets.all(14),
                          itemCount: late.length,
                          itemBuilder: (_, i) => _SubCard(
                            sub: late[i],
                            onPay: () => _payDialog(late[i]),
                          ),
                        );
                },
              ),
            ],
          ),
        ),
      ]),
    );
  }

  Widget _metric(String v, String l, Color c) => Expanded(
        child: Column(children: [
          Text(v,
              style: TextStyle(
                  fontWeight: FontWeight.bold, color: c, fontSize: 13)),
          Text(l,
              style: const TextStyle(
                  fontSize: 10, color: AppColors.textSecondary)),
        ]),
      );

  Future<void> _runEngine() async {
    setState(() => _running = true);
    try {
      final res = await ref
          .read(runMonthlyEngineUseCaseProvider)
          .execute(_month, _year);
      if (!mounted) return;
      AppUI.showToast(context,
          '✅ تم إنشاء ${res['created']} اشتراك، تجاهل ${res['skipped']}');
      ref.invalidate(_subsProvider(_SubsParams(_month, _year)));
    } catch (e) {
      if (mounted) AppUI.showToast(context, 'خطأ: $e', isError: true);
    } finally {
      if (mounted) setState(() => _running = false);
    }
  }

  Future<void> _pickMonth() async {
    int m = _month, y = _year;
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('اختر الشهر'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
            IconButton(
                icon: const Icon(Icons.arrow_back_ios),
                onPressed: () {
                  if (m == 1) { m = 12; y--; } else { m--; }
                  Navigator.pop(ctx);
                  _pickMonth();
                }),
            StatefulBuilder(
              builder: (_, setS) => Text(
                '${['','يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'][m]} $y',
                style: const TextStyle(
                    fontWeight: FontWeight.bold, fontSize: 16),
              ),
            ),
            IconButton(
                icon: const Icon(Icons.arrow_forward_ios),
                onPressed: () {
                  if (m == 12) { m = 1; y++; } else { m++; }
                  Navigator.pop(ctx);
                  _pickMonth();
                }),
          ]),
        ]),
        actions: [
          ElevatedButton(
            onPressed: () {
              setState(() { _month = m; _year = y; });
              Navigator.pop(ctx);
            },
            child: const Text('تأكيد'),
          ),
        ],
      ),
    );
  }

  Future<void> _payDialog(Subscription sub) async {
    double amount = sub.remainingAmount;
    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('دفع اشتراك ${sub.studentName}'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Text('المتبقي: ${sub.remainingAmount.toStringAsFixed(0)} ج.م'),
          const SizedBox(height: 10),
          TextField(
            decoration: const InputDecoration(
                labelText: 'المبلغ',
                suffixText: 'ج.م'),
            keyboardType: TextInputType.number,
            controller: TextEditingController(
                text: sub.remainingAmount.toStringAsFixed(0)),
            onChanged: (v) =>
                amount = double.tryParse(v) ?? sub.remainingAmount,
          ),
        ]),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(ctx);
              try {
                final student = await ref
                    .read(studentRepositoryProvider)
                    .getStudentById(sub.studentId!);
                if (student == null) return;
                await ref
                    .read(paySubscriptionUseCaseProvider)
                    .execute(sub, amount, student);
                if (!mounted) return;
                AppUI.showToast(context,
                    '✅ تم تسجيل دفعة ${amount.toStringAsFixed(0)} ج.م');
                ref.invalidate(
                    _subsProvider(_SubsParams(_month, _year)));
              } catch (e) {
                if (mounted)
                  AppUI.showToast(context, 'خطأ: $e', isError: true);
              }
            },
            child: const Text('تأكيد'),
          ),
        ],
      ),
    );
  }
}

class _SubCard extends StatelessWidget {
  final Subscription sub;
  final VoidCallback onPay;
  const _SubCard({required this.sub, required this.onPay});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final statusColor = sub.status == 'paid'
        ? AppColors.success
        : sub.status == 'partial'
            ? AppColors.warning
            : AppColors.danger;

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: statusColor.withOpacity(0.2)),
      ),
      child: Column(children: [
        Row(children: [
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
                color: statusColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(11)),
            child: Center(
              child: Text(
                  sub.studentName.isNotEmpty
                      ? sub.studentName[0]
                      : '؟',
                  style: TextStyle(
                      color: statusColor, fontWeight: FontWeight.bold)),
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(sub.studentName,
                  style: const TextStyle(
                      fontWeight: FontWeight.bold, fontSize: 13)),
              Text(sub.groupName,
                  style: const TextStyle(
                      fontSize: 11, color: AppColors.textSecondary)),
            ]),
          ),
          Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
            decoration: BoxDecoration(
                color: statusColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20)),
            child: Text(sub.statusLabel,
                style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.bold,
                    color: statusColor)),
          ),
        ]),
        if (sub.status != 'paid') ...[
          const SizedBox(height: 10),
          Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
            Text(
                'المتبقي: ${sub.remainingAmount.toStringAsFixed(0)} ج',
                style: const TextStyle(
                    fontSize: 12, color: AppColors.textSecondary)),
            ElevatedButton(
              onPressed: onPay,
              style: ElevatedButton.styleFrom(
                  backgroundColor: statusColor,
                  padding: const EdgeInsets.symmetric(
                      horizontal: 14, vertical: 6),
                  textStyle: const TextStyle(fontSize: 12)),
              child: const Text('دفع',
                  style: TextStyle(color: Colors.white)),
            ),
          ]),
        ],
      ]),
    );
  }
}
