// lib/features/reports/reports_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/stat_card.dart';
import '../../core/widgets/shimmer_loading.dart';
import '../../core/utils/ui_helpers.dart';
import '../../domain/entities/student.dart';
import '../../core/providers/usecase_providers.dart';
import '../students/student_profile_screen.dart';
import 'providers/smart_insights_provider.dart';
import 'widgets/insight_card.dart';

final _reportProvider = FutureProvider<Map<String, dynamic>>((ref) =>
    ref.read(getSmartReportUseCaseProvider).execute());

class ReportsScreen extends ConsumerWidget {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final reportState   = ref.watch(_reportProvider);
    final insightState  = ref.watch(smartInsightsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('التقارير الذكية'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () {
              ref.invalidate(_reportProvider);
              ref.invalidate(smartInsightsProvider);
            },
          ),
        ],
      ),
      body: reportState.when(
        loading: () => const DashboardShimmer(),
        error:   (e, _) => Center(child: Text('خطأ: $e')),
        data: (data) => RefreshIndicator(
          color: AppColors.primary,
          onRefresh: () => ref.refresh(_reportProvider.future),
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [

              // ── Smart Insights ─────────────────────────────
              AppUI.fadeSlide(index: 0,
                child: const _SectionTitle(title: '🧠 رؤى ذكية'),
              ),
              const SizedBox(height: 8),
              insightState.when(
                loading: () => const SizedBox(height: 80,
                    child: Center(child: CircularProgressIndicator(
                        color: AppColors.primary))),
                error:   (_, __) => const SizedBox.shrink(),
                data: (insights) => Column(
                  children: insights.asMap().entries.map((e) =>
                    AppUI.fadeSlide(index: e.key, child: Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: _InsightBanner(insight: e.value),
                    ))
                  ).toList(),
                ),
              ),
              const SizedBox(height: 20),

              // ── Income Summary ──────────────────────────────
              AppUI.fadeSlide(index: 1,
                child: _IncomeCard(data: data),
              ),
              const SizedBox(height: 16),

              // ── Key Metrics ─────────────────────────────────
              AppUI.fadeSlide(index: 2,
                child: Row(children: [
                  StatCard(
                    title: 'إجمالي الطلاب',
                    value: '${data['totalStudents']}',
                    icon:  Icons.people_rounded,
                    color: AppColors.primary,
                  ),
                  const SizedBox(width: 10),
                  StatCard(
                    title: 'الديون',
                    value: '${(data['totalDebt'] as double).toStringAsFixed(0)} ج',
                    icon:  Icons.money_off_rounded,
                    color: AppColors.danger,
                  ),
                ]),
              ),
              const SizedBox(height: 20),

              // ── Best Attendance ─────────────────────────────
              const _SectionTitle(title: '🏆 أفضل حضور'),
              const SizedBox(height: 8),
              ...(data['bestAttendance'] as List).asMap().entries.map(
                (e) => AppUI.fadeSlide(
                  index: e.key + 3,
                  child: _AttendanceTile(
                    entry: e.value,
                    rank:  e.key,
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) =>
                            StudentProfileScreen(
                                student: e.value['student'] as Student))),
                  ),
                ),
              ),
              const SizedBox(height: 16),

              // ── Risk Students ───────────────────────────────
              if ((data['riskStudents'] as List).isNotEmpty) ...[
                const _SectionTitle(title: '⚠️ طلاب في خطر'),
                const SizedBox(height: 8),
                ...(data['riskStudents'] as List).asMap().entries.map(
                  (e) => AppUI.fadeSlide(
                    index: e.key + 6,
                    child: _RiskTile(entry: e.value),
                  ),
                ),
                const SizedBox(height: 16),
              ],

              // ── Most Absent ─────────────────────────────────
              const _SectionTitle(title: '📵 أكثر غياباً'),
              const SizedBox(height: 8),
              ...(data['mostAbsent'] as List).asMap().entries.map(
                (e) => AppUI.fadeSlide(
                  index: e.key + 9,
                  child: _AttendanceTile(
                    entry: e.value,
                    rank:  -1,
                    danger: true,
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) =>
                            StudentProfileScreen(
                                student: e.value['student'] as Student))),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── Insight Banner ─────────────────────────────────────────────

class _InsightBanner extends StatelessWidget {
  final SmartInsight insight;
  const _InsightBanner({required this.insight});

  Color get _color {
    switch (insight.type) {
      case InsightType.positive: return AppColors.success;
      case InsightType.warning:  return AppColors.warning;
      case InsightType.danger:   return AppColors.danger;
      case InsightType.info:     return AppColors.primary;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(color: _color.withOpacity(0.25)),
        boxShadow: [
          BoxShadow(color: _color.withOpacity(0.06),
              blurRadius: 8, offset: const Offset(0, 2))
        ],
      ),
      child: Row(children: [
        Container(
          width: 42, height: 42,
          decoration: BoxDecoration(
              color: _color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(11)),
          child: Center(child: Text(insight.emoji,
              style: const TextStyle(fontSize: 20))),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(insight.title,
              style: TextStyle(fontWeight: FontWeight.bold,
                  fontSize: 13, color: _color)),
          const SizedBox(height: 2),
          Text(insight.body,
              style: const TextStyle(
                  fontSize: 11, color: AppColors.textSecondary)),
        ])),
      ]),
    );
  }
}

// ── Income Card ───────────────────────────────────────────────

class _IncomeCard extends StatelessWidget {
  final Map<String, dynamic> data;
  const _IncomeCard({required this.data});

  @override
  Widget build(BuildContext context) {
    final rate = (data['collectionRate'] as double);
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
            colors: [AppColors.primary, AppColors.primaryLight]),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('💰 ملخص مالي الشهر',
            style: TextStyle(color: Colors.white,
                fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 12),
        Row(children: [
          _IncomePill('محصّل', '${(data['monthlyIncome'] as double).toStringAsFixed(0)} ج',
              AppColors.success),
          const SizedBox(width: 8),
          _IncomePill('متوقع', '${(data['expectedIncome'] as double).toStringAsFixed(0)} ج',
              Colors.white70),
          const SizedBox(width: 8),
          _IncomePill('نسبة التحصيل', '${rate.toStringAsFixed(0)}%',
              rate >= 70 ? AppColors.success : AppColors.warning),
        ]),
        const SizedBox(height: 10),
        ClipRRect(
          borderRadius: BorderRadius.circular(6),
          child: LinearProgressIndicator(
            value: (rate / 100).clamp(0.0, 1.0),
            backgroundColor: Colors.white.withOpacity(0.2),
            color: rate >= 70 ? AppColors.success : AppColors.warning,
            minHeight: 8,
          ),
        ),
      ]),
    );
  }
}

class _IncomePill extends StatelessWidget {
  final String label, value;
  final Color color;
  const _IncomePill(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) => Expanded(
    child: Column(children: [
      Text(value,
          style: TextStyle(fontWeight: FontWeight.bold, color: color, fontSize: 13)),
      Text(label,
          style: const TextStyle(fontSize: 10, color: Colors.white60)),
    ]),
  );
}

class _SectionTitle extends StatelessWidget {
  final String title;
  const _SectionTitle({required this.title});
  @override
  Widget build(BuildContext context) => Padding(
    padding: const EdgeInsets.only(bottom: 0),
    child: Text(title,
        style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
  );
}

class _AttendanceTile extends StatelessWidget {
  final Map<String, dynamic> entry;
  final int rank;
  final bool danger;
  final VoidCallback onTap;
  const _AttendanceTile({required this.entry, required this.rank,
      required this.onTap, this.danger = false});

  @override
  Widget build(BuildContext context) {
    final s     = entry['student'] as Student;
    final pct   = entry['percentage'] as double;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final color  = danger ? AppColors.danger : AppColors.success;
    final medals = ['🥇', '🥈', '🥉'];
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.borderLight),
        ),
        child: Row(children: [
          Text(rank >= 0 && rank < 3 ? medals[rank] : (danger ? '❌' : '✅'),
              style: const TextStyle(fontSize: 18)),
          const SizedBox(width: 10),
          Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s.name,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            Text(s.groupName,
                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
          ])),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
            decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(20)),
            child: Text('${pct.toStringAsFixed(0)}%',
                style: TextStyle(fontSize: 12,
                    fontWeight: FontWeight.bold, color: color)),
          ),
        ]),
      ),
    );
  }
}

class _RiskTile extends StatelessWidget {
  final Map<String, dynamic> entry;
  const _RiskTile({required this.entry});

  @override
  Widget build(BuildContext context) {
    final s    = entry['student'] as Student;
    final risk = entry['risk'] as String;
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final color  = risk == 'خطر' ? AppColors.danger : AppColors.warning;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(children: [
        Container(
          width: 38, height: 38,
          decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(10)),
          child: Center(child: Text(s.displayInitial,
              style: TextStyle(color: color, fontWeight: FontWeight.bold))),
        ),
        const SizedBox(width: 10),
        Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(s.name,
              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
          Text('رصيد: ${s.balance.toStringAsFixed(0)} ج.م',
              style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
        ])),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
          decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20)),
          child: Text(risk,
              style: TextStyle(fontSize: 11,
                  fontWeight: FontWeight.bold, color: color)),
        ),
      ]),
    );
  }
}
