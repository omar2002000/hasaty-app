// lib/features/reports/providers/smart_insights_provider.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../domain/entities/student.dart';
import '../../../providers/global_providers.dart';

class SmartInsight {
  final String emoji;
  final String title;
  final String body;
  final InsightType type;
  const SmartInsight({required this.emoji, required this.title,
      required this.body, required this.type});
}

enum InsightType { positive, warning, danger, info }

final smartInsightsProvider =
    FutureProvider<List<SmartInsight>>((ref) async {
  final students = await ref.read(studentRepositoryProvider).getStudents();
  final payments = await ref.read(financeRepositoryProvider).getAllPayments();
  final now      = DateTime.now();
  final subs     = await ref.read(financeRepositoryProvider)
      .getSubscriptions(month: now.month, year: now.year);

  final insights = <SmartInsight>[];

  if (students.isEmpty) return insights;

  // 1. Top performer
  final sorted = [...students]..sort((a, b) => b.xp.compareTo(a.xp));
  if (sorted.isNotEmpty) {
    insights.add(SmartInsight(
      emoji: '🏆', type: InsightType.positive,
      title: 'نجم الفصل هذا الأسبوع',
      body:  '${sorted.first.name} بـ ${sorted.first.xp} نقطة XP',
    ));
  }

  // 2. Debt analysis
  final debtStudents = students.where((s) => s.balance < 0).toList();
  final totalDebt = debtStudents.fold<double>(0, (s, st) => s + st.balance.abs());
  if (debtStudents.isNotEmpty) {
    insights.add(SmartInsight(
      emoji: '💸', type: InsightType.danger,
      title: '${debtStudents.length} طالب عليهم ديون',
      body:  'إجمالي الديون المتراكمة: ${totalDebt.toStringAsFixed(0)} ج.م',
    ));
  }

  // 3. Collection rate
  final expected = subs.fold<double>(0, (s, x) => s + x.amount);
  final suffix   = '/${now.month}/${now.year}';
  final actual   = payments.where((p) => p.date.endsWith(suffix))
      .fold<double>(0, (s, p) => s + p.amount);
  if (expected > 0) {
    final rate = actual / expected * 100;
    insights.add(SmartInsight(
      emoji: rate >= 70 ? '✅' : '⚠️',
      type:  rate >= 70 ? InsightType.positive : InsightType.warning,
      title: 'نسبة تحصيل ${rate.toStringAsFixed(0)}%',
      body:  '${actual.toStringAsFixed(0)} ج من أصل ${expected.toStringAsFixed(0)} ج متوقعة',
    ));
  }

  // 4. XP level distribution
  final beginners = students.where((s) => s.xp < 50).length;
  final advanced  = students.where((s) => s.xp >= 200).length;
  if (beginners > students.length * 0.5) {
    insights.add(SmartInsight(
      emoji: '📚', type: InsightType.info,
      title: 'معظم الطلاب في المستوى المبتدئ',
      body:  '$beginners طالب لم يتجاوزوا 50 XP بعد — شجّعهم!',
    ));
  }
  if (advanced > 0) {
    insights.add(SmartInsight(
      emoji: '🔥', type: InsightType.positive,
      title: '$advanced طالب في مستوى متقدم أو أعلى',
      body:  'هؤلاء الطلاب يستحقون التقدير العلني',
    ));
  }

  // 5. New students this month (joined in current month)
  final newThisMonth = students.where((s) {
    try {
      final parts = s.joinDate.split('/');
      return int.parse(parts[1]) == now.month &&
             int.parse(parts[2]) == now.year;
    } catch (_) { return false; }
  }).length;
  if (newThisMonth > 0) {
    insights.add(SmartInsight(
      emoji: '🌱', type: InsightType.positive,
      title: '$newThisMonth طالب جديد هذا الشهر',
      body:  'رحّب بهم وأضف اشتراكاتهم',
    ));
  }

  // 6. Risk prediction
  final criticalCount = debtStudents.where((s) => s.balance <= -200).length;
  if (criticalCount > 0) {
    insights.add(SmartInsight(
      emoji: '🚨', type: InsightType.danger,
      title: 'تنبيه: $criticalCount طالب في خطر مالي حاد',
      body:  'رصيدهم أقل من -200 ج — تواصل مع أولياء أمورهم فوراً',
    ));
  }

  return insights;
});
