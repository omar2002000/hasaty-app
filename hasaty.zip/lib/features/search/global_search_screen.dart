// lib/features/search/global_search_screen.dart
// Stage 6B — Global fast search.
// Searches all non-archived students by name / phone / group.
// Uses existing studentsNotifierProvider (already in memory via keepAlive).
// Navigates to StudentProfileScreen on tap.

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../domain/entities/student.dart';
import '../students/providers/students_notifier.dart';
import '../students/student_profile_screen.dart';

class GlobalSearchScreen extends ConsumerStatefulWidget {
  const GlobalSearchScreen({super.key});

  @override
  ConsumerState<GlobalSearchScreen> createState() =>
      _GlobalSearchScreenState();
}

class _GlobalSearchScreenState extends ConsumerState<GlobalSearchScreen> {
  final _ctrl  = TextEditingController();
  String _query = '';

  @override
  void initState() {
    super.initState();
    // Auto-focus keyboard on open
    WidgetsBinding.instance.addPostFrameCallback((_) =>
        FocusScope.of(context).requestFocus(_focus));
  }

  final _focus = FocusNode();

  @override
  void dispose() {
    _ctrl.dispose();
    _focus.dispose();
    super.dispose();
  }

  List<Student> _filter(List<Student> students) {
    if (_query.trim().isEmpty) return [];
    final q = _query.trim().toLowerCase();
    return students.where((s) =>
        !s.archived && (
            s.name.toLowerCase().contains(q) ||
            s.phone.contains(q) ||
            s.groupName.toLowerCase().contains(q)
        )).toList();
  }

  @override
  Widget build(BuildContext context) {
    final allState = ref.watch(studentsNotifierProvider);

    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        title: TextField(
          controller:  _ctrl,
          focusNode:   _focus,
          autofocus:   true,
          onChanged:   (v) => setState(() => _query = v),
          style: const TextStyle(color: Colors.white, fontSize: 15),
          decoration: const InputDecoration(
            hintText:     'ابحث عن طالب...',
            hintStyle:    TextStyle(color: Colors.white54),
            border:       InputBorder.none,
            prefixIcon:   Icon(Icons.search, color: Colors.white70),
          ),
        ),
        actions: [
          if (_query.isNotEmpty)
            IconButton(
              icon: const Icon(Icons.clear),
              onPressed: () {
                _ctrl.clear();
                setState(() => _query = '');
              },
            ),
        ],
      ),
      body: allState.when(
        loading: () => const Center(
            child: CircularProgressIndicator(color: AppColors.primary)),
        error:   (e, _) => Center(child: Text('$e')),
        data: (students) {
          final results = _filter(students);

          // Empty state
          if (_query.trim().isEmpty) {
            return const Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.search_rounded, size: 64,
                      color: AppColors.textSecondary),
                  SizedBox(height: 12),
                  Text('ابدأ الكتابة للبحث',
                      style: TextStyle(color: AppColors.textSecondary,
                          fontSize: 15)),
                  SizedBox(height: 4),
                  Text('يمكنك البحث بالاسم أو الهاتف أو المجموعة',
                      style: TextStyle(color: AppColors.textSecondary,
                          fontSize: 11)),
                ],
              ),
            );
          }

          if (results.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  const Icon(Icons.person_search_rounded,
                      size: 56, color: AppColors.textSecondary),
                  const SizedBox(height: 12),
                  Text('لا يوجد نتيجة لـ "$_query"',
                      style: const TextStyle(
                          color: AppColors.textSecondary, fontSize: 14)),
                ],
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: results.length,
            itemBuilder: (_, i) {
              final s     = results[i];
              final isDark = Theme.of(context).brightness == Brightness.dark;
              // Highlight matched text
              final q = _query.trim().toLowerCase();

              return GestureDetector(
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) =>
                        StudentProfileScreen(student: s))),
                child: Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(13),
                  decoration: BoxDecoration(
                    color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
                    borderRadius: BorderRadius.circular(13),
                    border: Border.all(color: AppColors.borderLight),
                  ),
                  child: Row(children: [
                    Container(
                      width: 42, height: 42,
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                            colors: [AppColors.primary, AppColors.primaryLight]),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Center(child: Text(s.displayInitial,
                          style: const TextStyle(color: Colors.white,
                              fontWeight: FontWeight.bold, fontSize: 17))),
                    ),
                    const SizedBox(width: 12),
                    Expanded(child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      _highlight(s.name, q),
                      const SizedBox(height: 2),
                      Row(children: [
                        _highlightSmall(s.groupName, q),
                        if (s.phone.contains(q) && q.isNotEmpty) ...[
                          const Text(' • ',
                              style: TextStyle(color: AppColors.textSecondary)),
                          Text(s.phone,
                              style: const TextStyle(fontSize: 11,
                                  color: AppColors.textSecondary)),
                        ],
                      ]),
                    ])),
                    Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 2),
                        decoration: BoxDecoration(
                            color: (s.balance >= 0
                                ? AppColors.success : AppColors.danger)
                                .withOpacity(0.1),
                            borderRadius: BorderRadius.circular(20)),
                        child: Text(
                          '${s.balance >= 0 ? '+' : ''}${s.balance.toStringAsFixed(0)} ج',
                          style: TextStyle(fontSize: 10,
                              fontWeight: FontWeight.bold,
                              color: s.balance >= 0
                                  ? AppColors.success : AppColors.danger),
                        ),
                      ),
                      const SizedBox(height: 3),
                      Text('${s.xp} XP',
                          style: const TextStyle(fontSize: 9,
                              color: AppColors.textSecondary)),
                    ]),
                  ]),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Widget _highlight(String text, String query) {
    if (query.isEmpty || !text.toLowerCase().contains(query)) {
      return Text(text,
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14));
    }
    final idx   = text.toLowerCase().indexOf(query);
    final before = text.substring(0, idx);
    final match  = text.substring(idx, idx + query.length);
    final after  = text.substring(idx + query.length);
    return RichText(
      text: TextSpan(
        style: const TextStyle(fontWeight: FontWeight.bold,
            fontSize: 14, color: Colors.black87),
        children: [
          TextSpan(text: before),
          TextSpan(text: match,
              style: const TextStyle(color: AppColors.primary,
                  backgroundColor: Color(0x1A1E3A8A))),
          TextSpan(text: after),
        ],
      ),
    );
  }

  Widget _highlightSmall(String text, String query) {
    if (query.isEmpty || !text.toLowerCase().contains(query)) {
      return Text(text,
          style: const TextStyle(fontSize: 11,
              color: AppColors.textSecondary));
    }
    return Text(text,
        style: const TextStyle(fontSize: 11,
            color: AppColors.primary, fontWeight: FontWeight.bold));
  }
}
