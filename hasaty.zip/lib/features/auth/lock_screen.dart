// lib/features/auth/lock_screen.dart
// ─────────────────────────────────────────────────────────────
// Stage 7 — App lock screen.
//
// Shows a 4-digit PIN keypad. If lock type is 'biometric',
// the biometric prompt fires automatically on open and a
// fingerprint button is shown as a shortcut.
//
// Behaviour:
//   • Auto-submits when 4th digit is entered
//   • Shake animation on wrong PIN
//   • Biometric fallback to PIN
//   • Calls onUnlocked() callback on success (no Navigator.pop —
//     the parent decides the transition)
// ─────────────────────────────────────────────────────────────

import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../../core/theme/app_colors.dart';
import '../../core/security/auth_service.dart';

class LockScreen extends StatefulWidget {
  /// Called when user successfully unlocks the app.
  final VoidCallback onUnlocked;

  const LockScreen({super.key, required this.onUnlocked});

  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen>
    with SingleTickerProviderStateMixin {
  String _entered    = '';
  bool   _error      = false;
  bool   _checking   = false;
  String _errorMsg   = '';

  late AnimationController _shakeCtrl;
  late Animation<double>   _shakeAnim;

  @override
  void initState() {
    super.initState();

    _shakeCtrl = AnimationController(
      vsync:    this,
      duration: const Duration(milliseconds: 400),
    );
    _shakeAnim = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(parent: _shakeCtrl, curve: Curves.elasticIn),
    );

    // Auto-trigger biometric if that's the lock type
    WidgetsBinding.instance.addPostFrameCallback((_) => _tryBiometric());
  }

  @override
  void dispose() {
    _shakeCtrl.dispose();
    super.dispose();
  }

  // ── Biometric ─────────────────────────────────────────────────

  Future<void> _tryBiometric() async {
    final type = await AuthService.instance.lockType;
    if (type != 'biometric') return;
    final ok = await AuthService.instance.authenticateWithBiometric();
    if (ok && mounted) {
      HapticFeedback.mediumImpact();
      widget.onUnlocked();
    }
  }

  // ── PIN entry ─────────────────────────────────────────────────

  void _onDigit(String d) {
    if (_checking || _entered.length >= 4) return;
    setState(() {
      _entered += d;
      _error    = false;
      _errorMsg = '';
    });
    if (_entered.length == 4) _verifyPin();
  }

  void _onDelete() {
    if (_checking || _entered.isEmpty) return;
    setState(() => _entered = _entered.substring(0, _entered.length - 1));
  }

  Future<void> _verifyPin() async {
    setState(() => _checking = true);
    final ok = await AuthService.instance.verifyPin(_entered);
    if (!mounted) return;

    if (ok) {
      HapticFeedback.mediumImpact();
      widget.onUnlocked();
    } else {
      HapticFeedback.heavyImpact();
      setState(() {
        _error    = true;
        _errorMsg = 'الرقم السري غير صحيح';
        _entered  = '';
        _checking = false;
      });
      _shakeCtrl.forward(from: 0.0);
    }
  }

  // ── Build ─────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.primary,
      body: SafeArea(
        child: Column(
          children: [
            const SizedBox(height: 60),

            // App logo
            Container(
              width: 72, height: 72,
              decoration: BoxDecoration(
                color: Colors.white.withOpacity(0.15),
                borderRadius: BorderRadius.circular(20),
              ),
              child: const Center(
                child: Text('ح',
                    style: TextStyle(color: Colors.white, fontSize: 36,
                        fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(height: 16),
            const Text('حصتي', style: TextStyle(color: Colors.white,
                fontSize: 22, fontWeight: FontWeight.bold)),
            const SizedBox(height: 6),
            const Text('أدخل رقم السري',
                style: TextStyle(color: Colors.white70, fontSize: 14)),
            const SizedBox(height: 48),

            // PIN dots with shake animation
            AnimatedBuilder(
              animation: _shakeAnim,
              builder: (_, child) {
                final offset = sin(_shakeAnim.value * pi * 6) * 14.0;
                return Transform.translate(
                  offset: Offset(offset, 0),
                  child: child,
                );
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: List.generate(4, (i) {
                  final filled = i < _entered.length;
                  return AnimatedContainer(
                    duration: const Duration(milliseconds: 150),
                    margin: const EdgeInsets.symmetric(horizontal: 10),
                    width:  16, height: 16,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: filled ? Colors.white : Colors.transparent,
                      border: Border.all(
                        color: _error ? AppColors.danger : Colors.white,
                        width: 2,
                      ),
                    ),
                  );
                }),
              ),
            ),

            // Error message
            const SizedBox(height: 16),
            AnimatedOpacity(
              opacity: _error ? 1.0 : 0.0,
              duration: const Duration(milliseconds: 200),
              child: Text(_errorMsg,
                  style: const TextStyle(color: AppColors.danger,
                      fontSize: 13, fontWeight: FontWeight.bold)),
            ),

            const Spacer(),

            // Keypad
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 40),
              child: Column(
                children: [
                  _keyRow(['1', '2', '3']),
                  const SizedBox(height: 14),
                  _keyRow(['4', '5', '6']),
                  const SizedBox(height: 14),
                  _keyRow(['7', '8', '9']),
                  const SizedBox(height: 14),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      // Biometric shortcut
                      _BiometricBtn(onTap: _tryBiometric),
                      _DigitBtn(label: '0', onTap: () => _onDigit('0')),
                      _DeleteBtn(onTap: _onDelete),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }

  Widget _keyRow(List<String> digits) => Row(
    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    children: digits.map((d) =>
        _DigitBtn(label: d, onTap: () => _onDigit(d))).toList(),
  );
}

// ── Keypad widgets ────────────────────────────────────────────

class _DigitBtn extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _DigitBtn({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: 72, height: 72,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.12),
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white.withOpacity(0.2)),
      ),
      child: Center(child: Text(label,
          style: const TextStyle(color: Colors.white, fontSize: 26,
              fontWeight: FontWeight.w500))),
    ),
  );
}

class _DeleteBtn extends StatelessWidget {
  final VoidCallback onTap;
  const _DeleteBtn({required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: Container(
      width: 72, height: 72,
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.08),
        shape: BoxShape.circle,
      ),
      child: const Center(child: Icon(Icons.backspace_outlined,
          color: Colors.white70, size: 24)),
    ),
  );
}

class _BiometricBtn extends StatelessWidget {
  final VoidCallback onTap;
  const _BiometricBtn({required this.onTap});

  @override
  Widget build(BuildContext context) => FutureBuilder<bool>(
    future: AuthService.instance.isBiometricAvailable,
    builder: (_, snap) {
      if (snap.data != true) {
        return const SizedBox(width: 72, height: 72);
      }
      return GestureDetector(
        onTap: onTap,
        child: Container(
          width: 72, height: 72,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.08),
            shape: BoxShape.circle,
          ),
          child: const Center(child: Icon(Icons.fingerprint,
              color: Colors.white70, size: 28)),
        ),
      );
    },
  );
}
