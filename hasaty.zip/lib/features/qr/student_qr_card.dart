// lib/features/qr/student_qr_card.dart
// ─────────────────────────────────────────────────────────────
// Stage 1B — QR card bottom sheet.
//
// Features:
//   • Shows student QR code in a card layout
//   • Share as PNG (captures widget via RepaintBoundary)
//   • Export as PDF (QrExportService)
//   • Print (system dialog via printing package)
//
// Lazy token fix:
//   If student.qrToken is empty (legacy row migrated from v1),
//   _ensureQrToken() generates + persists the token on first open.
//   Subsequent opens use the stored value — no double-writes.
// ─────────────────────────────────────────────────────────────

import 'dart:io';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import 'package:printing/printing.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import '../../core/theme/app_colors.dart';
import '../../domain/entities/student.dart';
import '../../providers/global_providers.dart';
import 'qr_export_service.dart';
import 'qr_token_generator.dart';

class StudentQrSheet extends ConsumerWidget {
  final Student student;
  const StudentQrSheet({super.key, required this.student});

  static void show(BuildContext context, Student student) {
    showModalBottomSheet(
      context:          context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_)     => StudentQrSheet(student: student),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return DraggableScrollableSheet(
      initialChildSize: 0.82,
      maxChildSize:     0.95,
      minChildSize:     0.5,
      expand: false,
      builder: (_, controller) => Container(
        decoration: BoxDecoration(
          color: Theme.of(context).brightness == Brightness.dark
              ? AppColors.bgCardDark : Colors.white,
          borderRadius:
              const BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(children: [
          // Drag handle
          Container(
            margin: const EdgeInsets.only(top: 12, bottom: 8),
            width: 40, height: 4,
            decoration: BoxDecoration(
              color: AppColors.borderLight,
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          Expanded(
            child: SingleChildScrollView(
              controller: controller,
              padding: const EdgeInsets.all(24),
              child: _QrCardContent(student: student),
            ),
          ),
        ]),
      ),
    );
  }
}

// ─── QR card content ─────────────────────────────────────────

class _QrCardContent extends ConsumerStatefulWidget {
  final Student student;
  const _QrCardContent({required this.student});

  @override
  ConsumerState<_QrCardContent> createState() => _QrCardContentState();
}

class _QrCardContentState extends ConsumerState<_QrCardContent> {
  final GlobalKey _cardKey = GlobalKey();
  bool _exporting = false;

  late Student _student;

  @override
  void initState() {
    super.initState();
    _student = widget.student;
    // Trigger lazy token generation for legacy students (non-blocking)
    if (!_student.hasQrToken) {
      WidgetsBinding.instance
          .addPostFrameCallback((_) => _ensureQrToken());
    }
  }

  /// Generates + persists token for existing students that predate Stage 1A.
  /// Called once. All subsequent opens use the stored token.
  Future<void> _ensureQrToken() async {
    if (_student.id == null) return;
    final token   = QrTokenGenerator.generate(_student.id!);
    final updated = _student.copyWith(qrToken: token);

    // Persist via repository (single UPDATE — no side effects)
    await ref.read(studentRepositoryProvider).updateStudent(updated);

    if (mounted) setState(() => _student = updated);
  }

  /// QR data used in the image.
  /// Uses stored token when available; falls back to deterministic value
  /// while the async persist is still in flight.
  String get _qrData => _student.hasQrToken
      ? _student.qrToken
      : QrTokenGenerator.generate(_student.id ?? 0);

  @override
  Widget build(BuildContext context) {
    return Column(children: [
      const Text('كود QR الطالب',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      const SizedBox(height: 4),
      const Text('امسح هذا الكود لتسجيل الحضور',
          style: TextStyle(fontSize: 12, color: AppColors.textSecondary)),
      const SizedBox(height: 24),

      // ── QR Card ─────────────────────────────────────────────
      RepaintBoundary(
        key: _cardKey,
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            boxShadow: [
              BoxShadow(color: Colors.black.withOpacity(0.08),
                  blurRadius: 16, offset: const Offset(0, 4)),
            ],
          ),
          child: Column(children: [
            // Logo row
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Container(
                width: 28, height: 28,
                decoration: BoxDecoration(
                    color: AppColors.primary,
                    borderRadius: BorderRadius.circular(8)),
                child: const Center(child: Text('ح',
                    style: TextStyle(color: Colors.white,
                        fontSize: 14, fontWeight: FontWeight.bold))),
              ),
              const SizedBox(width: 8),
              const Text('حصتي',
                  style: TextStyle(color: AppColors.primary,
                      fontWeight: FontWeight.bold, fontSize: 16)),
            ]),
            const SizedBox(height: 16),

            // QR image — H error-correction for maximum scan reliability
            QrImageView(
              data:                 _qrData,
              size:                 200,
              errorCorrectionLevel: QrErrorCorrectLevel.H,
              backgroundColor:      Colors.white,
              eyeStyle: const QrEyeStyle(
                  eyeShape: QrEyeShape.square, color: Colors.black),
              dataModuleStyle: const QrDataModuleStyle(
                  dataModuleShape: QrDataModuleShape.square,
                  color: Colors.black),
            ),
            const SizedBox(height: 16),

            // Student info
            Text(_student.name,
                style: const TextStyle(fontWeight: FontWeight.bold,
                    fontSize: 16, color: Colors.black87),
                textAlign: TextAlign.center),
            const SizedBox(height: 4),
            Text(_student.groupName,
                style: const TextStyle(fontSize: 12, color: Colors.black54),
                textAlign: TextAlign.center),
            const SizedBox(height: 6),

            // Token pill
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                  color: Colors.grey.shade100,
                  borderRadius: BorderRadius.circular(20)),
              child: Text(_qrData,
                  style: const TextStyle(
                      fontFamily: 'monospace', fontSize: 10,
                      color: Colors.black54)),
            ),
          ]),
        ),
      ),
      const SizedBox(height: 28),

      // ── Action buttons ───────────────────────────────────────
      if (_exporting)
        const Padding(
          padding: EdgeInsets.symmetric(vertical: 16),
          child: CircularProgressIndicator(color: AppColors.primary),
        )
      else ...[
        // 1. Share as PNG
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            icon:  const Icon(Icons.share_rounded),
            label: const Text('مشاركة كصورة PNG'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: () => _shareAsPng(context),
          ),
        ),
        const SizedBox(height: 10),

        // 2. Export as PDF
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            icon:  const Icon(Icons.picture_as_pdf_rounded),
            label: const Text('تصدير PDF'),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.primary,
              side: const BorderSide(color: AppColors.primary),
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: () => _exportAsPdf(context),
          ),
        ),
        const SizedBox(height: 10),

        // 3. Print
        SizedBox(
          width: double.infinity,
          child: OutlinedButton.icon(
            icon:  const Icon(Icons.print_rounded),
            label: const Text('طباعة'),
            style: OutlinedButton.styleFrom(
              foregroundColor: AppColors.accent,
              side: const BorderSide(color: AppColors.accent),
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: () => _printCard(context),
          ),
        ),
      ],
    ]);
  }

  // ─── PNG — capture widget via RepaintBoundary ─────────────────

  Future<void> _shareAsPng(BuildContext context) async {
    setState(() => _exporting = true);
    try {
      final boundary = _cardKey.currentContext!.findRenderObject()
          as RenderRepaintBoundary;
      final image    = await boundary.toImage(pixelRatio: 3.0);
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      if (byteData == null) throw Exception('فشل التقاط الصورة');
      final bytes = byteData.buffer.asUint8List();

      final dir  = await getTemporaryDirectory();
      final file = File(
          '${dir.path}/QR_${_student.id}_${_student.name.replaceAll(' ', '_')}.png');
      await file.writeAsBytes(bytes);

      await Share.shareXFiles(
        [XFile(file.path, mimeType: 'image/png')],
        text: 'كود QR الخاص بـ ${_student.name}',
      );
    } catch (e) {
      if (context.mounted) _showError(context, 'خطأ في التصدير: $e');
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  // ─── PDF — via QrExportService ────────────────────────────────

  Future<void> _exportAsPdf(BuildContext context) async {
    setState(() => _exporting = true);
    try {
      await QrExportService.exportStudentCard(_student);
    } catch (e) {
      if (context.mounted) _showError(context, 'خطأ في PDF: $e');
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  // ─── Print — system dialog via printing package ───────────────

  Future<void> _printCard(BuildContext context) async {
    setState(() => _exporting = true);
    try {
      final bytes = await QrExportService.buildStudentCardBytes(_student);
      await Printing.layoutPdf(
        onLayout: (_) async => bytes,
        name: 'QR Card — ${_student.name}',
      );
    } catch (e) {
      if (context.mounted) _showError(context, 'خطأ في الطباعة: $e');
    } finally {
      if (mounted) setState(() => _exporting = false);
    }
  }

  void _showError(BuildContext context, String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: AppColors.danger,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
