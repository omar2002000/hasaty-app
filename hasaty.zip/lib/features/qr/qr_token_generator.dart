// lib/features/qr/qr_token_generator.dart
// ─────────────────────────────────────────────────────────────
// Pure Dart utility — zero Flutter/DB dependencies.
// Single responsibility: generate & parse HASATY QR tokens.
//
// Token format: 'HASATY-{studentId}'
//   • Prefix guards against accidental false matches
//   • Deterministic — same studentId always produces same token
//   • Backward-compatible parser handles legacy plain-int format
// ─────────────────────────────────────────────────────────────

class QrTokenGenerator {
  static const String _prefix = 'HASATY-';

  /// Generates a unique QR token for [studentId].
  /// Called once after DB insert returns the real ID.
  static String generate(int studentId) => '$_prefix$studentId';

  /// Parses a student ID from any supported QR format:
  ///   • 'HASATY-42'      → 42   (current format)
  ///   • 'HASATY-42-xyz'  → 42   (future extended format)
  ///   • '42'             → 42   (legacy plain-int format)
  ///
  /// Returns null if the value cannot be parsed.
  static int? parseStudentId(String raw) {
    final trimmed = raw.trim();

    if (trimmed.startsWith(_prefix)) {
      final remainder = trimmed.substring(_prefix.length);
      final idPart    = remainder.split('-').first;
      return int.tryParse(idPart);
    }

    return int.tryParse(trimmed);
  }

  static bool isValid(String raw) => parseStudentId(raw) != null;
}
