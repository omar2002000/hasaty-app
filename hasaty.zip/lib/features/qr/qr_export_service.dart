// lib/features/qr/qr_export_service.dart
// ─────────────────────────────────────────────────────────────
// Stage 1B — PDF card export.
//
// Public methods:
//   exportStudentCard      — builds PDF and opens share sheet
//   buildStudentCardBytes  — returns raw bytes (used by print dialog)
//
// Both use _buildPdf() internally — single source of truth.
// No widget tree required — uses QrPainter for off-screen render.
// ─────────────────────────────────────────────────────────────

import 'dart:io';
import 'dart:typed_data';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:qr_flutter/qr_flutter.dart';
import 'package:share_plus/share_plus.dart';
import '../../domain/entities/student.dart';
import 'qr_token_generator.dart';

class QrExportService {

  // ── Share PDF via system share sheet ─────────────────────────

  static Future<void> exportStudentCard(Student student) async {
    final bytes = await buildStudentCardBytes(student);
    final dir   = await getTemporaryDirectory();
    final file  = File(
      '${dir.path}/QR_Card_${student.id}_${student.name.replaceAll(' ', '_')}.pdf',
    );
    await file.writeAsBytes(bytes);
    await Share.shareXFiles(
      [XFile(file.path, mimeType: 'application/pdf')],
      subject: 'كارت QR — ${student.name}',
    );
  }

  // ── Return raw PDF bytes (used by printing package) ───────────

  static Future<Uint8List> buildStudentCardBytes(Student student) async {
    final pdf = await _buildPdf(student);
    return pdf.save();
  }

  // ── Build pw.Document ────────────────────────────────────────

  static Future<pw.Document> _buildPdf(Student student) async {
    final qrData = student.hasQrToken
        ? student.qrToken
        : QrTokenGenerator.generate(student.id ?? 0);

    // Render QR to PNG bytes off-screen (no widget tree)
    final qrPainter = QrPainter(
      data:                 qrData,
      version:              QrVersions.auto,
      errorCorrectionLevel: QrErrorCorrectLevel.H,
      gapless:              false,
    );
    final qrImageData = await qrPainter.toImageData(512.0);
    if (qrImageData == null) throw Exception('QR render failed');
    final qrBytes = qrImageData.buffer.asUint8List();

    final pdf     = pw.Document(compress: true);
    final qrImage = pw.MemoryImage(qrBytes);

    pdf.addPage(pw.Page(
      pageFormat: PdfPageFormat.a6,
      margin:     const pw.EdgeInsets.all(24),
      build: (pw.Context ctx) => pw.Column(
        mainAxisAlignment:  pw.MainAxisAlignment.center,
        crossAxisAlignment: pw.CrossAxisAlignment.center,
        children: [
          // App header
          pw.Container(
            padding: const pw.EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: pw.BoxDecoration(
              color:        PdfColor.fromHex('#1E3A8A'),
              borderRadius: pw.BorderRadius.circular(8),
            ),
            child: pw.Text(
              'حصتي — Hasaty',
              style: pw.TextStyle(
                color: PdfColors.white, fontSize: 14,
                fontWeight: pw.FontWeight.bold,
              ),
            ),
          ),
          pw.SizedBox(height: 16),

          // QR code
          pw.Image(qrImage, width: 160, height: 160),
          pw.SizedBox(height: 12),

          // Student name
          pw.Text(student.name,
              style: pw.TextStyle(fontSize: 16,
                  fontWeight: pw.FontWeight.bold, color: PdfColors.black),
              textAlign: pw.TextAlign.center),
          pw.SizedBox(height: 4),

          // Group
          pw.Text(student.groupName,
              style: const pw.TextStyle(fontSize: 11, color: PdfColors.grey),
              textAlign: pw.TextAlign.center),
          pw.SizedBox(height: 8),

          // Token code pill
          pw.Container(
            padding: const pw.EdgeInsets.symmetric(horizontal: 12, vertical: 4),
            decoration: pw.BoxDecoration(
              color: PdfColors.grey200,
              borderRadius: pw.BorderRadius.circular(20),
            ),
            child: pw.Text(qrData,
                style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey700)),
          ),
          pw.SizedBox(height: 12),

          // Footer
          pw.Text('امسح هذا الكود لتسجيل الحضور',
              style: const pw.TextStyle(fontSize: 9, color: PdfColors.grey)),
        ],
      ),
    ));

    return pdf;
  }
}
