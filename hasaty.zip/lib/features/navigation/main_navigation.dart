// lib/features/navigation/main_navigation.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../dashboard/dashboard_screen.dart';
import '../students/screens/students_screen.dart';
import '../finance/subscription_screen.dart';
import '../reports/reports_screen.dart';
import '../settings/settings_screen.dart';
import '../search/global_search_screen.dart'; // Stage 6B
import '../analytics/analytics_screen.dart'; // Stage 9

class MainNavigation extends ConsumerStatefulWidget {
  const MainNavigation({super.key});

  @override
  ConsumerState<MainNavigation> createState() => _MainNavigationState();
}

class _MainNavigationState extends ConsumerState<MainNavigation> {
  int _index = 0;

  static const _screens = [
    DashboardScreen(),
    StudentsScreen(),
    SubscriptionScreen(),
    ReportsScreen(),
    SettingsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: IndexedStack(index: _index, children: _screens),
      // Stage 6B: search FAB on home/students; analytics FAB on reports tab
      floatingActionButton: _index == 3
          ? FloatingActionButton.small(
              heroTag: 'analytics_fab',
              backgroundColor: AppColors.purple,
              tooltip: 'التحليلات المتقدمة',
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const AnalyticsScreen())),
              child: const Icon(Icons.insights_rounded, color: Colors.white),
            )
          : (_index == 0 || _index == 1
          ? FloatingActionButton.small(
              heroTag: 'search_fab',
              backgroundColor: AppColors.primary,
              tooltip: 'بحث سريع',
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(
                      builder: (_) => const GlobalSearchScreen(),
                      fullscreenDialog: true)),
              child: const Icon(Icons.search_rounded, color: Colors.white),
            )
          : null,
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: (i) => setState(() => _index = i),
        backgroundColor: Theme.of(context).brightness == Brightness.dark
            ? AppColors.bgCardDark
            : AppColors.bgCard,
        indicatorColor: AppColors.primary.withOpacity(0.15),
        labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
        destinations: const [
          NavigationDestination(
            icon:         Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded, color: AppColors.primary),
            label:        'الرئيسية',
          ),
          NavigationDestination(
            icon:         Icon(Icons.people_outline),
            selectedIcon: Icon(Icons.people_rounded, color: AppColors.primary),
            label:        'الطلاب',
          ),
          NavigationDestination(
            icon:         Icon(Icons.payments_outlined),
            selectedIcon: Icon(Icons.payments_rounded, color: AppColors.primary),
            label:        'الاشتراكات',
          ),
          NavigationDestination(
            icon:         Icon(Icons.bar_chart_outlined),
            selectedIcon: Icon(Icons.bar_chart_rounded, color: AppColors.primary),
            label:        'التقارير',
          ),
          NavigationDestination(
            icon:         Icon(Icons.settings_outlined),
            selectedIcon: Icon(Icons.settings_rounded, color: AppColors.primary),
            label:        'الإعدادات',
          ),
        ],
      ),
    );
  }
}
