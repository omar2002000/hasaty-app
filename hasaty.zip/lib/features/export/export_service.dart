// lib/features/export/export_service.dart
// ─────────────────────────────────────────────────────────────
// Stage 5 — Unified export service.
//
// PDF exports:
//   exportStudentReport  — one page per student (name, stats, attendance%)
//   exportGroupReport    — group summary with all members
//
// Excel exports:
//   exportAttendanceSheet — all attendance records, one row each
//
// Rules:
//   • No widget tree required (off-screen rendering only)
//   • Uses existing entities — no new DB queries
//   • Saves to temp dir → opens share sheet
// ─────────────────────────────────────────────────────────────

import 'dart:io';
import 'dart:typed_data';
import 'package:excel/excel.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:share_plus/share_plus.dart';
import '../../domain/entities/student.dart';
import '../../domain/entities/attendance_record.dart';
import '../../domain/entities/payment.dart';

class ExportService {

  // ══════════════════════════════════════════════════════════
  // PDF — Student Report
  // ══════════════════════════════════════════════════════════

  /// Generates a one-page student report PDF and opens share sheet.
  static Future<void> exportStudentReport({
    required Student student,
    required List<AttendanceRecord> attendance,
    required List<Payment> payments,
  }) async {
    final bytes = await _buildStudentReportBytes(
        student: student, attendance: attendance, payments: payments);

    final dir  = await getTemporaryDirectory();
    final name = 'Report_${student.name.replaceAll(' ', '_')}.pdf';
    final file = File('${dir.path}/$name');
    await file.writeAsBytes(bytes);

    await Share.shareXFiles(
      [XFile(file.path, mimeType: 'application/pdf')],
      subject: 'تقرير الطالب — ${student.name}',
    );
  }

  static Future<Uint8List> _buildStudentReportBytes({
    required Student student,
    required List<AttendanceRecord> attendance,
    required List<Payment> payments,
  }) async {
    final totalSessions = attendance.length;
    final presentCount  = attendance.where((r) => r.present).length;
    final absentCount   = totalSessions - presentCount;
    final attPct = totalSessions > 0
        ? (presentCount / totalSessions * 100).toStringAsFixed(1) : '0';
    final totalPaid = payments.fold<double>(0, (s, p) => s + p.amount);

    final pdf = pw.Document(compress: true);

    pdf.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      margin:     const pw.EdgeInsets.all(32),
      build: (ctx) => pw.Column(
        crossAxisAlignment: pw.CrossAxisAlignment.start,
        children: [
          // Header
          pw.Container(
            width: double.infinity,
            padding: const pw.EdgeInsets.all(16),
            decoration: pw.BoxDecoration(
              color: PdfColor.fromHex('#1E3A8A'),
              borderRadius: pw.BorderRadius.circular(8),
            ),
            child: pw.Row(
              mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
              children: [
                pw.Text('تقرير الطالب',
                    style: pw.TextStyle(color: PdfColors.white, fontSize: 18,
                        fontWeight: pw.FontWeight.bold)),
                pw.Text('حصتي — Hasaty',
                    style: const pw.TextStyle(color: PdfColors.white70,
                        fontSize: 11)),
              ],
            ),
          ),
          pw.SizedBox(height: 20),

          // Student info block
          pw.Container(
            padding: const pw.EdgeInsets.all(14),
            decoration: pw.BoxDecoration(
              border: pw.Border.all(color: PdfColors.grey300),
              borderRadius: pw.BorderRadius.circular(8),
            ),
            child: pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                _pdfRow('الاسم',       student.name),
                _pdfRow('المجموعة',    student.groupName),
                _pdfRow('الهاتف',      student.phone.isNotEmpty ? student.phone : '—'),
                _pdfRow('ولي الأمر',   student.parentPhone.isNotEmpty ? student.parentPhone : '—'),
                _pdfRow('تاريخ الانضمام', student.joinDate),
              ],
            ),
          ),
          pw.SizedBox(height: 16),

          // Stats row
          pw.Row(children: [
            _pdfStatBox('الرصيد', '${student.balance.toStringAsFixed(0)} ج',
                student.balance >= 0 ? PdfColors.green800 : PdfColors.red),
            pw.SizedBox(width: 8),
            _pdfStatBox('نقاط XP', '${student.xp}', PdfColors.orange800),
            pw.SizedBox(width: 8),
            _pdfStatBox('نسبة الحضور', '$attPct%',
                double.parse(attPct) >= 75 ? PdfColors.green800 : PdfColors.red),
          ]),
          pw.SizedBox(height: 16),

          // Attendance summary
          pw.Text('ملخص الحضور',
              style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          pw.Row(children: [
            _pdfStatBox('حاضر',    '$presentCount جلسة', PdfColors.green800),
            pw.SizedBox(width: 8),
            _pdfStatBox('غائب',    '$absentCount جلسة',  PdfColors.red),
            pw.SizedBox(width: 8),
            _pdfStatBox('الإجمالي','$totalSessions جلسة',PdfColors.blueGrey700),
          ]),
          pw.SizedBox(height: 16),

          // Payments summary
          pw.Text('ملخص المدفوعات',
              style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
          pw.SizedBox(height: 8),
          pw.Row(children: [
            _pdfStatBox('إجمالي المدفوع', '${totalPaid.toStringAsFixed(0)} ج',
                PdfColors.green800),
            pw.SizedBox(width: 8),
            _pdfStatBox('عدد الدفعات', '${payments.length}', PdfColors.blueGrey700),
          ]),

          if (payments.isNotEmpty) ...[
            pw.SizedBox(height: 12),
            pw.Text('آخر الدفعات:',
                style: const pw.TextStyle(fontSize: 11, color: PdfColors.grey700)),
            pw.SizedBox(height: 4),
            pw.Table(
              border:       pw.TableBorder.all(color: PdfColors.grey300),
              columnWidths: const {
                0: pw.FlexColumnWidth(3),
                1: pw.FlexColumnWidth(2),
                2: pw.FlexColumnWidth(2),
              },
              children: [
                pw.TableRow(
                  decoration: const pw.BoxDecoration(color: PdfColors.grey200),
                  children: [
                    _tCell('المبلغ', header: true),
                    _tCell('التاريخ', header: true),
                    _tCell('النوع', header: true),
                  ],
                ),
                ...payments.take(5).map((p) => pw.TableRow(children: [
                  _tCell('${p.amount.toStringAsFixed(0)} ج'),
                  _tCell(p.date),
                  _tCell(p.typeLabel),
                ])),
              ],
            ),
          ],

          pw.Spacer(),
          // Footer
          pw.Divider(color: PdfColors.grey300),
          pw.SizedBox(height: 4),
          pw.Text(
            'تم إنشاء هذا التقرير بتاريخ ${_todayStr()}  •  تطبيق حصتي',
            style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey500),
          ),
        ],
      ),
    ));

    return pdf.save();
  }

  // ══════════════════════════════════════════════════════════
  // PDF — Group Report
  // ══════════════════════════════════════════════════════════

  static Future<void> exportGroupReport({
    required String groupName,
    required List<Student> students,
    required Map<int, double> attendancePcts, // studentId → pct
  }) async {
    final pdf = pw.Document(compress: true);

    pdf.addPage(pw.Page(
      pageFormat: PdfPageFormat.a4,
      margin:     const pw.EdgeInsets.all(32),
      build: (ctx) {
        final totalStudents = students.length;
        final avgXp = totalStudents > 0
            ? students.fold<double>(0, (s, st) => s + st.xp) / totalStudents : 0.0;
        final avgAtt = attendancePcts.isEmpty ? 0.0
            : attendancePcts.values.fold<double>(0, (s, v) => s + v)
                / attendancePcts.length;
        final debtStudents = students.where((s) => s.balance < 0).length;

        return pw.Column(
          crossAxisAlignment: pw.CrossAxisAlignment.start,
          children: [
            // Header
            pw.Container(
              width: double.infinity,
              padding: const pw.EdgeInsets.all(16),
              decoration: pw.BoxDecoration(
                color: PdfColor.fromHex('#1E3A8A'),
                borderRadius: pw.BorderRadius.circular(8),
              ),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text('تقرير المجموعة: $groupName',
                      style: pw.TextStyle(color: PdfColors.white, fontSize: 16,
                          fontWeight: pw.FontWeight.bold)),
                  pw.Text('حصتي — Hasaty  |  ${_todayStr()}',
                      style: const pw.TextStyle(
                          color: PdfColors.white70, fontSize: 10)),
                ],
              ),
            ),
            pw.SizedBox(height: 16),

            // Summary stats
            pw.Row(children: [
              _pdfStatBox('عدد الطلاب',   '$totalStudents',                 PdfColors.blue800),
              pw.SizedBox(width: 8),
              _pdfStatBox('متوسط XP',    avgXp.toStringAsFixed(0),         PdfColors.orange800),
              pw.SizedBox(width: 8),
              _pdfStatBox('متوسط الحضور','${avgAtt.toStringAsFixed(1)}%',   PdfColors.green800),
              pw.SizedBox(width: 8),
              _pdfStatBox('لديهم دين',    '$debtStudents',                  PdfColors.red),
            ]),
            pw.SizedBox(height: 16),

            // Students table
            pw.Text('قائمة الطلاب',
                style: pw.TextStyle(fontSize: 13, fontWeight: pw.FontWeight.bold)),
            pw.SizedBox(height: 8),
            pw.Table(
              border:       pw.TableBorder.all(color: PdfColors.grey300),
              columnWidths: const {
                0: pw.FlexColumnWidth(3),
                1: pw.FlexColumnWidth(2),
                2: pw.FlexColumnWidth(2),
                3: pw.FlexColumnWidth(2),
              },
              children: [
                pw.TableRow(
                  decoration: const pw.BoxDecoration(color: PdfColors.grey200),
                  children: [
                    _tCell('الاسم',    header: true),
                    _tCell('الرصيد',   header: true),
                    _tCell('XP',       header: true),
                    _tCell('الحضور %', header: true),
                  ],
                ),
                ...students.map((s) {
                  final pct = attendancePcts[s.id] ?? 0.0;
                  return pw.TableRow(children: [
                    _tCell(s.name),
                    _tCell('${s.balance.toStringAsFixed(0)} ج',
                        color: s.balance < 0 ? PdfColors.red : null),
                    _tCell('${s.xp}'),
                    _tCell('${pct.toStringAsFixed(0)}%',
                        color: pct < 50 ? PdfColors.red
                            : pct < 75  ? PdfColors.orange800 : null),
                  ]);
                }),
              ],
            ),

            pw.Spacer(),
            pw.Divider(color: PdfColors.grey300),
            pw.SizedBox(height: 4),
            pw.Text(
              'تم إنشاء التقرير بتاريخ ${_todayStr()}  •  تطبيق حصتي',
              style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey500),
            ),
          ],
        );
      },
    ));

    final bytes = await pdf.save();
    final dir   = await getTemporaryDirectory();
    final name  = 'Group_${groupName.replaceAll(' ', '_')}.pdf';
    final file  = File('${dir.path}/$name');
    await file.writeAsBytes(bytes);

    await Share.shareXFiles(
      [XFile(file.path, mimeType: 'application/pdf')],
      subject: 'تقرير مجموعة $groupName',
    );
  }

  // ══════════════════════════════════════════════════════════
  // Excel — Attendance Sheet
  // ══════════════════════════════════════════════════════════

  static Future<void> exportAttendanceSheet({
    required List<Student>          students,
    required List<AttendanceRecord> attendance,
  }) async {
    final excel = Excel.createExcel();
    excel.delete('Sheet1'); // remove default blank sheet

    // ── Sheet 1: All attendance records ──────────────────────
    final attSheet = excel['سجل الحضور'];
    final attHeaders = ['م', 'اسم الطالب', 'المجموعة', 'التاريخ', 'الحضور'];
    _excelHeader(attSheet, attHeaders);

    final sorted = [...attendance]
      ..sort((a, b) => b.date.compareTo(a.date));

    for (int i = 0; i < sorted.length; i++) {
      final r   = sorted[i];
      final row = i + 1;
      _excelCell(attSheet, row, 0, i + 1);
      _excelCell(attSheet, row, 1, r.studentName);
      _excelCell(attSheet, row, 2, r.groupName);
      _excelCell(attSheet, row, 3, r.date);
      _excelCell(attSheet, row, 4, r.present ? 'حاضر' : 'غائب');
    }

    // ── Sheet 2: Attendance summary per student ───────────────
    final sumSheet = excel['ملخص الطلاب'];
    final sumHeaders = ['م', 'الاسم', 'المجموعة', 'الإجمالي',
        'حاضر', 'غائب', 'نسبة الحضور %', 'الرصيد', 'XP'];
    _excelHeader(sumSheet, sumHeaders);

    for (int i = 0; i < students.length; i++) {
      final s    = students[i];
      final recs = attendance.where((r) => r.studentId == s.id).toList();
      final pres = recs.where((r) => r.present).length;
      final abs  = recs.length - pres;
      final pct  = recs.isEmpty ? 0.0 : pres / recs.length * 100;
      final row  = i + 1;
      _excelCell(sumSheet, row, 0, i + 1);
      _excelCell(sumSheet, row, 1, s.name);
      _excelCell(sumSheet, row, 2, s.groupName);
      _excelCell(sumSheet, row, 3, recs.length);
      _excelCell(sumSheet, row, 4, pres);
      _excelCell(sumSheet, row, 5, abs);
      _excelCell(sumSheet, row, 6, '${pct.toStringAsFixed(1)}%');
      _excelCell(sumSheet, row, 7, s.balance);
      _excelCell(sumSheet, row, 8, s.xp);
    }

    // Auto-width
    for (final sheet in [attSheet, sumSheet]) {
      for (int c = 0; c < 9; c++) sheet.setColWidth(c, 18);
    }

    final bytes = excel.save();
    if (bytes == null) throw Exception('Excel encoding failed');

    final dir  = await getTemporaryDirectory();
    final now  = DateTime.now();
    final name = 'Attendance_${now.year}_${now.month}.xlsx';
    final file = File('${dir.path}/$name');
    await file.writeAsBytes(bytes);

    await Share.shareXFiles(
      [XFile(file.path,
          mimeType:
              'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')],
      subject: 'سجل الحضور — $name',
    );
  }

  // ─── PDF helpers ─────────────────────────────────────────────

  static pw.Widget _pdfRow(String label, String value) => pw.Padding(
    padding: const pw.EdgeInsets.symmetric(vertical: 3),
    child: pw.Row(children: [
      pw.SizedBox(width: 100,
          child: pw.Text('$label:',
              style: const pw.TextStyle(color: PdfColors.grey700,
                  fontSize: 11))),
      pw.Text(value,
          style: pw.TextStyle(fontSize: 11, fontWeight: pw.FontWeight.bold)),
    ]),
  );

  static pw.Widget _pdfStatBox(String label, String value, PdfColor color) =>
      pw.Expanded(
        child: pw.Container(
          padding: const pw.EdgeInsets.all(10),
          decoration: pw.BoxDecoration(
            color: color.shade(0.9),
            borderRadius: pw.BorderRadius.circular(6),
          ),
          child: pw.Column(
            crossAxisAlignment: pw.CrossAxisAlignment.start, children: [
            pw.Text(value, style: pw.TextStyle(fontSize: 14,
                fontWeight: pw.FontWeight.bold, color: color)),
            pw.SizedBox(height: 2),
            pw.Text(label, style: const pw.TextStyle(
                fontSize: 9, color: PdfColors.grey600)),
          ]),
        ),
      );

  static pw.Widget _tCell(String text,
      {bool header = false, PdfColor? color}) =>
      pw.Padding(
        padding: const pw.EdgeInsets.all(6),
        child: pw.Text(text,
            style: pw.TextStyle(
              fontSize: header ? 10 : 9,
              fontWeight: header ? pw.FontWeight.bold : null,
              color: color,
            )),
      );

  // ─── Excel helpers ────────────────────────────────────────────

  static void _excelHeader(Sheet sheet, List<String> headers) {
    for (int c = 0; c < headers.length; c++) {
      final cell = sheet.cell(
          CellIndex.indexByColumnRow(columnIndex: c, rowIndex: 0));
      cell.value = TextCellValue(headers[c]);
      cell.cellStyle = CellStyle(
          bold: true,
          backgroundColorHex: ExcelColor.fromHexString('#1E3A8A'));
    }
  }

  static void _excelCell(Sheet sheet, int row, int col, dynamic value) {
    final cell = sheet.cell(
        CellIndex.indexByColumnRow(columnIndex: col, rowIndex: row));
    if (value is int)         cell.value = IntCellValue(value);
    else if (value is double) cell.value = DoubleCellValue(value);
    else                      cell.value = TextCellValue(value.toString());
  }

  static String _todayStr() {
    final n = DateTime.now();
    return '${n.day}/${n.month}/${n.year}';
  }
}
