// lib/features/export/export_screen.dart
// Stage 5 — Export hub: PDF (student + group) + Excel (attendance)
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/ui_helpers.dart';
import '../../core/widgets/shimmer_loading.dart';
import '../../domain/entities/student.dart';
import '../../providers/global_providers.dart';
import '../students/student_profile_screen.dart';
import 'export_service.dart';

// ── Providers ─────────────────────────────────────────────────

final _exportStudentsProvider = FutureProvider<List<Student>>((ref) =>
    ref.read(studentRepositoryProvider).getStudents());

// ─────────────────────────────────────────────────────────────

class ExportScreen extends ConsumerStatefulWidget {
  const ExportScreen({super.key});

  @override
  ConsumerState<ExportScreen> createState() => _ExportScreenState();
}

class _ExportScreenState extends ConsumerState<ExportScreen> {
  bool _exporting = false;
  String _exportingLabel = '';

  @override
  Widget build(BuildContext context) {
    final studentsState = ref.watch(_exportStudentsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('تصدير البيانات')),
      body: studentsState.when(
        loading: () => const ListShimmer(),
        error:   (e, _) => Center(child: Text('خطأ: $e')),
        data: (students) {
          // Group list for group-level export
          final groups = students.map((s) => s.groupName).toSet().toList()
            ..sort();

          return ListView(
            padding: const EdgeInsets.all(18),
            children: [
              // ── Info banner ────────────────────────────────
              Container(
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(
                  color: AppColors.primary.withOpacity(0.06),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: AppColors.primary.withOpacity(0.15)),
                ),
                child: Row(children: [
                  const Icon(Icons.info_outline,
                      color: AppColors.primary, size: 18),
                  const SizedBox(width: 10),
                  Expanded(child: Text(
                    '${students.length} طالب · ${groups.length} مجموعة',
                    style: const TextStyle(fontSize: 12,
                        color: AppColors.primary),
                  )),
                ]),
              ),
              const SizedBox(height: 24),

              // ── Section: Student PDF ───────────────────────
              const _SectionLabel(label: '📄 تقرير الطالب (PDF)'),
              const SizedBox(height: 10),
              _ExportCard(
                icon:     Icons.person_outline,
                color:    AppColors.primary,
                title:    'اختر طالباً لتصدير تقريره',
                subtitle: 'يشمل: الحضور، المدفوعات، الرصيد، XP',
                format:   '.pdf',
                loading:  _exporting && _exportingLabel == 'student',
                onTap:    () => _pickStudentForExport(context, students),
              ),
              const SizedBox(height: 10),

              // ── Section: Group PDF ─────────────────────────
              const _SectionLabel(label: '👥 تقرير المجموعة (PDF)'),
              const SizedBox(height: 10),
              ...groups.map((g) {
                final gs = students.where((s) => s.groupName == g).toList();
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: _ExportCard(
                    icon:     Icons.groups_rounded,
                    color:    AppColors.accent,
                    title:    g,
                    subtitle: '${gs.length} طالب',
                    format:   '.pdf',
                    loading:  _exporting && _exportingLabel == 'group_$g',
                    onTap:    () => _exportGroup(context, g, gs),
                  ),
                );
              }),
              const SizedBox(height: 10),

              // ── Section: Excel Attendance ──────────────────
              const _SectionLabel(label: '📊 سجل الحضور (Excel)'),
              const SizedBox(height: 10),
              _ExportCard(
                icon:     Icons.table_chart_rounded,
                color:    const Color(0xFF217346),
                title:    'تصدير سجل الحضور الكامل',
                subtitle: 'جدول Excel: سجل مفصّل + ملخص نسب الحضور',
                format:   '.xlsx',
                loading:  _exporting && _exportingLabel == 'excel',
                onTap:    () => _exportExcel(context, students),
              ),
            ],
          );
        },
      ),
    );
  }

  // ─── Pick student for PDF report ──────────────────────────────

  Future<void> _pickStudentForExport(
      BuildContext context, List<Student> students) async {
    final selected = await showModalBottomSheet<Student>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.7,
        maxChildSize:     0.92,
        minChildSize:     0.4,
        expand: false,
        builder: (_, ctrl) => Container(
          decoration: BoxDecoration(
            color: Theme.of(context).brightness == Brightness.dark
                ? AppColors.bgCardDark : Colors.white,
            borderRadius:
                const BorderRadius.vertical(top: Radius.circular(20)),
          ),
          child: Column(children: [
            Container(
              margin: const EdgeInsets.only(top: 10, bottom: 8),
              width: 36, height: 4,
              decoration: BoxDecoration(
                  color: AppColors.borderLight,
                  borderRadius: BorderRadius.circular(2)),
            ),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 8),
              child: Text('اختر طالباً',
                  style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
            ),
            Expanded(
              child: ListView.builder(
                controller: ctrl,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemCount: students.length,
                itemBuilder: (_, i) {
                  final s = students[i];
                  return ListTile(
                    leading: CircleAvatar(
                      backgroundColor: AppColors.primary.withOpacity(0.1),
                      child: Text(s.displayInitial,
                          style: const TextStyle(
                              color: AppColors.primary,
                              fontWeight: FontWeight.bold)),
                    ),
                    title: Text(s.name),
                    subtitle: Text(s.groupName),
                    onTap: () => Navigator.pop(context, s),
                  );
                },
              ),
            ),
          ]),
        ),
      ),
    );
    if (selected == null || !mounted) return;
    await _exportStudent(context, selected);
  }

  // ─── Export student PDF ───────────────────────────────────────

  Future<void> _exportStudent(BuildContext context, Student student) async {
    setState(() { _exporting = true; _exportingLabel = 'student'; });
    try {
      final attendance = await ref.read(attendanceRepositoryProvider)
          .getByStudent(student.id!);
      final payments   = await ref.read(financeRepositoryProvider)
          .getStudentPayments(student.id!);

      await ExportService.exportStudentReport(
        student:    student,
        attendance: attendance,
        payments:   payments,
      );
      if (mounted) AppUI.showToast(context, '✅ تم تصدير تقرير ${student.name}');
    } catch (e) {
      if (mounted) AppUI.showToast(context, 'خطأ: $e', isError: true);
    } finally {
      if (mounted) setState(() { _exporting = false; _exportingLabel = ''; });
    }
  }

  // ─── Export group PDF ─────────────────────────────────────────

  Future<void> _exportGroup(BuildContext context, String groupName,
      List<Student> groupStudents) async {
    setState(() { _exporting = true; _exportingLabel = 'group_$groupName'; });
    try {
      // Build attendance % map
      final pcts = <int, double>{};
      for (final s in groupStudents) {
        pcts[s.id!] = await ref.read(attendanceRepositoryProvider)
            .getAttendancePercentage(s.id!);
      }
      await ExportService.exportGroupReport(
        groupName:      groupName,
        students:       groupStudents,
        attendancePcts: pcts,
      );
      if (mounted) AppUI.showToast(context, '✅ تم تصدير تقرير $groupName');
    } catch (e) {
      if (mounted) AppUI.showToast(context, 'خطأ: $e', isError: true);
    } finally {
      if (mounted) setState(() { _exporting = false; _exportingLabel = ''; });
    }
  }

  // ─── Export Excel attendance ──────────────────────────────────

  Future<void> _exportExcel(
      BuildContext context, List<Student> students) async {
    setState(() { _exporting = true; _exportingLabel = 'excel'; });
    try {
      // Fetch all attendance records
      final allAtt = <dynamic>[];
      for (final s in students) {
        final recs = await ref.read(attendanceRepositoryProvider)
            .getByStudent(s.id!);
        allAtt.addAll(recs);
      }
      await ExportService.exportAttendanceSheet(
        students:   students,
        attendance: allAtt.cast(),
      );
      if (mounted) AppUI.showToast(context, '✅ تم تصدير سجل الحضور');
    } catch (e) {
      if (mounted) AppUI.showToast(context, 'خطأ: $e', isError: true);
    } finally {
      if (mounted) setState(() { _exporting = false; _exportingLabel = ''; });
    }
  }
}

// ── Widgets ────────────────────────────────────────────────────

class _SectionLabel extends StatelessWidget {
  final String label;
  const _SectionLabel({required this.label});
  @override
  Widget build(BuildContext context) => Text(label,
      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13,
          color: AppColors.textSecondary));
}

class _ExportCard extends StatelessWidget {
  final IconData icon;
  final Color    color;
  final String   title, subtitle, format;
  final bool     loading;
  final VoidCallback onTap;

  const _ExportCard({
    required this.icon, required this.color,
    required this.title, required this.subtitle,
    required this.format, required this.loading,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return GestureDetector(
      onTap: loading ? null : onTap,
      child: AnimatedOpacity(
        opacity: loading ? 0.6 : 1.0,
        duration: const Duration(milliseconds: 200),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: color.withOpacity(0.2)),
            boxShadow: [BoxShadow(color: color.withOpacity(0.05),
                blurRadius: 6, offset: const Offset(0, 2))],
          ),
          child: Row(children: [
            Container(
              width: 46, height: 46,
              decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12)),
              child: loading
                  ? Center(child: SizedBox(width: 20, height: 20,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: color)))
                  : Icon(icon, color: color, size: 22),
            ),
            const SizedBox(width: 14),
            Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title, style: const TextStyle(
                  fontWeight: FontWeight.bold, fontSize: 14)),
              const SizedBox(height: 2),
              Text(subtitle, style: const TextStyle(
                  fontSize: 11, color: AppColors.textSecondary)),
            ])),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
              decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20)),
              child: Text(format,
                  style: TextStyle(fontSize: 10,
                      fontWeight: FontWeight.bold, color: color)),
            ),
          ]),
        ),
      ),
    );
  }
}
