// lib/features/students/student_profile_screen.dart
// Stage 2C: absence stats, smart status, full attendance timeline
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/stat_card.dart';
import '../../core/widgets/xp_progress_bar.dart';
import '../../core/utils/ui_helpers.dart';
import '../../domain/entities/student.dart';
import '../../domain/entities/attendance_record.dart';
import '../../domain/entities/payment.dart';
import '../../domain/entities/academic_grade.dart';
import '../../domain/entities/achievement.dart';
import '../../providers/global_providers.dart';
import '../finance/widgets/payment_timeline.dart';
import '../xp/xp_screen.dart';
import '../qr/student_qr_card.dart';

// ── Scoped Providers ──────────────────────────────────────────

final _studentAttProvider =
    FutureProvider.family<List<AttendanceRecord>, int>((ref, sid) =>
        ref.read(attendanceRepositoryProvider).getByStudent(sid));

final _studentPayProvider =
    FutureProvider.family<List<Payment>, int>((ref, sid) =>
        ref.read(financeRepositoryProvider).getStudentPayments(sid));

final _studentGradesProvider =
    FutureProvider.family<List<AcademicGrade>, int>((ref, sid) =>
        ref.read(gradeRepositoryProvider).getStudentGrades(sid));

final _studentAchProvider =
    FutureProvider.family<List<String>, int>((ref, sid) =>
        ref.read(achievementRepositoryProvider).getStudentAchievements(sid));

final _attPctProvider =
    FutureProvider.family<double, int>((ref, sid) =>
        ref.read(attendanceRepositoryProvider).getAttendancePercentage(sid));

// ── Smart Status (Stage 2C — computed, NOT stored) ─────────────
// >80% attendance + no debt → Regular
// 50–80% OR negative balance → Irregular
// <50%                       → Inactive
/// Stage 8 — Smart Status based purely on attendance percentage.
/// >80% → ملتزم (Regular)
/// 50–80% → متذبذب (Irregular)
/// <50% → غير نشط (Inactive)
/// Dynamic: never stored in DB — computed on every profile open.
String _smartStatus(double pct) {
  if (pct > 80) return 'ملتزم';
  if (pct >= 50) return 'متذبذب';
  return 'غير نشط';
}

Color _statusColor(String status) {
  switch (status) {
    case 'ملتزم':   return AppColors.success;
    case 'متذبذب': return AppColors.warning;
    default:        return AppColors.danger;
  }
}

// ─────────────────────────────────────────────────────────────

class StudentProfileScreen extends ConsumerStatefulWidget {
  final Student student;
  const StudentProfileScreen({super.key, required this.student});

  @override
  ConsumerState<StudentProfileScreen> createState() =>
      _StudentProfileScreenState();
}

class _StudentProfileScreenState extends ConsumerState<StudentProfileScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final s   = widget.student;
    final pct = ref.watch(_attPctProvider(s.id!));

    return Scaffold(
      body: NestedScrollView(
        headerSliverBuilder: (ctx, _) => [
          SliverAppBar(
            expandedHeight: 295,
            pinned: true,
            backgroundColor: AppColors.primary,
            actions: [
              IconButton(
                icon: const Icon(Icons.star_rounded, color: Colors.white),
                tooltip: 'نظام XP',
                onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => XpScreen(student: s))),
              ),
            ],
            flexibleSpace: FlexibleSpaceBar(
              background: Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    colors: [AppColors.primary, AppColors.primaryLight],
                    begin: Alignment.topLeft, end: Alignment.bottomRight,
                  ),
                ),
                child: SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        // Avatar
                        Container(
                          width: 60, height: 60,
                          decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(18)),
                          child: Center(child: Text(s.displayInitial,
                              style: const TextStyle(color: Colors.white,
                                  fontSize: 26, fontWeight: FontWeight.bold))),
                        ),
                        const SizedBox(height: 8),
                        Text(s.name, style: const TextStyle(
                            color: Colors.white, fontSize: 17,
                            fontWeight: FontWeight.bold)),
                        Text(s.groupName,
                            style: const TextStyle(color: Colors.white70, fontSize: 12)),
                        const SizedBox(height: 8),
                        // Smart status badge (Stage 2C)
                        pct.when(
                          loading: () => const SizedBox.shrink(),
                          error:   (_, __) => const SizedBox.shrink(),
                          data: (p) {
                            final status = _smartStatus(p);
                            final color  = _statusColor(status);
                            return Container(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 12, vertical: 4),
                              decoration: BoxDecoration(
                                  color: color.withOpacity(0.2),
                                  borderRadius: BorderRadius.circular(20),
                                  border: Border.all(
                                      color: color.withOpacity(0.4))),
                              child: Text(status,
                                  style: TextStyle(color: color,
                                      fontSize: 12,
                                      fontWeight: FontWeight.bold)),
                            );
                          },
                        ),
                        const SizedBox(height: 8),
                        XpProgressBar(
                          progress:  s.levelProgress,
                          currentXp: s.xp,
                          nextXp:    s.nextLevelXp,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            bottom: TabBar(
              controller: _tab,
              labelColor: Colors.white,
              unselectedLabelColor: Colors.white60,
              indicatorColor: Colors.white,
              isScrollable: true,
              tabs: const [
                Tab(text: 'الملف'),
                Tab(text: 'الحضور'),
                Tab(text: 'الدفعات'),
                Tab(text: 'الاشتراكات'),
              ],
            ),
          ),
        ],
        body: TabBarView(
          controller: _tab,
          children: [
            _ProfileTab(student: s, pctAsync: pct),
            _AttendanceTab(studentId: s.id!),
            _PaymentsTab(studentId: s.id!),
            PaymentTimeline(studentId: s.id!),
          ],
        ),
      ),
    );
  }
}

// ─── Profile Tab ──────────────────────────────────────────────

class _ProfileTab extends ConsumerWidget {
  final Student student;
  final AsyncValue<double> pctAsync;
  const _ProfileTab({required this.student, required this.pctAsync});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final achievements = ref.watch(_studentAchProvider(student.id!));
    final grades       = ref.watch(_studentGradesProvider(student.id!));
    final attState     = ref.watch(_studentAttProvider(student.id!));
    final pctVal       = pctAsync.valueOrNull ?? 0.0;

    // Absence stats (Stage 2C)
    final totalSessions = attState.valueOrNull?.length ?? 0;
    final presentCount  = attState.valueOrNull?.where((r) => r.present).length ?? 0;
    final absentCount   = totalSessions - presentCount;

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        // ── Attendance stats strip (Stage 2C) ─────────────────
        if (totalSessions > 0) Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: pctVal >= 75
                ? AppColors.success.withOpacity(0.06)
                : AppColors.warning.withOpacity(0.06),
            borderRadius: BorderRadius.circular(14),
            border: Border.all(color: (pctVal >= 75
                ? AppColors.success : AppColors.warning).withOpacity(0.2)),
          ),
          child: Column(children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                _StatChip('✅ حاضر', presentCount, AppColors.success),
                _StatChip('❌ غائب', absentCount,  AppColors.danger),
                _StatChip('📊 نسبة', null, pctVal >= 75
                    ? AppColors.success : AppColors.warning,
                    label: '${pctVal.toStringAsFixed(0)}%'),
              ],
            ),
            const SizedBox(height: 8),
            ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: (pctVal / 100).clamp(0.0, 1.0),
                backgroundColor: AppColors.borderLight,
                color: pctVal >= 75 ? AppColors.success : AppColors.warning,
                minHeight: 6,
              ),
            ),
          ]),
        ),

        // ── Stats row ──────────────────────────────────────────
        Row(children: [
          StatCard(title: 'الرصيد',
              value: '${student.balance.toStringAsFixed(0)} ج',
              icon:  Icons.account_balance_wallet_rounded,
              color: student.balance >= 0 ? AppColors.success : AppColors.danger),
          const SizedBox(width: 8),
          StatCard(title: 'XP', value: '${student.xp}',
              icon: Icons.stars_rounded, color: AppColors.warning),
          const SizedBox(width: 8),
          StatCard(title: '🪙 عملات', value: '${student.coins}',
              icon: Icons.monetization_on_outlined, color: AppColors.accent),
        ]),
        const SizedBox(height: 12),

        // ── QR button (Stage 1B) ───────────────────────────────
        // Stage 1B: QR code button — opens sheet with PNG/PDF/Print
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            icon:  const Icon(Icons.qr_code_rounded),
            label: const Text('عرض كود QR'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
            onPressed: () => StudentQrSheet.show(context, student),
          ),
        ),

        // ── WhatsApp button ────────────────────────────────────
        if (student.phone.isNotEmpty || student.parentPhone.isNotEmpty) ...[
          const SizedBox(height: 8),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              icon: const Icon(Icons.message,color: Color(0xFF25D366)),
              label: const Text('واتساب ولي الأمر',
                  style: TextStyle(color: Color(0xFF25D366))),
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Color(0xFF25D366)),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () {
                final p   = student.parentPhone.isNotEmpty
                    ? student.parentPhone : student.phone;
                final num = p.startsWith('0')
                    ? '2${p.substring(1)}' : p;
                launchUrl(Uri.parse('https://wa.me/$num'),
                    mode: LaunchMode.externalApplication);
              },
            ),
          ),
        ],
        const SizedBox(height: 16),

        // ── Achievements ───────────────────────────────────────
        const Align(alignment: Alignment.centerRight,
            child: Text('🎖️ الإنجازات',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15))),
        const SizedBox(height: 8),
        achievements.when(
          loading: () => const SizedBox.shrink(),
          error:   (_, __) => const SizedBox.shrink(),
          data: (ids) => ids.isEmpty
              ? Container(
                  padding: const EdgeInsets.all(14), width: double.infinity,
                  decoration: BoxDecoration(
                      color: AppColors.textSecondary.withOpacity(0.06),
                      borderRadius: BorderRadius.circular(12)),
                  child: const Text('لا يوجد إنجازات بعد',
                      style: TextStyle(color: AppColors.textSecondary, fontSize: 12),
                      textAlign: TextAlign.center))
              : Wrap(spacing: 8, runSpacing: 8,
                  children: ids.map((id) {
                    final a = Achievements.getById(id);
                    if (a == null) return const SizedBox.shrink();
                    return Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 10, vertical: 7),
                      decoration: BoxDecoration(
                          color: AppColors.warning.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                              color: AppColors.warning.withOpacity(0.3))),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        Text(a.emoji, style: const TextStyle(fontSize: 15)),
                        const SizedBox(width: 5),
                        Text(a.title,
                            style: const TextStyle(fontSize: 12,
                                fontWeight: FontWeight.bold)),
                      ]),
                    );
                  }).toList()),
        ),
        const SizedBox(height: 16),

        // ── Recent grades ──────────────────────────────────────
        grades.when(
          loading: () => const SizedBox.shrink(),
          error:   (_, __) => const SizedBox.shrink(),
          data: (gs) => gs.isEmpty ? const SizedBox.shrink()
              : Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Text('📝 آخر التقييمات',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                  const SizedBox(height: 8),
                  ...gs.take(5).map((g) {
                    final gc = g.grade == 'excellent' ? AppColors.success
                        : g.grade == 'good'       ? AppColors.accent
                        : g.grade == 'acceptable' ? AppColors.warning
                        : AppColors.danger;
                    return Container(
                      margin: const EdgeInsets.only(bottom: 6),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                          color: gc.withOpacity(0.06),
                          borderRadius: BorderRadius.circular(10),
                          border: Border.all(color: gc.withOpacity(0.2))),
                      child: Row(children: [
                        Text(g.gradeEmoji, style: const TextStyle(fontSize: 16)),
                        const SizedBox(width: 9),
                        Expanded(child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                          Text('${g.typeLabel} — ${g.gradeLabel}',
                              style: const TextStyle(fontWeight: FontWeight.bold,
                                  fontSize: 12)),
                          if (g.sessionTopic.isNotEmpty)
                            Text(g.sessionTopic,
                                style: const TextStyle(fontSize: 11,
                                    color: AppColors.textSecondary)),
                        ])),
                        Text(g.date,
                            style: const TextStyle(fontSize: 10,
                                color: AppColors.textSecondary)),
                      ]),
                    );
                  }),
                ]),
        ),
      ]),
    );
  }
}

class _StatChip extends StatelessWidget {
  final String title;
  final int? count;
  final Color color;
  final String? valueLabel;

  const _StatChip(this.title, this.count, this.color, {String? label})
      : valueLabel = label;

  @override
  Widget build(BuildContext context) => Column(children: [
    Text(count != null ? '$count' : (valueLabel ?? ''),
        style: TextStyle(color: color, fontSize: 20,
            fontWeight: FontWeight.bold)),
    Text(title, style: const TextStyle(fontSize: 10,
        color: AppColors.textSecondary)),
  ]);
}

// ─── Attendance Tab ────────────────────────────────────────────

class _AttendanceTab extends ConsumerWidget {
  final int studentId;
  const _AttendanceTab({required this.studentId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(_studentAttProvider(studentId));
    return state.when(
      loading: () => const Center(child: CircularProgressIndicator(
          color: AppColors.primary)),
      error:   (e, _) => Center(child: Text('$e')),
      data: (records) => records.isEmpty
          ? const Center(child: Text('لا يوجد سجل حضور',
              style: TextStyle(color: AppColors.textSecondary)))
          : ListView.builder(
              padding: const EdgeInsets.all(14),
              itemCount: records.length,
              itemBuilder: (_, i) {
                final r    = records[i];
                final isDark = Theme.of(context).brightness == Brightness.dark;
                final color = r.present ? AppColors.success : AppColors.danger;
                return Container(
                  margin: const EdgeInsets.only(bottom: 6),
                  decoration: BoxDecoration(
                      color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(color: color.withOpacity(0.2))),
                  child: ListTile(
                    leading: Container(
                      width: 34, height: 34,
                      decoration: BoxDecoration(
                          color: color.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(9)),
                      child: Icon(r.present ? Icons.check : Icons.close,
                          color: color, size: 16),
                    ),
                    title: Text(r.present ? 'حاضر' : 'غائب',
                        style: TextStyle(color: color,
                            fontWeight: FontWeight.bold)),
                    subtitle: Text(r.groupName),
                    trailing: Text(r.date,
                        style: const TextStyle(fontSize: 11,
                            color: AppColors.textSecondary)),
                  ),
                );
              }),
    );
  }
}

// ─── Payments Tab ─────────────────────────────────────────────

class _PaymentsTab extends ConsumerWidget {
  final int studentId;
  const _PaymentsTab({required this.studentId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(_studentPayProvider(studentId));
    return state.when(
      loading: () => const Center(child: CircularProgressIndicator(
          color: AppColors.primary)),
      error:   (e, _) => Center(child: Text('$e')),
      data: (payments) => payments.isEmpty
          ? const Center(child: Text('لا توجد دفعات',
              style: TextStyle(color: AppColors.textSecondary)))
          : ListView.builder(
              padding: const EdgeInsets.all(14),
              itemCount: payments.length,
              itemBuilder: (_, i) {
                final p    = payments[i];
                final isDark = Theme.of(context).brightness == Brightness.dark;
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                      color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                          color: AppColors.success.withOpacity(0.15))),
                  child: Row(children: [
                    Container(
                      width: 34, height: 34,
                      decoration: BoxDecoration(
                          color: AppColors.success.withOpacity(0.12),
                          borderRadius: BorderRadius.circular(9)),
                      child: const Icon(Icons.payments_rounded,
                          color: AppColors.success, size: 17),
                    ),
                    const SizedBox(width: 10),
                    Expanded(child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                      Text('${p.amount.toStringAsFixed(0)} ج.م',
                          style: const TextStyle(fontWeight: FontWeight.bold,
                              color: AppColors.success, fontSize: 14)),
                      if (p.note.isNotEmpty)
                        Text(p.note, style: const TextStyle(fontSize: 11,
                            color: AppColors.textSecondary)),
                    ])),
                    Text(p.date, style: const TextStyle(
                        fontSize: 10, color: AppColors.textSecondary)),
                  ]),
                );
              }),
    );
  }
}
