// lib/features/students/screens/students_screen.dart
// Stage 2A: Edit student dialog (name, phone, group, parentPhone)
// Stage 2B: Smart delete — archive (soft) vs hard delete with undo
// Stage 2C: Richer card showing balance, XP, attendance indicator

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/shimmer_loading.dart';
import '../../../core/widgets/empty_state.dart';
import '../../../core/utils/ui_helpers.dart';
import '../../../domain/entities/student.dart';
import '../providers/students_notifier.dart';
import '../student_profile_screen.dart';
import '../../qr/student_qr_card.dart'; // Stage 1B

class StudentsScreen extends ConsumerStatefulWidget {
  const StudentsScreen({super.key});

  @override
  ConsumerState<StudentsScreen> createState() => _StudentsScreenState();
}

class _StudentsScreenState extends ConsumerState<StudentsScreen> {
  final _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final filtered = ref.watch(filteredStudentsProvider);
    final filter   = ref.watch(studentsFilterProvider);
    final groups   = ref.watch(availableGroupsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('الطلاب'),
        actions: [
          PopupMenuButton<StudentSortBy>(
            icon: const Icon(Icons.sort_rounded),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            onSelected: (v) => ref.read(studentsFilterProvider.notifier)
                .update((s) => s.copyWith(sortBy: v)),
            itemBuilder: (_) => [
              _sortItem(StudentSortBy.xp,      '⭐ ترتيب بـ XP',   filter.sortBy),
              _sortItem(StudentSortBy.balance, '💰 ترتيب بالرصيد', filter.sortBy),
              _sortItem(StudentSortBy.name,    '🔤 ترتيب بالاسم',  filter.sortBy),
            ],
          ),
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () => ref.read(studentsNotifierProvider.notifier).reload(),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.primary,
        icon: const Icon(Icons.person_add_rounded, color: Colors.white),
        label: const Text('إضافة طالب',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        onPressed: () => _showAddDialog(context),
      ),
      body: Column(children: [
        // ── Search + Filter ────────────────────────────────────
        Container(
          color: Theme.of(context).brightness == Brightness.dark
              ? AppColors.bgCardDark : AppColors.bgCard,
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
          child: Column(children: [
            TextField(
              controller: _searchCtrl,
              onChanged: (v) => ref.read(studentsFilterProvider.notifier)
                  .update((s) => s.copyWith(query: v)),
              decoration: InputDecoration(
                hintText: 'ابحث باسم الطالب أو المجموعة...',
                prefixIcon: const Icon(Icons.search, color: AppColors.textSecondary),
                suffixIcon: filter.query.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          _searchCtrl.clear();
                          ref.read(studentsFilterProvider.notifier)
                              .update((s) => s.copyWith(query: ''));
                        })
                    : null,
              ),
            ),
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                _FilterChip(label: 'الكل',
                    selected: filter.filterBy == StudentFilterBy.all,
                    onTap: () => ref.read(studentsFilterProvider.notifier)
                        .update((s) => s.copyWith(filterBy: StudentFilterBy.all))),
                const SizedBox(width: 6),
                _FilterChip(label: '⚠️ ديون', color: AppColors.danger,
                    selected: filter.filterBy == StudentFilterBy.withDebt,
                    onTap: () => ref.read(studentsFilterProvider.notifier)
                        .update((s) => s.copyWith(filterBy: StudentFilterBy.withDebt))),
                const SizedBox(width: 6),
                _FilterChip(label: '🔴 خطر', color: AppColors.warning,
                    selected: filter.filterBy == StudentFilterBy.risky,
                    onTap: () => ref.read(studentsFilterProvider.notifier)
                        .update((s) => s.copyWith(filterBy: StudentFilterBy.risky))),
                const SizedBox(width: 6),
                _FilterChip(label: '📦 مؤرشفون', color: AppColors.textSecondary,
                    selected: filter.filterBy == StudentFilterBy.archived,
                    onTap: () => ref.read(studentsFilterProvider.notifier)
                        .update((s) => s.copyWith(filterBy: StudentFilterBy.archived))),
                ...groups.whenOrNull(data: (gs) => gs.map((g) => Padding(
                  padding: const EdgeInsets.only(left: 6),
                  child: _FilterChip(label: g, color: AppColors.accent,
                      selected: filter.groupName == g,
                      onTap: () => ref.read(studentsFilterProvider.notifier)
                          .update((s) => filter.groupName == g
                              ? s.copyWith(clearGroup: true)
                              : s.copyWith(groupName: g))),
                ))) ?? [],
              ]),
            ),
          ]),
        ),

        // ── List ────────────────────────────────────────────────
        Expanded(
          child: filtered.when(
            loading: () => const ListShimmer(),
            error:   (e, _) => Center(child: Text('خطأ: $e')),
            data: (students) {
              if (students.isEmpty) {
                return const EmptyStateWidget(
                  icon:     Icons.person_search_rounded,
                  title:    'لا يوجد نتائج',
                  subtitle: 'جرّب تغيير معايير البحث أو الفلتر',
                );
              }
              return RefreshIndicator(
                color: AppColors.primary,
                onRefresh: () =>
                    ref.read(studentsNotifierProvider.notifier).reload(),
                child: ListView.builder(
                  padding: const EdgeInsets.fromLTRB(16, 8, 16, 100),
                  itemCount: students.length,
                  itemBuilder: (_, i) => _StudentCard(
                    student:  students[i],
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) =>
                            StudentProfileScreen(student: students[i]))),
                    onEdit:    () => _showEditDialog(context, students[i]),
                    onDelete:  () => _showDeleteDialog(context, students[i]),
                    onRestore: filter.filterBy == StudentFilterBy.archived
                        ? () => _doRestore(context, students[i])
                        : null,
                  ),
                ),
              );
            },
          ),
        ),
      ]),
    );
  }

  PopupMenuItem<StudentSortBy> _sortItem(
      StudentSortBy val, String label, StudentSortBy current) =>
      PopupMenuItem(
        value: val,
        child: Row(children: [
          Icon(current == val
              ? Icons.radio_button_checked
              : Icons.radio_button_off,
              size: 16, color: AppColors.primary),
          const SizedBox(width: 8),
          Text(label),
        ]),
      );

  // ─── Stage 2A: Add student dialog ─────────────────────────────

  void _showAddDialog(BuildContext context) {
    String name = '', phone = '', parentPhone = '', group = '';
    showDialog(
      context: context,
      builder: (ctx) => _StudentDialog(
        title: 'إضافة طالب جديد',
        onSave: (n, p, pp, g) async {
          if (n.isEmpty || g.isEmpty) return;
          final now = DateTime.now();
          await ref.read(studentsNotifierProvider.notifier).addStudent(Student(
            name: n, phone: p, parentPhone: pp, groupName: g,
            joinDate: '${now.day}/${now.month}/${now.year}',
          ));
          if (context.mounted) AppUI.showToast(context, 'تم إضافة $n ✅');
        },
      ),
    );
  }

  // ─── Stage 2A: Edit student dialog ────────────────────────────

  void _showEditDialog(BuildContext context, Student s) {
    showDialog(
      context: context,
      builder: (_) => _StudentDialog(
        title:         'تعديل بيانات الطالب',
        initialName:   s.name,
        initialPhone:  s.phone,
        initialParent: s.parentPhone,
        initialGroup:  s.groupName,
        onSave: (n, p, pp, g) async {
          if (n.isEmpty || g.isEmpty) return;
          await ref.read(studentsNotifierProvider.notifier)
              .updateStudent(s.copyWith(
            name:        n,
            phone:       p,
            parentPhone: pp,
            groupName:   g,
          ));
          if (context.mounted) AppUI.showToast(context, 'تم التعديل ✅');
        },
      ),
    );
  }

  // ─── Stage 2B: Smart delete dialog ────────────────────────────

  Future<void> _showDeleteDialog(BuildContext context, Student s) async {
    final choice = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('حذف الطالب', textAlign: TextAlign.center),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
                color: AppColors.warning.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12)),
            child: Text('${s.name} — ${s.groupName}',
                style: const TextStyle(fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
          ),
          const SizedBox(height: 16),
          const Text('اختر نوع الحذف:', textAlign: TextAlign.center),
        ]),
        actionsAlignment: MainAxisAlignment.spaceEvenly,
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('إلغاء'),
          ),
          // Soft delete (archive)
          OutlinedButton.icon(
            icon: const Icon(Icons.archive_outlined, size: 16),
            label: const Text('أرشفة'),
            style: OutlinedButton.styleFrom(foregroundColor: AppColors.warning),
            onPressed: () => Navigator.pop(context, 'archive'),
          ),
          // Hard delete
          ElevatedButton.icon(
            icon: const Icon(Icons.delete_forever_rounded, size: 16),
            label: const Text('حذف نهائي'),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger),
            onPressed: () => Navigator.pop(context, 'hard'),
          ),
        ],
      ),
    );

    if (choice == null || !mounted) return;

    if (choice == 'archive') {
      await ref.read(studentsNotifierProvider.notifier)
          .archiveStudent(s.id!);
      if (mounted) {
        // Undo snackbar — 5 seconds
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('تم أرشفة ${s.name}'),
          backgroundColor: AppColors.warning,
          duration: const Duration(seconds: 5),
          behavior: SnackBarBehavior.floating,
          action: SnackBarAction(
            label: 'تراجع',
            textColor: Colors.white,
            onPressed: () async {
              await ref.read(studentsNotifierProvider.notifier)
                  .restoreStudent(s.id!);
              if (context.mounted) {
                AppUI.showToast(context, 'تم استعادة ${s.name}');
              }
            },
          ),
        ));
      }
    } else if (choice == 'hard') {
      // Extra confirmation for hard delete
      final confirm = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: const Row(children: [
            Icon(Icons.warning_rounded, color: AppColors.danger),
            SizedBox(width: 8),
            Text('تأكيد الحذف النهائي'),
          ]),
          content: Text(
            'سيُحذف "${s.name}" بشكل نهائي مع جميع سجلاته (حضور، مدفوعات، درجات).\n\nهذا الإجراء لا يمكن التراجع عنه.',
            style: const TextStyle(height: 1.5),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger),
              onPressed: () => Navigator.pop(context, true),
              child: const Text('حذف نهائي',
                  style: TextStyle(color: Colors.white)),
            ),
          ],
        ),
      );
      if (confirm == true && mounted) {
        await ref.read(studentsNotifierProvider.notifier)
            .hardDeleteStudent(s.id!);
        if (mounted) {
          AppUI.showToast(context, 'تم حذف ${s.name} نهائياً');
        }
      }
    }
  }

  // ─── Restore (from archived filter) ───────────────────────────

  Future<void> _doRestore(BuildContext context, Student s) async {
    await ref.read(studentsNotifierProvider.notifier).restoreStudent(s.id!);
    if (mounted) AppUI.showToast(context, 'تم استعادة ${s.name} ✅');
  }
}

// ══════════════════════════════════════════════════════════════
// Reusable Add/Edit Student Dialog
// ══════════════════════════════════════════════════════════════

class _StudentDialog extends StatefulWidget {
  final String title;
  final String initialName;
  final String initialPhone;
  final String initialParent;
  final String initialGroup;
  final Future<void> Function(
      String name, String phone, String parent, String group) onSave;

  const _StudentDialog({
    required this.title,
    required this.onSave,
    this.initialName   = '',
    this.initialPhone  = '',
    this.initialParent = '',
    this.initialGroup  = '',
  });

  @override
  State<_StudentDialog> createState() => _StudentDialogState();
}

class _StudentDialogState extends State<_StudentDialog> {
  late final TextEditingController _name, _phone, _parent, _group;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _name   = TextEditingController(text: widget.initialName);
    _phone  = TextEditingController(text: widget.initialPhone);
    _parent = TextEditingController(text: widget.initialParent);
    _group  = TextEditingController(text: widget.initialGroup);
  }

  @override
  void dispose() {
    _name.dispose(); _phone.dispose();
    _parent.dispose(); _group.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: Row(children: [
        const Icon(Icons.person_rounded, color: AppColors.primary),
        const SizedBox(width: 8),
        Text(widget.title, style: const TextStyle(fontSize: 16)),
      ]),
      content: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          _field(_name,   'اسم الطالب *',      Icons.person,     TextInputType.text),
          const SizedBox(height: 10),
          _field(_phone,  'رقم الهاتف',         Icons.phone,      TextInputType.phone),
          const SizedBox(height: 10),
          _field(_parent, 'هاتف ولي الأمر',     Icons.phone_in_talk, TextInputType.phone),
          const SizedBox(height: 10),
          _field(_group,  'المجموعة *',          Icons.groups_rounded, TextInputType.text),
        ]),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('إلغاء'),
        ),
        ElevatedButton(
          onPressed: _saving ? null : () async {
            if (_name.text.trim().isEmpty || _group.text.trim().isEmpty) {
              return;
            }
            setState(() => _saving = true);
            await widget.onSave(
              _name.text.trim(), _phone.text.trim(),
              _parent.text.trim(), _group.text.trim(),
            );
            if (mounted) Navigator.pop(context);
          },
          child: _saving
              ? const SizedBox(width: 16, height: 16,
                  child: CircularProgressIndicator(strokeWidth: 2))
              : const Text('حفظ'),
        ),
      ],
    );
  }

  Widget _field(TextEditingController ctrl, String label,
      IconData icon, TextInputType type) {
    return TextField(
      controller: ctrl,
      keyboardType: type,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, size: 18),
      ),
    );
  }
}

// ── Student Card ───────────────────────────────────────────────

class _StudentCard extends StatelessWidget {
  final Student student;
  final VoidCallback onTap;
  final VoidCallback onEdit;
  final VoidCallback onDelete;
  final VoidCallback? onRestore;

  const _StudentCard({
    required this.student,
    required this.onTap,
    required this.onEdit,
    required this.onDelete,
    this.onRestore,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final bc = student.isCriticalRisk
        ? AppColors.danger
        : student.isFinancialRisk
            ? AppColors.warning
            : AppColors.borderLight;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 10),
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: bc.withOpacity(0.5)),
        ),
        child: Row(children: [
          // Avatar
          Container(
            width: 44, height: 44,
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [AppColors.primary, AppColors.primaryLight]),
              borderRadius: BorderRadius.circular(13),
            ),
            child: Center(child: Text(student.displayInitial,
                style: const TextStyle(color: Colors.white,
                    fontWeight: FontWeight.bold, fontSize: 18))),
          ),
          const SizedBox(width: 12),

          // Info
          Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(student.name,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            const SizedBox(height: 3),
            Text(student.groupName,
                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
            const SizedBox(height: 5),
            Row(children: [
              _Pill('${student.levelEmoji} ${student.levelName}', AppColors.primary),
              const SizedBox(width: 5),
              _Pill(
                '${student.balance >= 0 ? '+' : ''}${student.balance.toStringAsFixed(0)} ج',
                student.balance >= 0 ? AppColors.success : AppColors.danger,
              ),
              const SizedBox(width: 5),
              _Pill('${student.xp} XP', AppColors.warning),
            ]),
          ])),

          // Actions
          // Stage 1B: QR shortcut
          IconButton(
            icon: const Icon(Icons.qr_code_rounded,
                color: AppColors.primary, size: 20),
            tooltip: 'QR',
            onPressed: () => StudentQrSheet.show(context, student),
          ),
          PopupMenuButton<String>(
            shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12)),
            onSelected: (v) {
              if (v == 'edit')    onEdit();
              if (v == 'delete')  onDelete();
              if (v == 'restore') onRestore?.call();
            },
            itemBuilder: (_) => [
              if (onRestore != null)
                const PopupMenuItem(value: 'restore',
                    child: Row(children: [
                      Icon(Icons.restore, size: 16, color: AppColors.success),
                      SizedBox(width: 8), Text('استعادة'),
                    ]))
              else ...[
                const PopupMenuItem(value: 'edit',
                    child: Row(children: [
                      Icon(Icons.edit_outlined, size: 16, color: AppColors.primary),
                      SizedBox(width: 8), Text('تعديل'),
                    ])),
                const PopupMenuItem(value: 'delete',
                    child: Row(children: [
                      Icon(Icons.delete_outline, size: 16, color: AppColors.danger),
                      SizedBox(width: 8), Text('حذف'),
                    ])),
              ],
            ],
          ),
        ]),
      ),
    );
  }
}

class _Pill extends StatelessWidget {
  final String text;
  final Color  color;
  const _Pill(this.text, this.color);
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
    decoration: BoxDecoration(
        color: color.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
    child: Text(text,
        style: TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: color)),
  );
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final Color color;
  final VoidCallback onTap;
  const _FilterChip({required this.label, required this.selected,
      this.color = AppColors.primary, required this.onTap});

  @override
  Widget build(BuildContext context) => GestureDetector(
    onTap: onTap,
    child: AnimatedContainer(
      duration: const Duration(milliseconds: 180),
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: selected ? color : color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: selected ? color : color.withOpacity(0.3)),
      ),
      child: Text(label,
          style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold,
              color: selected ? Colors.white : color)),
    ),
  );
}
