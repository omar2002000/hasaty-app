// lib/features/students/providers/students_notifier.dart
// Stage 6C: keepAlive.
// Stage 8: AuditService.log() calls on every student mutation.
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../domain/entities/student.dart';
import '../../../core/providers/usecase_providers.dart';
import '../../../core/services/audit_service.dart'; // Stage 8
import '../../../providers/global_providers.dart';

// ── Filter/Sort State ─────────────────────────────────────────

enum StudentSortBy { xp, balance, name, attendance }
enum StudentFilterBy { all, withDebt, risky, archived }

class StudentsFilter {
  final String query;
  final String? groupName;
  final StudentSortBy sortBy;
  final StudentFilterBy filterBy;
  final bool sortDesc;

  const StudentsFilter({
    this.query    = '',
    this.groupName,
    this.sortBy   = StudentSortBy.xp,
    this.filterBy = StudentFilterBy.all,
    this.sortDesc = true,
  });

  StudentsFilter copyWith({
    String? query,
    String? groupName,
    StudentSortBy? sortBy,
    StudentFilterBy? filterBy,
    bool? sortDesc,
    bool clearGroup = false,
  }) {
    return StudentsFilter(
      query:     query     ?? this.query,
      groupName: clearGroup ? null : (groupName ?? this.groupName),
      sortBy:    sortBy    ?? this.sortBy,
      filterBy:  filterBy  ?? this.filterBy,
      sortDesc:  sortDesc  ?? this.sortDesc,
    );
  }
}

// ── Notifier ──────────────────────────────────────────────────

class StudentsNotifier extends AsyncNotifier<List<Student>> {
  @override
  Future<List<Student>> build() async {
    ref.keepAlive(); // Stage 6C
    return ref.read(getStudentsUseCaseProvider).execute();
  }

  Future<void> reload() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(
        () => ref.read(getStudentsUseCaseProvider).execute());
  }

  Future<void> addStudent(Student student) async {
    final id = await ref.read(addStudentUseCaseProvider).execute(student);
    // Stage 8: audit log
    await AuditService.log(ref,
      actionType:  'add',
      studentId:   id,
      studentName: student.name,
      description: 'تم إضافة الطالب ${student.name} — ${student.groupName}',
    );
    await reload();
  }

  Future<void> updateStudent(Student student) async {
    await ref.read(updateStudentUseCaseProvider).execute(student);
    // Stage 8: audit log
    await AuditService.log(ref,
      actionType:  'edit',
      studentId:   student.id,
      studentName: student.name,
      description: 'تم تعديل بيانات ${student.name}',
    );
    await reload();
  }

  Future<void> archiveStudent(int id) async {
    // Fetch name before archiving for the log
    final students = state.valueOrNull ?? [];
    final s = students.firstWhere((st) => st.id == id,
        orElse: () => const Student(name: '', phone: '', groupName: '', joinDate: ''));

    await ref.read(archiveStudentUseCaseProvider).archive(id);
    // Stage 8: audit log
    await AuditService.log(ref,
      actionType:  'archive',
      studentId:   id,
      studentName: s.name,
      description: 'تم أرشفة الطالب ${s.name}',
    );
    await reload();
  }

  Future<void> restoreStudent(int id) async {
    final students = state.valueOrNull ?? [];
    final s = students.firstWhere((st) => st.id == id,
        orElse: () => const Student(name: '', phone: '', groupName: '', joinDate: ''));

    await ref.read(studentRepositoryProvider).restoreStudent(id);
    await AuditService.log(ref,
      actionType:  'edit',
      studentId:   id,
      studentName: s.name,
      description: 'تم استعادة الطالب ${s.name} من الأرشيف',
    );
    await reload();
  }

  Future<void> hardDeleteStudent(int id) async {
    final students = state.valueOrNull ?? [];
    final s = students.firstWhere((st) => st.id == id,
        orElse: () => const Student(name: '', phone: '', groupName: '', joinDate: ''));

    await ref.read(studentRepositoryProvider).hardDeleteStudent(id);
    await AuditService.log(ref,
      actionType:  'delete',
      studentId:   id,
      studentName: s.name,
      description: 'تم حذف ${s.name} نهائياً مع جميع سجلاته',
    );
    await reload();
  }

  Future<void> chargeStudent(Student student, double amount, String note) async {
    await ref.read(chargeStudentUseCaseProvider).execute(student, amount, note);
    await AuditService.log(ref,
      actionType:  'payment',
      studentId:   student.id,
      studentName: student.name,
      description: 'تم شحن رصيد ${student.name} بمبلغ ${amount.toStringAsFixed(0)} ج',
    );
    await reload();
  }
}

final studentsNotifierProvider =
    AsyncNotifierProvider<StudentsNotifier, List<Student>>(
        StudentsNotifier.new);

// ── Filter Provider ───────────────────────────────────────────

final studentsFilterProvider =
    StateProvider<StudentsFilter>((_) => const StudentsFilter());

final filteredStudentsProvider = Provider<AsyncValue<List<Student>>>((ref) {
  final raw    = ref.watch(studentsNotifierProvider);
  final filter = ref.watch(studentsFilterProvider);

  return raw.whenData((students) {
    var result = students.where((s) => !s.archived).toList();

    if (filter.query.isNotEmpty) {
      final q = filter.query.toLowerCase();
      result = result.where((s) =>
          s.name.toLowerCase().contains(q) ||
          s.groupName.toLowerCase().contains(q) ||
          s.phone.contains(q)).toList();
    }

    if (filter.groupName != null) {
      result = result.where((s) => s.groupName == filter.groupName).toList();
    }

    switch (filter.filterBy) {
      case StudentFilterBy.withDebt:
        result = result.where((s) => s.balance < 0).toList(); break;
      case StudentFilterBy.risky:
        result = result
            .where((s) => s.isCriticalRisk || s.isFinancialRisk).toList();
        break;
      case StudentFilterBy.archived:
        result = students.where((s) => s.archived).toList(); break;
      case StudentFilterBy.all: break;
    }

    result.sort((a, b) {
      int cmp;
      switch (filter.sortBy) {
        case StudentSortBy.xp:        cmp = a.xp.compareTo(b.xp); break;
        case StudentSortBy.balance:   cmp = a.balance.compareTo(b.balance); break;
        case StudentSortBy.name:      cmp = a.name.compareTo(b.name); break;
        case StudentSortBy.attendance: cmp = 0; break;
      }
      return filter.sortDesc ? -cmp : cmp;
    });

    return result;
  });
});

final availableGroupsProvider = Provider<AsyncValue<List<String>>>((ref) {
  return ref.watch(studentsNotifierProvider).whenData((students) =>
      students.map((s) => s.groupName).toSet().toList()..sort());
});
