// lib/features/risk/risk_provider.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../domain/entities/student.dart';
import '../../providers/global_providers.dart';

enum RiskLevel { critical, warning, safe }

class StudentRisk {
  final Student student;
  final RiskLevel level;
  final double attendancePct;
  final List<String> reasons;

  const StudentRisk({
    required this.student,
    required this.level,
    required this.attendancePct,
    required this.reasons,
  });

  String get levelLabel {
    switch (level) {
      case RiskLevel.critical: return 'خطر عالٍ';
      case RiskLevel.warning:  return 'تحذير';
      case RiskLevel.safe:     return 'ملتزم';
    }
  }

  String get levelEmoji {
    switch (level) {
      case RiskLevel.critical: return '🔴';
      case RiskLevel.warning:  return '🟡';
      case RiskLevel.safe:     return '🟢';
    }
  }
}

final riskProvider = FutureProvider<Map<String, List<StudentRisk>>>((ref) async {
  final students = await ref.read(studentRepositoryProvider).getStudents();
  final critical = <StudentRisk>[];
  final warning  = <StudentRisk>[];
  final safe     = <StudentRisk>[];

  for (final s in students) {
    final pct     = await ref.read(attendanceRepositoryProvider)
        .getAttendancePercentage(s.id!);
    final reasons = <String>[];

    // Assess reasons
    if (s.balance <= -200)     reasons.add('دين متراكم ${s.balance.toStringAsFixed(0)} ج');
    if (s.balance < 0 && s.balance > -200) reasons.add('رصيد سالب ${s.balance.toStringAsFixed(0)} ج');
    if (pct < 50 && pct > 0)   reasons.add('حضور ضعيف ${pct.toStringAsFixed(0)}%');
    if (pct < 75 && pct >= 50) reasons.add('حضور متوسط ${pct.toStringAsFixed(0)}%');

    RiskLevel level;
    if (s.balance <= -200 || (pct < 50 && pct > 0)) {
      level = RiskLevel.critical;
    } else if (s.balance < 0 || (pct < 75 && pct > 0)) {
      level = RiskLevel.warning;
    } else {
      level = RiskLevel.safe;
    }

    final risk = StudentRisk(
      student:       s,
      level:         level,
      attendancePct: pct,
      reasons:       reasons,
    );

    switch (level) {
      case RiskLevel.critical: critical.add(risk); break;
      case RiskLevel.warning:  warning.add(risk);  break;
      case RiskLevel.safe:     safe.add(risk);      break;
    }
  }

  // Sort by severity
  critical.sort((a, b) => a.student.balance.compareTo(b.student.balance));
  warning.sort((a, b) => a.attendancePct.compareTo(b.attendancePct));

  return {
    'critical': critical,
    'warning':  warning,
    'safe':     safe,
  };
});
