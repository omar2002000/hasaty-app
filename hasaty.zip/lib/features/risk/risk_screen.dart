// lib/features/risk/risk_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/shimmer_loading.dart';
import '../../core/utils/ui_helpers.dart';
import '../students/student_profile_screen.dart';
import 'risk_provider.dart';

class RiskScreen extends ConsumerWidget {
  const RiskScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(riskProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('تحليل المخاطر'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () => ref.invalidate(riskProvider),
          ),
        ],
      ),
      body: state.when(
        loading: () => const ListShimmer(count: 8),
        error:   (e, _) => Center(child: Text('خطأ: $e')),
        data: (data) {
          final critical = data['critical']!;
          final warning  = data['warning']!;
          final safe     = data['safe']!;
          final total    = critical.length + warning.length + safe.length;

          return ListView(
            padding: const EdgeInsets.all(16),
            children: [

              // ── Summary ─────────────────────────────────────
              AppUI.fadeSlide(index: 0, child: _SummaryRow(
                critical: critical.length,
                warning:  warning.length,
                safe:     safe.length,
                total:    total,
              )),
              const SizedBox(height: 20),

              // ── Critical ────────────────────────────────────
              if (critical.isNotEmpty) ...[
                _SectionHeader(
                  title: '🔴 خطر عالٍ (${critical.length})',
                  color: AppColors.danger,
                ),
                const SizedBox(height: 8),
                ...critical.asMap().entries.map((e) => AppUI.fadeSlide(
                  index: e.key + 1,
                  child: _RiskCard(risk: e.value, onTap: () =>
                      Navigator.push(context, MaterialPageRoute(
                          builder: (_) => StudentProfileScreen(
                              student: e.value.student)))),
                )),
                const SizedBox(height: 16),
              ],

              // ── Warning ─────────────────────────────────────
              if (warning.isNotEmpty) ...[
                _SectionHeader(
                  title: '🟡 تحذير (${warning.length})',
                  color: AppColors.warning,
                ),
                const SizedBox(height: 8),
                ...warning.asMap().entries.map((e) => AppUI.fadeSlide(
                  index: e.key + 5,
                  child: _RiskCard(risk: e.value, onTap: () =>
                      Navigator.push(context, MaterialPageRoute(
                          builder: (_) => StudentProfileScreen(
                              student: e.value.student)))),
                )),
                const SizedBox(height: 16),
              ],

              // ── Safe ────────────────────────────────────────
              if (safe.isNotEmpty) ...[
                _SectionHeader(
                  title: '🟢 ملتزمون (${safe.length})',
                  color: AppColors.success,
                ),
                const SizedBox(height: 8),
                // ✅ تم حل الخطأ هنا بإضافة .toList()
                ...safe.take(5).toList().asMap().entries.map((e) => AppUI.fadeSlide(
                  index: e.key + 10,
                  child: _RiskCard(risk: e.value, onTap: () =>
                      Navigator.push(context, MaterialPageRoute(
                          builder: (_) => StudentProfileScreen(
                              student: e.value.student)))),
                )),
                if (safe.length > 5)
                  Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Text('و ${safe.length - 5} آخرين ملتزمون...',
                        style: const TextStyle(
                            color: AppColors.textSecondary, fontSize: 12),
                        textAlign: TextAlign.center),
                  ),
              ],
            ],
          );
        },
      ),
    );
  }
}

class _SummaryRow extends StatelessWidget {
  final int critical, warning, safe, total;
  const _SummaryRow({required this.critical, required this.warning,
      required this.safe, required this.total});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(children: [
        Text('إجمالي $total طالب',
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
        const SizedBox(height: 12),
        // Progress bar
        ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Row(children: [
            if (critical > 0)
              Flexible(
                flex: critical,
                child: Container(height: 10, color: AppColors.danger),
              ),
            if (warning > 0)
              Flexible(
                flex: warning,
                child: Container(height: 10, color: AppColors.warning),
              ),
            if (safe > 0)
              Flexible(
                flex: safe,
                child: Container(height: 10, color: AppColors.success),
              ),
          ]),
        ),
        const SizedBox(height: 10),
        Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          _SummaryChip('🔴 خطر', critical, AppColors.danger),
          _SummaryChip('🟡 تحذير', warning, AppColors.warning),
          _SummaryChip('🟢 آمن', safe, AppColors.success),
        ]),
      ]),
    );
  }
}

class _SummaryChip extends StatelessWidget {
  final String label;
  final int count;
  final Color color;
  const _SummaryChip(this.label, this.count, this.color);

  @override
  Widget build(BuildContext context) => Column(children: [
    Text('$count', style: TextStyle(
        fontSize: 22, fontWeight: FontWeight.bold, color: color)),
    Text(label, style: const TextStyle(fontSize: 11,
        color: AppColors.textSecondary)),
  ]);
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final Color color;
  const _SectionHeader({required this.title, required this.color});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
    decoration: BoxDecoration(
      color: color.withOpacity(0.08),
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: color.withOpacity(0.2)),
    ),
    child: Text(title, style: TextStyle(
        fontWeight: FontWeight.bold, fontSize: 13, color: color)),
  );
}

class _RiskCard extends StatelessWidget {
  final StudentRisk risk;
  final VoidCallback onTap;
  const _RiskCard({required this.risk, required this.onTap});

  Color get _color {
    switch (risk.level) {
      case RiskLevel.critical: return AppColors.danger;
      case RiskLevel.warning:  return AppColors.warning;
      case RiskLevel.safe:     return AppColors.success;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final s      = risk.student;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(13),
        decoration: BoxDecoration(
          color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: _color.withOpacity(0.25)),
        ),
        child: Row(children: [
          // Avatar
          Container(
            width: 40, height: 40,
            decoration: BoxDecoration(
                color: _color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(11)),
            child: Center(child: Text(s.displayInitial,
                style: TextStyle(color: _color, fontWeight: FontWeight.bold))),
          ),
          const SizedBox(width: 12),
          // Info
          Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(s.name,
                style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            Text(s.groupName,
                style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
            if (risk.reasons.isNotEmpty) ...[
              const SizedBox(height: 4),
              Wrap(spacing: 4, runSpacing: 2,
                  children: risk.reasons.map((r) => Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                        color: _color.withOpacity(0.08),
                        borderRadius: BorderRadius.circular(10)),
                    child: Text(r, style: TextStyle(fontSize: 9, color: _color)),
                  )).toList()),
            ],
          ])),
          // Risk badge
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                  color: _color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20)),
              child: Text('${risk.levelEmoji} ${risk.levelLabel}',
                  style: TextStyle(fontSize: 10,
                      fontWeight: FontWeight.bold, color: _color)),
            ),
            const SizedBox(height: 3),
            Text('${risk.attendancePct.toStringAsFixed(0)}% حضور',
                style: const TextStyle(fontSize: 9,
                    color: AppColors.textSecondary)),
          ]),
        ]),
      ),
    );
  }
}