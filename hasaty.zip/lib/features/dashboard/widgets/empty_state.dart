// lib/features/dashboard/widgets/empty_state.dart
// Empty state خاص بالـ Dashboard — يعرض رسالة ترحيبية
// عندما لا يوجد طلاب بعد.
import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';

class DashboardEmptyState extends StatelessWidget {
  const DashboardEmptyState({super.key});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Icon
            Container(
              padding: const EdgeInsets.all(28),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    AppColors.primary.withOpacity(0.08),
                    AppColors.primaryLight.withOpacity(0.05),
                  ],
                ),
                shape: BoxShape.circle,
              ),
              child: const Text('🎓', style: TextStyle(fontSize: 52)),
            ),
            const SizedBox(height: 24),

            // Title
            const Text(
              'مرحباً بك في حصتي!',
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),

            // Subtitle
            const Text(
              'ابدأ بإضافة طلابك ومجموعاتك\nوستظهر هنا الإحصاءات تلقائياً',
              style: TextStyle(
                fontSize: 13,
                color: AppColors.textSecondary,
                height: 1.6,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 32),

            // Steps
            _Step(number: '1', text: 'أضف مجموعاتك من قسم الإعدادات'),
            const SizedBox(height: 10),
            _Step(number: '2', text: 'أضف طلابك من قسم الطلاب'),
            const SizedBox(height: 10),
            _Step(number: '3', text: 'ابدأ تسجيل الحضور والاشتراكات'),
          ],
        ),
      ),
    );
  }
}

class _Step extends StatelessWidget {
  final String number;
  final String text;
  const _Step({required this.number, required this.text});

  @override
  Widget build(BuildContext context) {
    return Row(children: [
      Container(
        width: 28, height: 28,
        decoration: const BoxDecoration(
          color: AppColors.primary,
          shape: BoxShape.circle,
        ),
        child: Center(
          child: Text(number,
              style: const TextStyle(
                  color: Colors.white,
                  fontSize: 13,
                  fontWeight: FontWeight.bold)),
        ),
      ),
      const SizedBox(width: 12),
      Expanded(
        child: Text(text,
            style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
      ),
    ]);
  }
}
