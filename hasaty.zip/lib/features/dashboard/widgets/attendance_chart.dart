// lib/features/dashboard/widgets/attendance_chart.dart
import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';

class AttendanceChart extends StatelessWidget {
  final double percentage;

  const AttendanceChart({super.key, required this.percentage});

  Color get _color {
    if (percentage >= 75) return AppColors.success;
    if (percentage >= 50) return AppColors.warning;
    return AppColors.danger;
  }

  String get _label {
    if (percentage >= 75) return 'ممتاز 🌟';
    if (percentage >= 50) return 'متوسط ⚠️';
    return 'ضعيف ❌';
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            const Text('📊 معدل الحضور العام',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
              decoration: BoxDecoration(
                  color: _color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20)),
              child: Text(_label,
                  style: TextStyle(
                      fontSize: 11, fontWeight: FontWeight.bold, color: _color)),
            ),
          ],
        ),
        const SizedBox(height: 14),
        Row(children: [
          // Circular indicator
          SizedBox(
            width: 64, height: 64,
            child: Stack(children: [
              CircularProgressIndicator(
                value: percentage / 100,
                strokeWidth: 7,
                backgroundColor: AppColors.borderLight,
                color: _color,
              ),
              Center(
                child: Text(
                  '${percentage.toStringAsFixed(0)}%',
                  style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                      color: _color),
                ),
              ),
            ]),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start, children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(6),
                child: LinearProgressIndicator(
                  value: percentage / 100,
                  backgroundColor: AppColors.borderLight,
                  color: _color,
                  minHeight: 10,
                ),
              ),
              const SizedBox(height: 8),
              Text('$percentage% من الطلاب حضروا بانتظام',
                  style: const TextStyle(
                      fontSize: 11, color: AppColors.textSecondary)),
            ]),
          ),
        ]),
      ]),
    );
  }
}
