// lib/features/dashboard/widgets/income_chart.dart
// Stage 4: added collectionRate parameter + percentage indicator
import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';

class IncomeChart extends StatelessWidget {
  final List<Map<String, dynamic>> monthlyData;
  final double collectionRate;

  const IncomeChart({
    super.key,
    required this.monthlyData,
    this.collectionRate = 0,
  });

  @override
  Widget build(BuildContext context) {
    final isDark   = Theme.of(context).brightness == Brightness.dark;
    final amounts  = monthlyData.map((m) => (m['amount'] as double)).toList();
    final maxVal   = amounts.isEmpty ? 1.0
        : amounts.reduce((a, b) => a > b ? a : b).clamp(1.0, double.infinity);
    final rateColor = collectionRate >= 80
        ? AppColors.success
        : collectionRate >= 50 ? AppColors.warning : AppColors.danger;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          const Text('📈 الدخل الشهري',
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
          // Stage 4: collection rate badge
          if (collectionRate > 0)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                  color: rateColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20)),
              child: Text(
                'تحصيل ${collectionRate.toStringAsFixed(0)}%',
                style: TextStyle(fontSize: 10,
                    fontWeight: FontWeight.bold, color: rateColor),
              ),
            ),
        ]),
        const SizedBox(height: 16),
        // Bar chart
        SizedBox(
          height: 110,
          child: monthlyData.isEmpty
              ? const Center(child: Text('لا توجد بيانات',
                  style: TextStyle(color: AppColors.textSecondary)))
              : Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: monthlyData.asMap().entries.map((e) {
                    final pct    = maxVal > 0
                        ? (e.value['amount'] as double) / maxVal : 0.0;
                    final isLast = e.key == monthlyData.length - 1;
                    final amt    = e.value['amount'] as double;
                    return Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 3),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            if (isLast && amt > 0)
                              Container(
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 4, vertical: 2),
                                decoration: BoxDecoration(
                                    color: AppColors.success,
                                    borderRadius: BorderRadius.circular(5)),
                                child: Text(
                                  amt.toStringAsFixed(0),
                                  style: const TextStyle(
                                      color: Colors.white, fontSize: 7,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            const SizedBox(height: 3),
                            AnimatedContainer(
                              duration: Duration(
                                  milliseconds: 400 + e.key * 80),
                              curve: Curves.easeOut,
                              height: (pct * 75).clamp(4.0, 75.0),
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: isLast
                                      ? [AppColors.success,
                                          AppColors.success.withOpacity(0.6)]
                                      : [AppColors.primary.withOpacity(0.7),
                                          AppColors.primary.withOpacity(0.3)],
                                  begin: Alignment.topCenter,
                                  end:   Alignment.bottomCenter,
                                ),
                                borderRadius: const BorderRadius.vertical(
                                    top: Radius.circular(5)),
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              (e.value['month'] as String).substring(0, 3),
                              style: TextStyle(
                                fontSize: 9,
                                color: isLast
                                    ? AppColors.primary
                                    : AppColors.textSecondary,
                                fontWeight: isLast
                                    ? FontWeight.bold : FontWeight.normal,
                              ),
                            ),
                          ],
                        ),
                      ),
                    );
                  }).toList(),
                ),
        ),
      ]),
    );
  }
}
