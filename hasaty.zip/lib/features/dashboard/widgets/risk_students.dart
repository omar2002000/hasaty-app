// lib/features/dashboard/widgets/risk_students.dart
import 'package:flutter/material.dart';
import '../../../core/theme/app_colors.dart';
import '../../../domain/entities/student.dart';

class RiskStudents extends StatelessWidget {
  final List<Student> students;
  final void Function(Student)? onTap;

  const RiskStudents({super.key, required this.students, this.onTap});

  @override
  Widget build(BuildContext context) {
    if (students.isEmpty) {
      return Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.success.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: AppColors.success.withOpacity(0.2)),
        ),
        child: const Row(children: [
          Text('🎉', style: TextStyle(fontSize: 22)),
          SizedBox(width: 10),
          Expanded(child: Text('لا يوجد طلاب في خطر حالياً!',
              style: TextStyle(color: AppColors.success, fontWeight: FontWeight.bold))),
        ]),
      );
    }

    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(children: students.map((s) {
      final color = s.isCriticalRisk ? AppColors.danger : AppColors.warning;
      return GestureDetector(
        onTap: () => onTap?.call(s),
        child: Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: color.withOpacity(0.3)),
          ),
          child: Row(children: [
            Container(
              width: 36, height: 36,
              decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(10)),
              child: Center(
                child: Text(s.displayInitial,
                    style: TextStyle(
                        color: color, fontWeight: FontWeight.bold)),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(child: Column(
                crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(s.name,
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
              Text(s.groupName,
                  style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
            ])),
            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20)),
                child: Text('${s.balance.toStringAsFixed(0)} ج',
                    style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: color)),
              ),
              const SizedBox(height: 3),
              Text(s.isCriticalRisk ? '🔴 خطر' : '🟡 تحذير',
                  style: const TextStyle(fontSize: 10, color: AppColors.textSecondary)),
            ]),
          ]),
        ),
      );
    }).toList());
  }
}
