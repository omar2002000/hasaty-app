// lib/features/dashboard/dashboard_screen.dart
// Stage 4: added today attendance card, most-absent analytics,
//          group breakdown, avg attendance, collection rate.
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../core/widgets/stat_card.dart';
import '../../core/widgets/shimmer_loading.dart';
import '../../core/widgets/empty_state.dart';
import '../../core/utils/ui_helpers.dart';
import '../../domain/entities/student.dart';
import '../students/student_profile_screen.dart';
import '../students/screens/students_screen.dart';
import '../finance/subscription_screen.dart';
import '../sessions/qr_scanner_screen.dart';
import '../settings/notifications_screen.dart';
import 'providers/dashboard_provider.dart';
import 'widgets/income_chart.dart';
import 'widgets/risk_students.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(dashboardProvider);
    final now   = DateTime.now();
    const months = ['','يناير','فبراير','مارس','أبريل','مايو','يونيو',
        'يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];

    return Scaffold(
      body: Column(children: [
        // ── Hero Header ─────────────────────────────────────
        _buildHeader(context, state, now, months),

        // ── Body ───────────────────────────────────────────
        Expanded(
          child: state.when(
            loading: () => const DashboardShimmer(),
            error:   (e, _) => Center(child: Text('خطأ: $e')),
            data: (data) {
              if ((data['students'] as int) == 0) {
                return const EmptyStateWidget(
                  icon: Icons.people_outline,
                  title: 'لا يوجد طلاب بعد',
                  subtitle: 'ابدأ بإضافة طلابك من قسم الطلاب',
                );
              }
              return RefreshIndicator(
                color: AppColors.primary,
                onRefresh: () => ref.refresh(dashboardProvider.future),
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    // ── Row 1: Students + Today ──────────────
                    AppUI.fadeSlide(index: 0, child: Row(children: [
                      StatCard(
                        title: 'إجمالي الطلاب',
                        value: '${data['students']}',
                        icon:  Icons.people_rounded,
                        color: AppColors.primary,
                        onTap: () => Navigator.push(context,
                            MaterialPageRoute(builder: (_) => const StudentsScreen())),
                      ),
                      const SizedBox(width: 10),
                      // Stage 4: today attendance card
                      StatCard(
                        title: 'حضور اليوم',
                        value: '${data['todayPresent']}',
                        icon:  Icons.how_to_reg_rounded,
                        color: AppColors.success,
                      ),
                    ])),
                    const SizedBox(height: 10),

                    // ── Row 2: Income + Debt ─────────────────
                    AppUI.fadeSlide(index: 1, child: Row(children: [
                      StatCard(
                        title: 'دخل الشهر',
                        value: '${data['income']} ج',
                        icon:  Icons.payments_rounded,
                        color: AppColors.accent,
                        onTap: () => Navigator.push(context,
                            MaterialPageRoute(builder: (_) => const SubscriptionScreen())),
                      ),
                      const SizedBox(width: 10),
                      StatCard(
                        title: 'إجمالي الديون',
                        value: '${data['totalDebt']} ج',
                        icon:  Icons.money_off_rounded,
                        color: AppColors.danger,
                      ),
                    ])),
                    const SizedBox(height: 10),

                    // ── Row 3: Avg Attendance + Risky ────────
                    AppUI.fadeSlide(index: 2, child: Row(children: [
                      StatCard(
                        title: 'متوسط الحضور',
                        value: '${(data['avgAttendance'] as double).toStringAsFixed(0)}%',
                        icon:  Icons.bar_chart_rounded,
                        color: (data['avgAttendance'] as double) >= 70
                            ? AppColors.success : AppColors.warning,
                      ),
                      const SizedBox(width: 10),
                      StatCard(
                        title: 'طلاب الخطر',
                        value: '${data['risky']}',
                        icon:  Icons.warning_rounded,
                        color: AppColors.warning,
                      ),
                    ])),
                    const SizedBox(height: 20),

                    // ── Income Chart ─────────────────────────
                    AppUI.fadeSlide(index: 3,
                      child: IncomeChart(
                        monthlyData: (data['monthlyChart'] as List)
                            .cast<Map<String, dynamic>>(),
                        collectionRate: data['collectionRate'] as double,
                      ),
                    ),
                    const SizedBox(height: 20),

                    // ── Stage 4: Group Breakdown ──────────────
                    if ((data['groupBreakdown'] as List).isNotEmpty) ...[
                      AppUI.fadeSlide(index: 4,
                          child: _GroupBreakdown(
                              groups: (data['groupBreakdown'] as List)
                                  .cast<Map<String, dynamic>>())),
                      const SizedBox(height: 20),
                    ],

                    // ── Stage 4: Most Absent ──────────────────
                    if ((data['mostAbsent'] as List).isNotEmpty) ...[
                      const _SectionHeader(title: '📵 أكثر غياباً'),
                      const SizedBox(height: 10),
                      ...(data['mostAbsent'] as List).asMap().entries.map((e) {
                        final entry  = e.value as Map<String, dynamic>;
                        final s      = entry['student'] as Student;
                        final absent = entry['absent'] as int;
                        final pct    = entry['pct'] as double;
                        return AppUI.fadeSlide(
                          index: e.key + 5,
                          child: _AbsenceTile(
                            student: s, absentCount: absent, pct: pct,
                            onTap: () => Navigator.push(context,
                                MaterialPageRoute(builder: (_) =>
                                    StudentProfileScreen(student: s))),
                          ),
                        );
                      }),
                      const SizedBox(height: 16),
                    ],

                    // ── Risk Students ─────────────────────────
                    if ((data['studentsList'] as List).isNotEmpty) ...[
                      const _SectionHeader(title: '⚠️ يحتاجون متابعة'),
                      const SizedBox(height: 10),
                      RiskStudents(
                        students: (data['studentsList'] as List<Student>)
                            .take(5).toList(),
                        onTap: (s) => Navigator.push(context,
                            MaterialPageRoute(builder: (_) =>
                                StudentProfileScreen(student: s))),
                      ),
                      const SizedBox(height: 16),
                    ],

                    // ── Top Students ──────────────────────────
                    if ((data['topStudents'] as List).isNotEmpty) ...[
                      const _SectionHeader(title: '⭐ نجوم الفصل'),
                      const SizedBox(height: 10),
                      ...(data['topStudents'] as List<Student>)
                          .asMap().entries.map((e) => AppUI.fadeSlide(
                            index: e.key + 10,
                            child: _TopStudentTile(
                                student: e.value, rank: e.key),
                          )),
                    ],
                  ],
                ),
              );
            },
          ),
        ),
      ]),
    );
  }

  Widget _buildHeader(BuildContext context, AsyncValue state,
      DateTime now, List<String> months) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          colors: [AppColors.primary, AppColors.primaryLight],
          begin: Alignment.topLeft, end: Alignment.bottomRight,
        ),
      ),
      child: SafeArea(
        bottom: false,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
          child: Column(children: [
            Row(children: [
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(13)),
                child: const Center(child: Text('ن',
                    style: TextStyle(color: Colors.white, fontSize: 20,
                        fontWeight: FontWeight.bold))),
              ),
              const SizedBox(width: 12),
              Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('مرحباً، مستر نصر 👋',
                    style: TextStyle(color: Colors.white, fontSize: 14,
                        fontWeight: FontWeight.bold)),
                Text('${months[now.month]} ${now.year}',
                    style: const TextStyle(
                        color: Colors.white70, fontSize: 11)),
              ])),
              // Collection rate badge
              state.whenOrNull(data: (d) => Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.15),
                    borderRadius: BorderRadius.circular(20)),
                child: Text(
                  'تحصيل ${(d['collectionRate'] as double).toStringAsFixed(0)}%',
                  style: const TextStyle(color: Colors.white, fontSize: 11,
                      fontWeight: FontWeight.bold)),
              )) ?? const SizedBox.shrink(),
              const SizedBox(width: 8),
              IconButton(
                icon: const Icon(Icons.notifications_outlined,
                    color: Colors.white),
                onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) =>
                        const NotificationsScreen())),
              ),
            ]),
            const SizedBox(height: 16),
            // Quick actions
            Row(children: [
              _QuickAction(
                icon: Icons.person_add_rounded, label: 'طالب جديد',
                color: AppColors.success,
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const StudentsScreen())),
              ),
              const SizedBox(width: 10),
              _QuickAction(
                icon: Icons.qr_code_scanner_rounded, label: 'حضور QR',
                color: AppColors.accent,
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const QRScannerScreen(
                        groupName: '', sessionPrice: 0))),
              ),
              const SizedBox(width: 10),
              _QuickAction(
                icon: Icons.payments_rounded, label: 'اشتراك',
                color: AppColors.warning,
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const SubscriptionScreen())),
              ),
              const SizedBox(width: 10),
              Consumer(builder: (ctx, ref2, _) => _QuickAction(
                icon: Icons.refresh_rounded, label: 'تحديث',
                color: AppColors.purple,
                onTap: () => ref2.invalidate(dashboardProvider),
              )),
            ]),
          ]),
        ),
      ),
    );
  }
}

// ── Group Breakdown widget (Stage 4) ──────────────────────────

class _GroupBreakdown extends StatelessWidget {
  final List<Map<String, dynamic>> groups;
  const _GroupBreakdown({required this.groups});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('📊 توزيع المجموعات',
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
        const SizedBox(height: 14),
        ...groups.map((g) {
          final pct   = (g['attPct'] as double).clamp(0.0, 100.0);
          final color = pct >= 75 ? AppColors.success
              : pct >= 50 ? AppColors.warning : AppColors.danger;
          return Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                children: [
              Row(children: [
                Expanded(child: Text(g['group'] as String,
                    style: const TextStyle(fontSize: 12,
                        fontWeight: FontWeight.bold))),
                Text('${g['count']} طالب',
                    style: const TextStyle(
                        fontSize: 11, color: AppColors.textSecondary)),
                const SizedBox(width: 8),
                Text('${pct.toStringAsFixed(0)}%',
                    style: TextStyle(fontSize: 11,
                        fontWeight: FontWeight.bold, color: color)),
              ]),
              const SizedBox(height: 4),
              ClipRRect(
                borderRadius: BorderRadius.circular(4),
                child: LinearProgressIndicator(
                  value: pct / 100,
                  backgroundColor: AppColors.borderLight,
                  color: color, minHeight: 5,
                ),
              ),
            ]),
          );
        }),
      ]),
    );
  }
}

// ── Absence tile (Stage 4) ─────────────────────────────────────

class _AbsenceTile extends StatelessWidget {
  final Student student;
  final int     absentCount;
  final double  pct;
  final VoidCallback onTap;
  const _AbsenceTile({required this.student, required this.absentCount,
      required this.pct, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final color  = pct < 50 ? AppColors.danger : AppColors.warning;
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.25)),
        ),
        child: Row(children: [
          Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10)),
            child: Center(child: Text(student.displayInitial,
                style: TextStyle(color: color, fontWeight: FontWeight.bold))),
          ),
          const SizedBox(width: 10),
          Expanded(child: Column(
              crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(student.name, style: const TextStyle(
                fontWeight: FontWeight.bold, fontSize: 13)),
            Text(student.groupName, style: const TextStyle(
                fontSize: 11, color: AppColors.textSecondary)),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20)),
              child: Text('$absentCount غياب',
                  style: TextStyle(fontSize: 11,
                      fontWeight: FontWeight.bold, color: color)),
            ),
            const SizedBox(height: 2),
            Text('حضور ${pct.toStringAsFixed(0)}%',
                style: const TextStyle(fontSize: 9,
                    color: AppColors.textSecondary)),
          ]),
        ]),
      ),
    );
  }
}

// ── Helpers ────────────────────────────────────────────────────

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color color;
  final VoidCallback onTap;
  const _QuickAction({required this.icon, required this.label,
      required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) => Expanded(
    child: GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.15),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withOpacity(0.2)),
        ),
        child: Column(children: [
          Icon(icon, color: Colors.white, size: 20),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(
              color: Colors.white, fontSize: 10,
              fontWeight: FontWeight.bold)),
        ]),
      ),
    ),
  );
}

class _SectionHeader extends StatelessWidget {
  final String title;
  const _SectionHeader({required this.title});
  @override
  Widget build(BuildContext context) => Text(title,
      style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold));
}

class _TopStudentTile extends StatelessWidget {
  final Student student;
  final int rank;
  const _TopStudentTile({required this.student, required this.rank});

  @override
  Widget build(BuildContext context) {
    final isDark  = Theme.of(context).brightness == Brightness.dark;
    final medals  = ['🥇', '🥈', '🥉'];
    final medal   = rank < 3 ? medals[rank] : '⭐';
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AppColors.borderLight),
      ),
      child: Row(children: [
        Text(medal, style: const TextStyle(fontSize: 20)),
        const SizedBox(width: 10),
        Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(student.name, style: const TextStyle(
              fontWeight: FontWeight.bold, fontSize: 13)),
          Text(student.groupName, style: const TextStyle(
              fontSize: 11, color: AppColors.textSecondary)),
        ])),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
          decoration: BoxDecoration(
              color: AppColors.warning.withOpacity(0.12),
              borderRadius: BorderRadius.circular(20)),
          child: Text('${student.xp} XP',
              style: const TextStyle(fontSize: 12,
                  fontWeight: FontWeight.bold, color: AppColors.warning)),
        ),
      ]),
    );
  }
}
