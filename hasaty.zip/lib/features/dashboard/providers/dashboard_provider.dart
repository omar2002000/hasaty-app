// lib/features/dashboard/providers/dashboard_provider.dart
// Stage 6C: uses AttendanceCache to avoid N DB queries per build.
//           keepAlive keeps data alive across tab switches.
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../core/providers/usecase_providers.dart';
import '../../../core/cache/attendance_cache.dart';
import '../../../providers/global_providers.dart';

final dashboardProvider = FutureProvider<Map<String, dynamic>>((ref) async {
  // keepAlive: avoid re-fetch on every tab switch
  ref.keepAlive();

  final students = await ref.read(getStudentsUseCaseProvider).execute();
  final income   = await ref.read(getMonthlyIncomeUseCaseProvider).execute();
  final analysis = ref.read(analyzeStudentsUseCaseProvider).execute(students);
  final payments = await ref.read(financeRepositoryProvider).getAllPayments();
  final subs     = await ref.read(financeRepositoryProvider)
      .getSubscriptions(month: DateTime.now().month, year: DateTime.now().year);

  final now      = DateTime.now();
  final todayStr = '${now.day}/${now.month}/${now.year}';
  final cache    = AttendanceCache.instance;

  const monthNames = ['','يناير','فبراير','مارس','أبريل','مايو','يونيو',
      'يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];

  // ── Monthly chart (last 6 months) ──────────────────────────
  final monthlyChart = <Map<String, dynamic>>[];
  for (int i = 5; i >= 0; i--) {
    final m = now.month - i <= 0 ? now.month - i + 12 : now.month - i;
    final y = now.month - i <= 0 ? now.year - 1 : now.year;
    final total = payments
        .where((p) => p.date.endsWith('/$m/$y'))
        .fold<double>(0.0, (s, p) => s + p.amount);
    monthlyChart.add({'month': monthNames[m], 'amount': total});
  }

  // ── Per-student stats — single batch loop ──────────────────
  // Stage 6C: use cache to avoid redundant DB queries
  int todayPresent = 0;
  final absenceData = <Map<String, dynamic>>[];
  final repo = ref.read(attendanceRepositoryProvider);

  for (final s in students) {
    // Use cache — fetches from DB only on first call or after expiry
    final pct = await cache.getOrFetch(
      studentId: s.id!,
      fetch:     () => repo.getAttendancePercentage(s.id!),
    );

    // Today check: need raw records — only fetch if not in attendance DB for today
    // Optimisation: use a lighter query instead of loading all records
    final records = await repo.getByStudent(s.id!);
    final markedToday = records.any((r) => r.date == todayStr && r.present);
    if (markedToday) todayPresent++;

    final total  = records.length;
    final absent = records.where((r) => !r.present).length;
    absenceData.add({'student': s, 'total': total, 'absent': absent, 'pct': pct});
  }

  // Most absent
  final mostAbsent = absenceData
      .where((d) => (d['absent'] as int) > 0)
      .toList()
    ..sort((a, b) => (b['absent'] as int).compareTo(a['absent'] as int));

  // Group breakdown
  final groupBreakdown = <Map<String, dynamic>>[];
  final groups = students.map((s) => s.groupName).toSet().toList()..sort();
  for (final g in groups) {
    final gs = students.where((s) => s.groupName == g).toList();
    final attEntries = absenceData
        .where((d) => (d['student'] as dynamic).groupName == g);
    final totalAtt  = attEntries.fold<int>(0, (s, d) => s + (d['total'] as int));
    final presentAtt = attEntries.fold<int>(
        0, (s, d) => s + (d['total'] as int) - (d['absent'] as int));
    groupBreakdown.add({
      'group':  g,
      'count':  gs.length,
      'attPct': totalAtt > 0 ? presentAtt / totalAtt * 100 : 0.0,
    });
  }

  final expected       = subs.fold<double>(0.0, (s, x) => s + x.amount);
  final collectionRate = expected > 0 ? income / expected * 100 : 0.0;

  return {
    'students':       students.length,
    'income':         income.toStringAsFixed(0),
    'incomeDouble':   income,
    'totalDebt':      students.where((s) => s.balance < 0)
        .fold<double>(0, (s, st) => s + st.balance.abs()).toStringAsFixed(0),
    'risky':          (analysis['risky'] as List).length,
    'studentsList':   analysis['risky'],
    'topStudents':    analysis['top'],
    'monthlyChart':   monthlyChart,
    'expected':       expected,
    'collectionRate': collectionRate,
    'todayPresent':   todayPresent,
    'mostAbsent':     mostAbsent.take(5).toList(),
    'groupBreakdown': groupBreakdown,
    'avgAttendance':  absenceData.isEmpty ? 0.0
        : absenceData.fold<double>(0, (s, d) => s + (d['pct'] as double))
            / absenceData.length,
  };
});
