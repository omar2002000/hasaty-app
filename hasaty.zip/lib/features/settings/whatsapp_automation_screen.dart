// lib/features/settings/whatsapp_automation_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme/app_colors.dart';
import '../../core/constants/whatsapp_templates.dart';
import '../../domain/entities/student.dart';
import '../../providers/global_providers.dart';

// ── Providers ────────────────────────────────────────────────

final _debtStudentsProvider = FutureProvider<List<Student>>((ref) =>
    ref.read(studentRepositoryProvider).getStudentsWithDebt());

final _absentStudentsProvider = FutureProvider<List<Student>>((ref) async {
  final students = await ref.read(studentRepositoryProvider).getStudents();
  final absent   = <Student>[];
  for (final s in students) {
    final pct = await ref.read(attendanceRepositoryProvider).getAttendancePercentage(s.id!);
    if (pct < 60 && pct > 0) absent.add(s);
  }
  return absent;
});

// ─────────────────────────────────────────────────────────────

class WhatsAppAutomationScreen extends ConsumerStatefulWidget {
  const WhatsAppAutomationScreen({super.key});

  @override
  ConsumerState<WhatsAppAutomationScreen> createState() =>
      _WhatsAppAutomationScreenState();
}

class _WhatsAppAutomationScreenState
    extends ConsumerState<WhatsAppAutomationScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;

  static const _months = [
    '', 'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
    'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
  ];

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  // ── WhatsApp launcher ────────────────────────────────────
  Future<void> _send(Student s, String msg) async {
    final phone = s.phone.startsWith('0') ? s.phone.substring(1) : s.phone;
    final url   = Uri.parse(
        'https://wa.me/20$phone?text=${Uri.encodeComponent(msg)}');
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

  Future<void> _sendBulk(
      List<Student> students, String Function(Student) msgFn) async {
    for (final s in students) {
      await _send(s, msgFn(s));
      await Future.delayed(const Duration(seconds: 2));
    }
  }

  @override
  Widget build(BuildContext context) {
    final debtState   = ref.watch(_debtStudentsProvider);
    final absentState = ref.watch(_absentStudentsProvider);

    final debtCount   = debtState.valueOrNull?.length   ?? 0;
    final absentCount = absentState.valueOrNull?.length ?? 0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('مركز واتساب التلقائي'),
        bottom: TabBar(
          controller: _tab,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          indicatorColor: Colors.white,
          tabs: [
            Tab(text: 'مالي ($debtCount)'),
            Tab(text: 'غياب ($absentCount)'),
            const Tab(text: 'تقارير'),
          ],
        ),
      ),
      body: TabBarView(controller: _tab, children: [
        // ── Debt Tab ─────────────────────────────────────
        debtState.when(
          loading: () => const Center(child: CircularProgressIndicator(color: AppColors.primary)),
          error:   (e, _) => Center(child: Text('$e')),
          data: (students) => _listTab(
            items:    students,
            color:    AppColors.danger,
            emptyMsg: 'لا يوجد مديونون 🎉',
            infoFn:   (s) => '${s.balance.abs().toStringAsFixed(0)} ج دين',
            msgFn:    (s) => WhatsAppTemplates.debt(s.name, s.balance.abs().toStringAsFixed(0)),
          ),
        ),

        // ── Absent Tab ────────────────────────────────────
        absentState.when(
          loading: () => const Center(child: CircularProgressIndicator(color: AppColors.primary)),
          error:   (e, _) => Center(child: Text('$e')),
          data: (students) => _listTab(
            items:    students,
            color:    AppColors.warning,
            emptyMsg: 'لا يوجد طلاب بغياب عالٍ 🎉',
            infoFn:   (s) => 'غياب متكرر',
            msgFn:    (s) => WhatsAppTemplates.absence(s.name, s.groupName),
          ),
        ),

        // ── Reports Tab ───────────────────────────────────
        _reportsTab(),
      ]),
    );
  }

  Widget _reportsTab() {
    final now = DateTime.now();
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(children: [
        _tplCard(
          '📊 تقرير شهري للكل',
          'إرسال ملخص الأداء لكل الطلاب',
          AppColors.primary,
          () => _sendMonthlyAll(_months[now.month]),
        ),
        const SizedBox(height: 8),
        _tplCard(
          '🏆 تهنئة المتفوقين',
          'إرسال تهنئة لأعلى 3 طلاب XP',
          AppColors.warning,
          () => _sendExcellence(),
        ),
      ]),
    );
  }

  Widget _listTab({
    required List<Student> items,
    required Color color,
    required String emptyMsg,
    required String Function(Student) infoFn,
    required String Function(Student) msgFn,
  }) {
    return Column(children: [
      if (items.isNotEmpty)
        Padding(
          padding: const EdgeInsets.all(14),
          child: SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.send, size: 15, color: Colors.white),
              label: Text('إرسال للجميع (${items.length})',
                  style: const TextStyle(color: Colors.white)),
              style: ElevatedButton.styleFrom(
                backgroundColor: color, elevation: 0,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: () => _sendBulk(items, msgFn),
            ),
          ),
        ),
      Expanded(
        child: items.isEmpty
            ? Center(child: Text(emptyMsg,
                style: const TextStyle(color: AppColors.textSecondary)))
            : ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 14),
                itemCount: items.length,
                itemBuilder: (ctx, i) {
                  final s      = items[i];
                  final isDark = Theme.of(context).brightness == Brightness.dark;
                  return Container(
                    margin: const EdgeInsets.only(bottom: 7),
                    padding: const EdgeInsets.all(11),
                    decoration: BoxDecoration(
                      color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
                      borderRadius: BorderRadius.circular(11),
                      border: Border.all(color: color.withOpacity(0.2)),
                    ),
                    child: Row(children: [
                      Container(
                        width: 36, height: 36,
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Center(child: Text(s.displayInitial,
                            style: TextStyle(color: color, fontWeight: FontWeight.bold))),
                      ),
                      const SizedBox(width: 9),
                      Expanded(child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(s.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
                        Text(infoFn(s), style: TextStyle(fontSize: 11, color: color, fontWeight: FontWeight.bold)),
                      ])),
                      GestureDetector(
                        onTap: () => _send(s, msgFn(s)),
                        child: Container(
                          padding: const EdgeInsets.all(7),
                          decoration: BoxDecoration(
                            color: AppColors.success.withOpacity(0.12),
                            borderRadius: BorderRadius.circular(9),
                          ),
                          child: const Icon(Icons.chat, color: AppColors.success, size: 18),
                        ),
                      ),
                    ]),
                  );
                },
              ),
      ),
    ]);
  }

  Widget _tplCard(String title, String sub, Color color, VoidCallback onTap) =>
      Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: color.withOpacity(0.06),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: color.withOpacity(0.2)),
        ),
        child: Row(children: [
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
            Text(sub, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
          ])),
          ElevatedButton(
            onPressed: onTap,
            style: ElevatedButton.styleFrom(
              backgroundColor: color, elevation: 0,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
            ),
            child: const Text('إرسال', style: TextStyle(color: Colors.white, fontSize: 12)),
          ),
        ]),
      );

  Future<void> _sendMonthlyAll(String month) async {
    final students = await ref.read(studentRepositoryProvider).getStudents();
    for (final s in students) {
      final pct = await ref.read(attendanceRepositoryProvider).getAttendancePercentage(s.id!);
      await _send(s, WhatsAppTemplates.monthlyReport(
        s.name, month, pct.toStringAsFixed(0),
        s.balance.toStringAsFixed(0), '${s.xp}',
      ));
      await Future.delayed(const Duration(seconds: 2));
    }
  }

  Future<void> _sendExcellence() async {
    final students = await ref.read(studentRepositoryProvider).getStudents();
    for (final s in students.take(3)) {
      await _send(s, WhatsAppTemplates.excellence(s.name, s.levelName));
      await Future.delayed(const Duration(seconds: 2));
    }
  }
}
