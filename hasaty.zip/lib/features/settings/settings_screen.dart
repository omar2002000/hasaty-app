// lib/features/settings/settings_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/ui_helpers.dart';
import '../../main.dart';
import '../../data/services/backup_service.dart';
import 'archive_screen.dart';
import 'nasr_coins_screen.dart';
import 'notifications_screen.dart';
import 'whatsapp_automation_screen.dart';
import '../sessions/groups_screen.dart';
import '../risk/risk_screen.dart';
import '../export/export_screen.dart'; // Stage 5
import '../../core/security/auth_service.dart'; // Stage 7
import '../auth/lock_screen.dart'; // Stage 7
import 'activity_log_screen.dart'; // Stage 8
import '../analytics/analytics_screen.dart'; // Stage 9

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Scaffold(
      appBar: AppBar(title: const Text('الإعدادات')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(18),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [

          // ── Profile Card ───────────────────────────────────
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: const LinearGradient(
                  colors: [AppColors.primary, AppColors.primaryLight]),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Row(children: [
              Container(
                width: 58, height: 58,
                decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(16)),
                child: const Center(child: Text('ن',
                    style: TextStyle(color: Colors.white, fontSize: 25,
                        fontWeight: FontWeight.bold))),
              ),
              const SizedBox(width: 14),
              const Expanded(child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start, children: [
                Text('مستر نصر علي',
                    style: TextStyle(color: Colors.white, fontSize: 17,
                        fontWeight: FontWeight.bold)),
                Text('معلم اللغة الإنجليزية',
                    style: TextStyle(color: Colors.white70, fontSize: 12)),
                SizedBox(height: 4),
                Text('حصتي v4.0 🚀',
                    style: TextStyle(color: Colors.white60, fontSize: 11)),
              ])),
            ]),
          ),
          const SizedBox(height: 22),

          // ── Appearance ─────────────────────────────────────
          _label('المظهر'),
          _tile(context,
            icon: isDark ? Icons.light_mode : Icons.dark_mode,
            color: AppColors.purple,
            title: 'الوضع الليلي',
            subtitle: isDark ? 'مفعّل' : 'غير مفعّل',
            trailing: Switch(
              value: isDark,
              activeColor: AppColors.primary,
              onChanged: (v) => HasatyApp.of(context)?.toggleTheme(v),
            ),
          ),
          const SizedBox(height: 16),

          // ── Tools ──────────────────────────────────────────
          _label('الأدوات'),
          _tile(context,
            icon: Icons.groups_outlined,
            color: AppColors.accent,
            title: 'المجموعات',
            subtitle: 'إدارة مجموعات الطلاب',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const GroupsScreen())),
          ),
          _tile(context,
            icon: Icons.bar_chart_rounded,
            color: AppColors.purple,
            title: 'التحليلات المتقدمة',
            subtitle: 'رسوم بيانية: الحضور، الإيراد، الطلاب',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const AnalyticsScreen())),
          ),
          _tile(context,
            icon: Icons.upload_file_rounded,
            color: AppColors.accent,
            title: 'تصدير البيانات',
            subtitle: 'PDF للطلاب والمجموعات + Excel الحضور',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const ExportScreen())),
          ),
          _tile(context,
            icon: Icons.warning_amber_rounded,
            color: AppColors.danger,
            title: 'تحليل المخاطر',
            subtitle: 'الطلاب في خطر مالي أو انتظام',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const RiskScreen())),
          ),
          _tile(context,
            icon: Icons.campaign_rounded,
            color: AppColors.success,
            title: 'مركز واتساب التلقائي',
            subtitle: 'إرسال رسائل جماعية وتقارير',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(
                    builder: (_) => const WhatsAppAutomationScreen())),
          ),
          _tile(context,
            icon: Icons.monetization_on_outlined,
            color: AppColors.warning,
            title: 'عملة نصر 🪙',
            subtitle: 'نقاط التحفيز ومتجر المكافآت',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const NasrCoinsScreen())),
          ),
          _tile(context,
            icon: Icons.notifications_outlined,
            color: AppColors.primary,
            title: 'مركز الإشعارات',
            subtitle: 'تنبيهات الديون والغياب',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(
                    builder: (_) => const NotificationsScreen())),
          ),
          _tile(context,
            icon: Icons.archive_outlined,
            color: AppColors.textSecondary,
            title: 'أرشيف الطلاب',
            subtitle: 'الطلاب المنقطعون',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const ArchiveScreen())),
          ),
          const SizedBox(height: 16),

          
          // ── Stage 7: Security ─────────────────────────────
          _label('الأمان والخصوصية'),
          _LockTile(),
          const SizedBox(height: 16),

          // ── Stage 8: Activity Log ─────────────────────────
          _label('السجل والمتابعة'),
          _tile(context,
            icon: Icons.history_rounded,
            color: AppColors.purple,
            title: 'سجل النشاط',
            subtitle: 'تتبع العمليات: إضافة / تعديل / حذف / حضور',
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const ActivityLogScreen())),
          ),
          const SizedBox(height: 16),

          // ── Backup ─────────────────────────────────────────
          _label('النسخ الاحتياطي'),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
              borderRadius: BorderRadius.circular(14),
              border: Border.all(
                  color: isDark ? AppColors.borderDark : AppColors.borderLight),
            ),
            child: Column(children: [
              const Row(children: [
                Icon(Icons.backup_rounded, color: AppColors.primary, size: 20),
                SizedBox(width: 8),
                Text('بيانات التطبيق',
                    style: TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 14)),
              ]),
              const SizedBox(height: 6),
              const Text(
                'صدّر نسخة احتياطية كاملة من قاعدة البيانات أو استعدها.',
                style: TextStyle(
                    fontSize: 11, color: AppColors.textSecondary, height: 1.5),
              ),
              const SizedBox(height: 14),
              Row(children: [
                Expanded(
                  child: ElevatedButton.icon(
                    icon: const Icon(Icons.upload_rounded, size: 16),
                    label: const Text('تصدير النسخة',
                        style: TextStyle(fontSize: 12)),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                    onPressed: () async {
                      final ok = await BackupService.instance.exportDatabase();
                      if (context.mounted) {
                        AppUI.showToast(context,
                            ok ? '✅ تم تصدير النسخة الاحتياطية'
                               : 'فشل التصدير',
                            isError: !ok);
                      }
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: OutlinedButton.icon(
                    icon: const Icon(Icons.download_rounded, size: 16),
                    label: const Text('استعادة',
                        style: TextStyle(fontSize: 12)),
                    style: OutlinedButton.styleFrom(
                      side: const BorderSide(color: AppColors.warning),
                      foregroundColor: AppColors.warning,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10)),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                    ),
                    onPressed: () async {
                      // Confirm
                      final ok = await showDialog<bool>(
                        context: context,
                        builder: (_) => AlertDialog(
                          shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(16)),
                          title: const Text('تحذير'),
                          content: const Text(
                              'ستحل البيانات المستوردة محل البيانات الحالية. هل أنت متأكد؟'),
                          actions: [
                            TextButton(
                                onPressed: () => Navigator.pop(context, false),
                                child: const Text('إلغاء')),
                            ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: AppColors.warning),
                              onPressed: () => Navigator.pop(context, true),
                              child: const Text('متأكد',
                                  style: TextStyle(color: Colors.white)),
                            ),
                          ],
                        ),
                      );
                      if (ok != true || !context.mounted) return;
                      final res =
                          await BackupService.instance.importDatabase();
                      if (context.mounted) {
                        AppUI.showToast(context,
                            res ? '✅ تم استعادة النسخة — أعد التشغيل'
                               : 'فشل الاستيراد',
                            isError: !res);
                      }
                    },
                  ),
                ),
              ]),
            ]),
          ),
          const SizedBox(height: 16),

          // ── About ──────────────────────────────────────────
          _label('عن التطبيق'),
          _tile(context,
            icon: Icons.info_outline,
            color: AppColors.primary,
            title: 'الإصدار',
            subtitle: 'حصتي v4.0 — مستر نصر علي',
          ),
          _tile(context,
            icon: Icons.architecture_rounded,
            color: AppColors.accent,
            title: 'المعمارية',
            subtitle: 'Clean Architecture + Riverpod ✅',
          ),
        ]),
      ),
    );
  }

  static Widget _label(String t) => Padding(
      padding: const EdgeInsets.only(bottom: 7),
      child: Text(t, style: const TextStyle(
          fontSize: 12, color: AppColors.textSecondary,
          fontWeight: FontWeight.bold)));

  static Widget _tile(BuildContext context, {
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    Widget? trailing,
    VoidCallback? onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      margin: const EdgeInsets.only(bottom: 7),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(13),
        border: Border.all(
            color: isDark ? AppColors.borderDark : AppColors.borderLight),
      ),
      child: ListTile(
        onTap: onTap,
        leading: Container(
          width: 38, height: 38,
          decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(11)),
          child: Icon(icon, color: color, size: 19),
        ),
        title: Text(title,
            style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
        subtitle: Text(subtitle,
            style: const TextStyle(
                fontSize: 11, color: AppColors.textSecondary)),
        trailing: trailing ??
            (onTap != null
                ? Icon(Icons.arrow_forward_ios,
                    size: 13, color: Colors.grey.shade400)
                : null),
      ),
    );
  }
}

// ══════════════════════════════════════════════════════════════
// Stage 7 — Lock tile widget
// Stateful so it reads & updates lock state reactively.
// Lives in settings_screen.dart to keep changes isolated.
// ══════════════════════════════════════════════════════════════

class _LockTile extends StatefulWidget {
  const _LockTile();
  @override
  State<_LockTile> createState() => _LockTileState();
}

class _LockTileState extends State<_LockTile> {
  bool   _enabled   = false;
  String _lockType  = 'pin';
  bool   _bioAvail  = false;
  bool   _loading   = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final en   = await AuthService.instance.isLockEnabled;
    final type = await AuthService.instance.lockType;
    final bio  = await AuthService.instance.isBiometricAvailable;
    if (mounted) setState(() {
      _enabled  = en;
      _lockType = type;
      _bioAvail = bio;
      _loading  = false;
    });
  }

  Future<void> _toggle(bool val) async {
    if (val) {
      // Enable: ask for PIN setup
      await _showPinSetup();
    } else {
      await AuthService.instance.disableLock();
      setState(() { _enabled = false; _lockType = 'pin'; });
    }
  }

  Future<void> _showPinSetup() async {
    String pin1 = '', pin2 = '';
    final result = await showDialog<String>(
      context: context,
      barrierDismissible: false,
      builder: (_) => _PinSetupDialog(),
    );
    if (result != null && result.length == 4 && mounted) {
      await AuthService.instance.setPin(result);
      setState(() { _enabled = true; _lockType = 'pin'; });
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ تم تفعيل القفل بالرقم السري'),
            backgroundColor: AppColors.success,
            behavior: SnackBarBehavior.floating),
      );
    }
  }

  Future<void> _switchToBiometric() async {
    final ok = await AuthService.instance.authenticateWithBiometric();
    if (ok && mounted) {
      await AuthService.instance.enableBiometricLock();
      setState(() => _lockType = 'biometric');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('✅ تم تفعيل القفل ببصمة الإصبع'),
            backgroundColor: AppColors.success,
            behavior: SnackBarBehavior.floating),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const SizedBox(height: 56,
        child: Center(child: CircularProgressIndicator(
            color: AppColors.primary, strokeWidth: 2)));

    final isDark = Theme.of(context).brightness == Brightness.dark;

    return Column(children: [
      // Lock enable/disable
      Container(
        margin: const EdgeInsets.only(bottom: 7),
        decoration: BoxDecoration(
          color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
          borderRadius: BorderRadius.circular(13),
          border: Border.all(color: isDark ? AppColors.borderDark : AppColors.borderLight),
        ),
        child: ListTile(
          leading: Container(
            width: 38, height: 38,
            decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(11)),
            child: const Icon(Icons.lock_outline, color: AppColors.primary, size: 19),
          ),
          title: const Text('قفل التطبيق',
              style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
          subtitle: Text(_enabled
              ? 'مفعّل — ${_lockType == 'biometric' ? 'بصمة' : 'رقم سري'}'
              : 'غير مفعّل',
              style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
          trailing: Switch(
            value: _enabled,
            activeColor: AppColors.primary,
            onChanged: _toggle,
          ),
        ),
      ),
      // Biometric option (shown when lock enabled + bio available + currently PIN)
      if (_enabled && _bioAvail && _lockType == 'pin')
        Container(
          margin: const EdgeInsets.only(bottom: 7),
          decoration: BoxDecoration(
            color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
            borderRadius: BorderRadius.circular(13),
            border: Border.all(color: isDark ? AppColors.borderDark : AppColors.borderLight),
          ),
          child: ListTile(
            leading: Container(
              width: 38, height: 38,
              decoration: BoxDecoration(
                  color: AppColors.accent.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(11)),
              child: const Icon(Icons.fingerprint, color: AppColors.accent, size: 19),
            ),
            title: const Text('تفعيل بصمة الإصبع',
                style: TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
            subtitle: const Text('استخدم البصمة بدلاً من الرقم السري',
                style: TextStyle(fontSize: 11, color: AppColors.textSecondary)),
            trailing: const Icon(Icons.arrow_forward_ios, size: 13, color: Colors.grey),
            onTap: _switchToBiometric,
          ),
        ),
    ]);
  }
}

// ── PIN Setup Dialog ──────────────────────────────────────────

class _PinSetupDialog extends StatefulWidget {
  @override
  State<_PinSetupDialog> createState() => _PinSetupDialogState();
}

class _PinSetupDialogState extends State<_PinSetupDialog> {
  final _ctrl1 = TextEditingController();
  final _ctrl2 = TextEditingController();
  String _error = '';

  @override
  void dispose() {
    _ctrl1.dispose();
    _ctrl2.dispose();
    super.dispose();
  }

  void _confirm() {
    final p1 = _ctrl1.text.trim();
    final p2 = _ctrl2.text.trim();
    if (p1.length < 4) {
      setState(() => _error = 'الرقم السري يجب أن يكون 4 أرقام على الأقل');
      return;
    }
    if (p1 != p2) {
      setState(() => _error = 'الرقمان لا يتطابقان');
      return;
    }
    Navigator.pop(context, p1);
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
      title: const Row(children: [
        Icon(Icons.lock_rounded, color: AppColors.primary),
        SizedBox(width: 8),
        Text('إعداد رقم السري', style: TextStyle(fontSize: 16)),
      ]),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        TextField(
          controller: _ctrl1,
          obscureText: true,
          keyboardType: TextInputType.number,
          maxLength: 8,
          decoration: const InputDecoration(
            labelText: 'رقم السري الجديد',
            prefixIcon: Icon(Icons.pin_rounded),
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _ctrl2,
          obscureText: true,
          keyboardType: TextInputType.number,
          maxLength: 8,
          decoration: const InputDecoration(
            labelText: 'تأكيد الرقم السري',
            prefixIcon: Icon(Icons.pin_rounded),
          ),
        ),
        if (_error.isNotEmpty) ...[
          const SizedBox(height: 6),
          Text(_error, style: const TextStyle(color: AppColors.danger, fontSize: 11)),
        ],
      ]),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context),
          child: const Text('إلغاء'),
        ),
        ElevatedButton(
          onPressed: _confirm,
          child: const Text('تأكيد'),
        ),
      ],
    );
  }
}
