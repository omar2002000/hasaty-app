// lib/features/settings/archive_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/ui_helpers.dart';
import '../../domain/entities/student.dart';
import '../../providers/global_providers.dart';

final _archivedProvider = FutureProvider<List<Student>>((ref) =>
    ref.read(studentRepositoryProvider).getArchivedStudents());

class ArchiveScreen extends ConsumerWidget {
  const ArchiveScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(_archivedProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('أرشيف الطلاب')),
      body: state.when(
        loading: () => const Center(child: CircularProgressIndicator(color: AppColors.primary)),
        error:   (e, _) => Center(child: Text('$e')),
        data: (students) => students.isEmpty
            ? const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                Icon(Icons.archive_outlined, size: 64, color: AppColors.textSecondary),
                SizedBox(height: 12),
                Text('لا يوجد طلاب مؤرشفون', style: TextStyle(color: AppColors.textSecondary)),
              ]))
            : ListView.builder(
                padding: const EdgeInsets.all(14),
                itemCount: students.length,
                itemBuilder: (_, i) {
                  final s = students[i];
                  final isDark = Theme.of(context).brightness == Brightness.dark;
                  return Container(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    decoration: BoxDecoration(
                      color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
                      borderRadius: BorderRadius.circular(14),
                      border: Border.all(color: AppColors.borderLight),
                    ),
                    child: Row(children: [
                      Container(
                        width: 42, height: 42,
                        decoration: BoxDecoration(
                          color: AppColors.textSecondary.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Center(child: Text(s.displayInitial,
                            style: const TextStyle(color: AppColors.textSecondary, fontWeight: FontWeight.bold))),
                      ),
                      const SizedBox(width: 12),
                      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(s.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        Text(s.groupName, style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                      ])),
                      Row(mainAxisSize: MainAxisSize.min, children: [
                        TextButton.icon(
                          icon: const Icon(Icons.restore, size: 15),
                          label: const Text('استعادة', style: TextStyle(fontSize: 12)),
                          onPressed: () async {
                            await ref.read(studentRepositoryProvider).restoreStudent(s.id!);
                            ref.invalidate(_archivedProvider);
                            if (context.mounted) AppUI.showToast(context, 'تم استعادة \${s.name}');
                          },
                        ),
                        // Stage 2B: hard delete from archive
                        IconButton(
                          icon: const Icon(Icons.delete_forever_rounded,
                              color: AppColors.danger, size: 18),
                          tooltip: 'حذف نهائي',
                          onPressed: () async {
                            final ok = await showDialog<bool>(
                              context: context,
                              builder: (_) => AlertDialog(
                                title: const Text('حذف نهائي'),
                                content: Text('حذف "\${s.name}" نهائياً؟\nلا يمكن التراجع.'),
                                actions: [
                                  TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
                                  ElevatedButton(
                                    style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger),
                                    onPressed: () => Navigator.pop(context, true),
                                    child: const Text('حذف', style: TextStyle(color: Colors.white)),
                                  ),
                                ],
                              ),
                            );
                            if (ok == true) {
                              await ref.read(studentRepositoryProvider).hardDeleteStudent(s.id!);
                              ref.invalidate(_archivedProvider);
                              if (context.mounted) AppUI.showToast(context, 'تم الحذف النهائي');
                            }
                          },
                        ),
                      ]),
                    ]),
                  );
                },
              ),
      ),
    );
  }
}
