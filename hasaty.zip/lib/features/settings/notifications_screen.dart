// lib/features/settings/notifications_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/ui_helpers.dart';
import '../../core/widgets/shimmer_loading.dart';
import '../../domain/entities/app_notification.dart';
import '../../providers/global_providers.dart';

final _notificationsProvider =
    FutureProvider<List<AppNotification>>((ref) =>
        ref.read(notificationRepositoryProvider).getAllNotifications());

final _unreadCountProvider = FutureProvider<int>((ref) =>
    ref.read(notificationRepositoryProvider).getUnreadCount());

class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state       = ref.watch(_notificationsProvider);
    final unreadCount = ref.watch(_unreadCountProvider).valueOrNull ?? 0;

    return Scaffold(
      appBar: AppBar(
        title: Row(children: [
          const Text('الإشعارات'),
          if (unreadCount > 0) ...[
            const SizedBox(width: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
              decoration: BoxDecoration(
                  color: AppColors.danger,
                  borderRadius: BorderRadius.circular(10)),
              child: Text('$unreadCount',
                  style: const TextStyle(color: Colors.white,
                      fontSize: 11, fontWeight: FontWeight.bold)),
            ),
          ],
        ]),
        actions: [
          // Smart generate
          IconButton(
            icon: const Icon(Icons.auto_awesome_rounded),
            tooltip: 'توليد تنبيهات ذكية',
            onPressed: () async {
              await ref.read(notificationRepositoryProvider)
                  .generateSmartNotifications();
              ref.invalidate(_notificationsProvider);
              ref.invalidate(_unreadCountProvider);
              if (context.mounted) {
                AppUI.showToast(context, '✅ تم توليد التنبيهات الذكية');
              }
            },
          ),
          // Mark all read
          TextButton(
            onPressed: () async {
              await ref.read(notificationRepositoryProvider).markAllRead();
              ref.invalidate(_notificationsProvider);
              ref.invalidate(_unreadCountProvider);
            },
            child: const Text('قراءة الكل',
                style: TextStyle(color: Colors.white, fontSize: 12)),
          ),
        ],
      ),
      body: state.when(
        loading: () => const ListShimmer(count: 6),
        error:   (e, _) => Center(child: Text('خطأ: $e')),
        data: (notifications) {
          if (notifications.isEmpty) {
            return Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    padding: const EdgeInsets.all(22),
                    decoration: BoxDecoration(
                        color: AppColors.primary.withOpacity(0.06),
                        shape: BoxShape.circle),
                    child: const Icon(Icons.notifications_none_rounded,
                        size: 52, color: AppColors.textSecondary),
                  ),
                  const SizedBox(height: 16),
                  const Text('لا توجد إشعارات',
                      style: TextStyle(
                          fontSize: 16, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  const Text(
                    'اضغط ✨ لتوليد تنبيهات ذكية\nبناءً على بيانات طلابك',
                    style: TextStyle(fontSize: 12,
                        color: AppColors.textSecondary, height: 1.6),
                    textAlign: TextAlign.center,
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.auto_awesome_rounded),
                    label: const Text('توليد تنبيهات الآن'),
                    onPressed: () async {
                      await ref.read(notificationRepositoryProvider)
                          .generateSmartNotifications();
                      ref.invalidate(_notificationsProvider);
                      ref.invalidate(_unreadCountProvider);
                    },
                  ),
                ],
              ),
            );
          }

          // Group by type
          final debt    = notifications.where((n) => n.type == 'debt').toList();
          final absence = notifications.where((n) => n.type == 'absence').toList();
          final other   = notifications.where((n) =>
              n.type != 'debt' && n.type != 'absence').toList();

          return RefreshIndicator(
            color: AppColors.primary,
            onRefresh: () => ref.refresh(_notificationsProvider.future),
            child: ListView(
              padding: const EdgeInsets.all(14),
              children: [
                // Summary bar
                Container(
                  padding: const EdgeInsets.all(12),
                  margin: const EdgeInsets.only(bottom: 16),
                  decoration: BoxDecoration(
                    color: AppColors.primary.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(
                        color: AppColors.primary.withOpacity(0.15)),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _TypeSummary('💰', 'ديون', debt.length, AppColors.danger),
                      _TypeSummary('📵', 'غياب', absence.length, AppColors.warning),
                      _TypeSummary('🔔', 'أخرى', other.length, AppColors.primary),
                    ],
                  ),
                ),

                if (debt.isNotEmpty) ...[
                  _GroupHeader('💰 تنبيهات الديون', AppColors.danger),
                  ...debt.map((n) => _NotificationTile(notification: n)),
                  const SizedBox(height: 12),
                ],
                if (absence.isNotEmpty) ...[
                  _GroupHeader('📵 تنبيهات الغياب', AppColors.warning),
                  ...absence.map((n) => _NotificationTile(notification: n)),
                  const SizedBox(height: 12),
                ],
                if (other.isNotEmpty) ...[
                  _GroupHeader('🔔 إشعارات أخرى', AppColors.primary),
                  ...other.map((n) => _NotificationTile(notification: n)),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}

class _TypeSummary extends StatelessWidget {
  final String icon, label;
  final int count;
  final Color color;
  const _TypeSummary(this.icon, this.label, this.count, this.color);

  @override
  Widget build(BuildContext context) => Column(children: [
    Text(icon, style: const TextStyle(fontSize: 20)),
    Text('$count', style: TextStyle(fontWeight: FontWeight.bold,
        fontSize: 16, color: color)),
    Text(label, style: const TextStyle(
        fontSize: 10, color: AppColors.textSecondary)),
  ]);
}

class _GroupHeader extends StatelessWidget {
  final String title;
  final Color color;
  const _GroupHeader(this.title, this.color);

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
    margin: const EdgeInsets.only(bottom: 8),
    decoration: BoxDecoration(
        color: color.withOpacity(0.08),
        borderRadius: BorderRadius.circular(8)),
    child: Text(title,
        style: TextStyle(fontWeight: FontWeight.bold,
            fontSize: 12, color: color)),
  );
}

class _NotificationTile extends StatelessWidget {
  final AppNotification notification;
  const _NotificationTile({required this.notification});

  Color get _color {
    switch (notification.type) {
      case 'debt':       return AppColors.danger;
      case 'absence':    return AppColors.warning;
      case 'excellence': return AppColors.success;
      default:           return AppColors.primary;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: notification.isRead
            ? (isDark ? AppColors.bgCardDark : AppColors.bgCard)
            : _color.withOpacity(0.04),
        borderRadius: BorderRadius.circular(13),
        border: Border.all(
          color: notification.isRead
              ? AppColors.borderLight
              : _color.withOpacity(0.25),
          width: notification.isRead ? 1 : 1.5,
        ),
      ),
      child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          width: 40, height: 40,
          decoration: BoxDecoration(
              color: _color.withOpacity(0.1), shape: BoxShape.circle),
          child: Center(child: Text(notification.typeIcon,
              style: const TextStyle(fontSize: 18))),
        ),
        const SizedBox(width: 12),
        Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(notification.title,
                style: TextStyle(fontWeight: FontWeight.bold,
                    fontSize: 13, color: notification.isRead ? null : _color))),
            if (!notification.isRead)
              Container(width: 8, height: 8,
                  decoration: BoxDecoration(
                      color: _color, shape: BoxShape.circle)),
          ]),
          const SizedBox(height: 3),
          Text(notification.body,
              style: const TextStyle(
                  fontSize: 12, color: AppColors.textSecondary)),
          const SizedBox(height: 4),
          Text(notification.date,
              style: const TextStyle(
                  fontSize: 10, color: AppColors.textSecondary)),
        ])),
      ]),
    );
  }
}
