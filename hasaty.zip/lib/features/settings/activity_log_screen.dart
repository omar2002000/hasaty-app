// lib/features/settings/activity_log_screen.dart
// ─────────────────────────────────────────────────────────────
// Stage 8 — Activity log screen.
// Shows all audit_logs entries, newest first.
// Filter chips for each action type.
// ─────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../domain/entities/audit_log.dart';
import '../../providers/global_providers.dart';

final _auditLogsProvider = FutureProvider<List<AuditLog>>((ref) =>
    ref.read(auditLogRepositoryProvider).getAll(limit: 300));

class ActivityLogScreen extends ConsumerStatefulWidget {
  const ActivityLogScreen({super.key});

  @override
  ConsumerState<ActivityLogScreen> createState() => _ActivityLogScreenState();
}

class _ActivityLogScreenState extends ConsumerState<ActivityLogScreen> {
  String? _filter; // null = all, else action type

  static const _filters = [
    ('all',        'الكل',     null),
    ('add',        '➕ إضافة', AppColors.success),
    ('edit',       '✏️ تعديل', AppColors.primary),
    ('archive',    '📦 أرشفة', AppColors.warning),
    ('delete',     '🗑️ حذف',  AppColors.danger),
    ('attendance', '✅ حضور',  AppColors.accent),
    ('payment',    '💰 دفعة',  AppColors.purple),
  ];

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(_auditLogsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('سجل النشاط'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () => ref.invalidate(_auditLogsProvider),
          ),
        ],
      ),
      body: Column(children: [
        // ── Filter chips ────────────────────────────────────
        Container(
          height: 48,
          color: Theme.of(context).brightness == Brightness.dark
              ? AppColors.bgCardDark : AppColors.bgCard,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            itemCount: _filters.length,
            separatorBuilder: (_, __) => const SizedBox(width: 6),
            itemBuilder: (_, i) {
              final (type, label, color) = _filters[i];
              final isAll      = type == 'all';
              final isSelected = isAll ? _filter == null : _filter == type;
              final chipColor  = color ?? AppColors.primary;
              return GestureDetector(
                onTap: () => setState(() =>
                    _filter = isAll ? null : type),
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 160),
                  padding: const EdgeInsets.symmetric(horizontal: 12),
                  decoration: BoxDecoration(
                    color: isSelected
                        ? chipColor : chipColor.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: isSelected
                        ? chipColor : chipColor.withOpacity(0.3)),
                  ),
                  child: Center(child: Text(label,
                      style: TextStyle(
                        fontSize: 11, fontWeight: FontWeight.bold,
                        color: isSelected ? Colors.white : chipColor,
                      ))),
                ),
              );
            },
          ),
        ),

        // ── List ────────────────────────────────────────────
        Expanded(
          child: state.when(
            loading: () => const Center(child: CircularProgressIndicator(
                color: AppColors.primary)),
            error:   (e, _) => Center(child: Text('خطأ: $e')),
            data: (logs) {
              final filtered = _filter == null
                  ? logs
                  : logs.where((l) => l.actionType == _filter).toList();

              if (filtered.isEmpty) {
                return Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Icon(Icons.history_rounded,
                          size: 56, color: AppColors.textSecondary),
                      const SizedBox(height: 12),
                      Text(_filter == null
                          ? 'لا يوجد سجل بعد'
                          : 'لا يوجد ${_filters.firstWhere((f) => f.$1 == _filter, orElse: () => ('', 'سجل', null)).$2}',
                          style: const TextStyle(color: AppColors.textSecondary)),
                    ],
                  ),
                );
              }

              // Group by date
              final grouped = <String, List<AuditLog>>{};
              for (final log in filtered) {
                final date = log.timestamp.split(' ').first;
                grouped.putIfAbsent(date, () => []).add(log);
              }

              return RefreshIndicator(
                color: AppColors.primary,
                onRefresh: () => ref.refresh(_auditLogsProvider.future),
                child: ListView.builder(
                  padding: const EdgeInsets.all(14),
                  itemCount: grouped.length,
                  itemBuilder: (_, gi) {
                    final date    = grouped.keys.elementAt(gi);
                    final entries = grouped[date]!;
                    return Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Date header
                        Padding(
                          padding: const EdgeInsets.symmetric(vertical: 8),
                          child: Text(date,
                              style: const TextStyle(
                                  fontSize: 12,
                                  fontWeight: FontWeight.bold,
                                  color: AppColors.textSecondary)),
                        ),
                        ...entries.map((log) => _LogTile(log: log)),
                      ],
                    );
                  },
                ),
              );
            },
          ),
        ),
      ]),
    );
  }
}

class _LogTile extends StatelessWidget {
  final AuditLog log;
  const _LogTile({required this.log});

  Color get _color {
    switch (log.actionType) {
      case 'add':        return AppColors.success;
      case 'edit':       return AppColors.primary;
      case 'archive':    return AppColors.warning;
      case 'delete':     return AppColors.danger;
      case 'attendance': return AppColors.accent;
      case 'payment':    return AppColors.purple;
      default:           return AppColors.textSecondary;
    }
  }

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final time   = log.timestamp.contains(' ')
        ? log.timestamp.split(' ').last : '';

    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.all(11),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(11),
        border: Border.all(color: _color.withOpacity(0.15)),
      ),
      child: Row(children: [
        Container(
          width: 36, height: 36,
          decoration: BoxDecoration(
              color: _color.withOpacity(0.1), shape: BoxShape.circle),
          child: Center(child: Text(log.actionIcon,
              style: const TextStyle(fontSize: 16))),
        ),
        const SizedBox(width: 10),
        Expanded(child: Column(
            crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(log.description,
              style: const TextStyle(fontSize: 12,
                  fontWeight: FontWeight.bold),
              maxLines: 2, overflow: TextOverflow.ellipsis),
          if (log.studentName.isNotEmpty) ...[
            const SizedBox(height: 2),
            Text(log.studentName,
                style: const TextStyle(fontSize: 10,
                    color: AppColors.textSecondary)),
          ],
        ])),
        const SizedBox(width: 6),
        Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
            decoration: BoxDecoration(
                color: _color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(10)),
            child: Text(log.actionLabel,
                style: TextStyle(fontSize: 9,
                    fontWeight: FontWeight.bold, color: _color)),
          ),
          const SizedBox(height: 3),
          Text(time, style: const TextStyle(
              fontSize: 9, color: AppColors.textSecondary)),
        ]),
      ]),
    );
  }
}
