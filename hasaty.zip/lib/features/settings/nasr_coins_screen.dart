// lib/features/settings/nasr_coins_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/ui_helpers.dart';
import '../../domain/entities/student.dart';
import '../../providers/global_providers.dart';

final _coinsStudentsProvider = FutureProvider<List<Student>>((ref) =>
    ref.read(studentRepositoryProvider).getStudents());

class NasrCoinsScreen extends ConsumerWidget {
  const NasrCoinsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(_coinsStudentsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Text('عملة نصر'),
          SizedBox(width: 6),
          Text('🪙', style: TextStyle(fontSize: 18)),
        ]),
      ),
      body: state.when(
        loading: () => const Center(child: CircularProgressIndicator(color: AppColors.primary)),
        error:   (e, _) => Center(child: Text('$e')),
        data: (students) => Column(children: [
          Container(
            padding: const EdgeInsets.all(14),
            color: AppColors.warning.withOpacity(0.06),
            child: const Row(children: [
              Icon(Icons.info_outline, color: AppColors.warning, size: 16),
              SizedBox(width: 8),
              Expanded(child: Text('النقاط تُكسب من الحضور والدفع المنتظم. يمكن صرفها على مكافآت.',
                  style: TextStyle(fontSize: 12, color: AppColors.textSecondary))),
            ]),
          ),
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(14),
              itemCount: students.length,
              itemBuilder: (_, i) {
                final s = students[i];
                final isDark = Theme.of(context).brightness == Brightness.dark;
                return Container(
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(11),
                  decoration: BoxDecoration(
                    color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.borderLight),
                  ),
                  child: Row(children: [
                    Text(i < 3 ? ['🥇','🥈','🥉'][i] : '${i+1}',
                        style: TextStyle(fontSize: i < 3 ? 20 : 13, fontWeight: FontWeight.bold)),
                    const SizedBox(width: 8),
                    Container(
                      width: 34, height: 34,
                      decoration: BoxDecoration(
                        color: AppColors.warning.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(9),
                      ),
                      child: Center(child: Text(s.displayInitial,
                          style: const TextStyle(color: AppColors.warning, fontWeight: FontWeight.bold))),
                    ),
                    const SizedBox(width: 9),
                    Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(s.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                      Text(s.groupName, style: const TextStyle(fontSize: 10, color: AppColors.textSecondary)),
                    ])),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 4),
                      decoration: BoxDecoration(
                        color: AppColors.warning.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Row(children: [
                        const Text('🪙', style: TextStyle(fontSize: 13)),
                        const SizedBox(width: 4),
                        Text('${s.coins}', style: const TextStyle(fontWeight: FontWeight.bold, color: AppColors.warning, fontSize: 13)),
                      ]),
                    ),
                    const SizedBox(width: 8),
                    GestureDetector(
                      onTap: () => _awardDialog(context, ref, s),
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: AppColors.success.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(Icons.add, color: AppColors.success, size: 16),
                      ),
                    ),
                  ]),
                );
              },
            ),
          ),
        ]),
      ),
    );
  }

  void _awardDialog(BuildContext context, WidgetRef ref, Student s) {
    int amount = 10;
    String reason = '';
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text('منح عملات — ${s.name}'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(
            decoration: const InputDecoration(labelText: 'عدد العملات'),
            keyboardType: TextInputType.number,
            onChanged: (v) => amount = int.tryParse(v) ?? 10,
          ),
          const SizedBox(height: 9),
          TextField(
            decoration: const InputDecoration(labelText: 'السبب'),
            onChanged: (v) => reason = v,
          ),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () async {
              await ref.read(coinRepositoryProvider).awardCoins(
                s.id!, s.name, amount, reason.isEmpty ? 'منحة يدوية' : reason,
              );
              if (!context.mounted) return;
              Navigator.pop(ctx);
              AppUI.showToast(context, '🪙 منحت $amount عملة لـ ${s.name}');
              ref.invalidate(_coinsStudentsProvider);
            },
            child: const Text('منح'),
          ),
        ],
      ),
    );
  }
}
