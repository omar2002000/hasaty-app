// lib/features/sessions/qr_scanner_screen.dart
// ─────────────────────────────────────────────────────────────
// Stage 1C — Full-screen attendance scanner.
// Stage 1D — Continuous scan mode with session counter.
//
// Key behaviours:
//   • Camera stays OPEN after each scan (continuous mode — Stage 1D)
//   • Parses 'HASATY-{id}' AND legacy plain-int formats
//   • Prevents duplicate attendance (same-day check in repository)
//   • Animated green/red overlay with student name feedback
//   • HapticFeedback: light on detect, medium on success, heavy on error
//   • 1.5 s cooldown between scans (fast but not spam-prone)
//   • Session counter: how many students marked this session (Stage 1D)
//   • Scanned names list — last 3 shown inline (Stage 1D)
// ─────────────────────────────────────────────────────────────

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/global_providers.dart';
import '../qr/qr_token_generator.dart';

class QRScannerScreen extends ConsumerStatefulWidget {
  final String groupName;
  final double sessionPrice;

  const QRScannerScreen({
    super.key,
    required this.groupName,
    required this.sessionPrice,
  });

  @override
  ConsumerState<QRScannerScreen> createState() => _QRScannerScreenState();
}

class _QRScannerScreenState extends ConsumerState<QRScannerScreen>
    with SingleTickerProviderStateMixin {

  // ── Scan state ────────────────────────────────────────────────
  bool    _isProcessing  = false;
  String? _lastScannedRaw;         // prevents same code firing twice in a row

  // ── Feedback state ────────────────────────────────────────────
  bool   _showSuccess    = false;
  bool   _showError      = false;
  String _feedbackName   = '';
  String _feedbackMsg    = '';

  // ── Session counter (Stage 1D) ───────────────────────────────
  final List<String> _scannedNames = [];
  int get _count => _scannedNames.length;

  // ── Fade animation for feedback overlay ───────────────────────
  late final AnimationController _flashCtrl;
  late final Animation<double>   _flashAnim;

  @override
  void initState() {
    super.initState();
    _flashCtrl = AnimationController(
        vsync: this, duration: const Duration(milliseconds: 350));
    _flashAnim = CurvedAnimation(parent: _flashCtrl, curve: Curves.easeOut);
  }

  @override
  void dispose() {
    _flashCtrl.dispose();
    super.dispose();
  }

  // ─── Core scan handler ────────────────────────────────────────

  void _onDetect(BarcodeCapture capture) async {
    if (_isProcessing) return;

    final barcodes = capture.barcodes;
    if (barcodes.isEmpty || barcodes.first.rawValue == null) return;

    final raw = barcodes.first.rawValue!;
    if (raw == _lastScannedRaw) return;   // same QR still in frame
    _lastScannedRaw = raw;

    // Haptic: light on initial detection
    HapticFeedback.lightImpact();

    // Parse student ID from HASATY-{id} or legacy plain-int
    final studentId = QrTokenGenerator.parseStudentId(raw);
    if (studentId == null) {
      _triggerFeedback(success: false, name: '', msg: 'كود QR غير صالح');
      return;
    }

    setState(() => _isProcessing = true);

    // Repository handles duplicate check + DB write
    final res = await ref.read(attendanceRepositoryProvider).markByQR(
      studentId,
      widget.groupName,
      widget.sessionPrice,
    );

    final success = res['success'] as bool;
    final msg     = res['message'] as String;
    final student = res['student'];
    final name    = (student?.name as String?) ?? '#$studentId';

    if (success) {
      HapticFeedback.mediumImpact();
      if (!_scannedNames.contains(name)) {
        setState(() => _scannedNames.add(name));
      }
    } else {
      HapticFeedback.heavyImpact();
    }

    _triggerFeedback(success: success, name: name, msg: msg);

    // Cooldown: camera stays open — reset after 1.5 s (Stage 1D)
    await Future.delayed(const Duration(milliseconds: 1500));
    if (mounted) {
      setState(() {
        _isProcessing  = false;
        _lastScannedRaw = null;
        _showSuccess   = false;
        _showError     = false;
      });
    }
  }

  void _triggerFeedback({
    required bool   success,
    required String name,
    required String msg,
  }) {
    setState(() {
      _showSuccess  = success;
      _showError    = !success;
      _feedbackName = name;
      _feedbackMsg  = msg;
    });
    _flashCtrl.forward(from: 0.0);
  }

  // ─── Build ────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final hasGroup = widget.groupName.isNotEmpty;

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(children: [

        // ── Camera (full screen) ──────────────────────────────
        MobileScanner(onDetect: _onDetect),

        // ── Scan-area overlay (darkened corners + coloured frame) ─
        _buildScanOverlay(),

        // ── Top bar ───────────────────────────────────────────
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Row(children: [
              // Back
              IconButton(
                onPressed: () => Navigator.pop(context),
                icon: const Icon(Icons.arrow_back_ios_rounded,
                    color: Colors.white),
                style: IconButton.styleFrom(
                    backgroundColor: Colors.black38,
                    shape: const CircleBorder()),
              ),
              // Title
              Expanded(
                child: Text(
                  hasGroup ? 'حضور — ${widget.groupName}' : 'تسجيل حضور QR',
                  style: const TextStyle(
                      color: Colors.white, fontSize: 15,
                      fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
              ),
              // Session counter badge (Stage 1D)
              Container(
                padding: const EdgeInsets.symmetric(
                    horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: _count > 0
                      ? AppColors.success : Colors.black38,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Row(mainAxisSize: MainAxisSize.min, children: [
                  const Icon(Icons.people_rounded,
                      color: Colors.white, size: 14),
                  const SizedBox(width: 4),
                  Text('$_count',
                      style: const TextStyle(
                          color: Colors.white, fontSize: 13,
                          fontWeight: FontWeight.bold)),
                ]),
              ),
            ]),
          ),
        ),

        // ── Feedback overlay (animated) ───────────────────────
        if (_showSuccess || _showError)
          _buildFeedbackOverlay(),

        // ── Bottom hint ───────────────────────────────────────
        if (!_showSuccess && !_showError)
          Positioned(
            bottom: 60, left: 24, right: 24,
            child: Center(
              child: AnimatedOpacity(
                opacity: _isProcessing ? 0.0 : 1.0,
                duration: const Duration(milliseconds: 200),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 20, vertical: 10),
                  decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.circular(24)),
                  child: Text(
                    _isProcessing
                        ? 'جارٍ التسجيل...'
                        : 'وجّه الكاميرا نحو كود QR الطالب',
                    style: const TextStyle(
                        color: Colors.white, fontSize: 13),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ),
          ),

        // ── Scanned names list (Stage 1D) ─────────────────────
        if (_scannedNames.isNotEmpty)
          Positioned(
            bottom: 120, left: 16, right: 16,
            child: _ScannedList(names: _scannedNames),
          ),
      ]),
    );
  }

  // ─── Scan overlay: dim + coloured frame + corner markers ──────

  Widget _buildScanOverlay() {
    final frameColor = _showSuccess
        ? AppColors.success
        : _showError
            ? AppColors.danger
            : Colors.white;

    return Stack(children: [
      // Semi-transparent dim layer over full screen
      Container(color: Colors.black.withOpacity(0.5)),

      // Centre cut-out: clear rect with border
      Center(
        child: Container(
          width: 250, height: 250,
          decoration: BoxDecoration(
            color:  Colors.transparent,
            border: Border.all(
                color: frameColor,
                width: _showSuccess || _showError ? 3.5 : 2.5),
            borderRadius: BorderRadius.circular(18),
          ),
        ),
      ),

      // Corner accent markers
      Center(
        child: SizedBox(
          width: 254, height: 254,
          child: CustomPaint(
            painter: _CornerPainter(color: frameColor),
          ),
        ),
      ),
    ]);
  }

  // ─── Feedback overlay ─────────────────────────────────────────

  Widget _buildFeedbackOverlay() {
    final success = _showSuccess;
    final color   = success ? AppColors.success : AppColors.danger;

    return FadeTransition(
      opacity: _flashAnim,
      child: Center(
        child: Container(
          margin: const EdgeInsets.symmetric(horizontal: 40),
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: color, width: 2),
            boxShadow: [
              BoxShadow(color: color.withOpacity(0.3),
                  blurRadius: 20, spreadRadius: 2),
            ],
          ),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(success
                ? Icons.check_circle_rounded
                : Icons.cancel_rounded,
                color: color, size: 52),
            const SizedBox(height: 10),
            if (_feedbackName.isNotEmpty)
              Text(_feedbackName,
                  style: const TextStyle(
                      fontSize: 18, fontWeight: FontWeight.bold,
                      color: Colors.black87),
                  textAlign: TextAlign.center),
            const SizedBox(height: 6),
            Text(_feedbackMsg,
                style: TextStyle(fontSize: 13, color: color),
                textAlign: TextAlign.center),
          ]),
        ),
      ),
    );
  }
}

// ─── Scanned names list widget (Stage 1D) ─────────────────────

class _ScannedList extends StatelessWidget {
  final List<String> names;
  const _ScannedList({required this.names});

  @override
  Widget build(BuildContext context) {
    final recent = names.reversed.take(3).toList();
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
          color: Colors.black54,
          borderRadius: BorderRadius.circular(16)),
      child: Column(
        mainAxisSize:    MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('آخر الحاضرين (${names.length}):',
              style: const TextStyle(
                  color: Colors.white70, fontSize: 11,
                  fontWeight: FontWeight.bold)),
          const SizedBox(height: 5),
          ...recent.map((n) => Padding(
            padding: const EdgeInsets.only(bottom: 2),
            child: Row(children: [
              const Icon(Icons.check_rounded,
                  color: AppColors.success, size: 13),
              const SizedBox(width: 5),
              Text(n, style: const TextStyle(
                  color: Colors.white, fontSize: 12)),
            ]),
          )),
          if (names.length > 3)
            Text('و ${names.length - 3} آخرين...',
                style: const TextStyle(
                    color: Colors.white54, fontSize: 10)),
        ],
      ),
    );
  }
}

// ─── Corner markers painter ───────────────────────────────────

class _CornerPainter extends CustomPainter {
  final Color color;
  const _CornerPainter({required this.color});

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color       = color
      ..strokeWidth = 4.0
      ..style       = PaintingStyle.stroke
      ..strokeCap   = StrokeCap.round;

    const len  = 22.0;
    final l    = 0.0;
    final r    = size.width;
    final t    = 0.0;
    final b    = size.height;

    // Top-left
    canvas.drawLine(Offset(l, t), Offset(l + len, t), paint);
    canvas.drawLine(Offset(l, t), Offset(l, t + len), paint);
    // Top-right
    canvas.drawLine(Offset(r, t), Offset(r - len, t), paint);
    canvas.drawLine(Offset(r, t), Offset(r, t + len), paint);
    // Bottom-left
    canvas.drawLine(Offset(l, b), Offset(l + len, b), paint);
    canvas.drawLine(Offset(l, b), Offset(l, b - len), paint);
    // Bottom-right
    canvas.drawLine(Offset(r, b), Offset(r - len, b), paint);
    canvas.drawLine(Offset(r, b), Offset(r, b - len), paint);
  }

  @override
  bool shouldRepaint(_CornerPainter old) => old.color != color;
}
