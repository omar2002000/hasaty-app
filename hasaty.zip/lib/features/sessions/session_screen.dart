// lib/features/sessions/session_screen.dart
// Stage 6A: Start Session Mode upgrades.
//   • In-session search bar (real-time filter by name)
//   • Keyboard-dismiss on scroll
//   • Session summary sheet before save (present/absent/price breakdown)
//   • Batch WhatsApp to all absent students with one tap
//   • Haptic feedback on tap
//   • keepAlive on session students provider

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/ui_helpers.dart';
import '../../domain/entities/group.dart';
import '../../domain/entities/attendance_record.dart';
import '../../domain/entities/student.dart';
import '../../providers/global_providers.dart';
import '../students/student_profile_screen.dart';
import 'qr_scanner_screen.dart'; // Stage 6A: QR in session
import '../../core/services/audit_service.dart'; // Stage 8

// Provider is scoped to group name — keepAlive avoids re-fetch in same session
final _sessionStudentsProvider = FutureProvider.family<List<Student>, String>(
    (ref, groupName) async {
  ref.keepAlive();
  final all = await ref.read(studentRepositoryProvider).getStudents();
  return all.where((s) => s.groupName == groupName).toList();
});

class SessionScreen extends ConsumerStatefulWidget {
  final Group group;
  const SessionScreen({super.key, required this.group});

  @override
  ConsumerState<SessionScreen> createState() => _SessionScreenState();
}

class _SessionScreenState extends ConsumerState<SessionScreen> {
  final Set<int>           _markedPresent = {};
  bool                     _submitting    = false;
  final TextEditingController _search     = TextEditingController();
  String                   _query        = '';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(_sessionStudentsProvider(widget.group.name));

    return GestureDetector(
      // Stage 6A: dismiss keyboard on scroll/tap outside
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(
          title: Text('حصة — ${widget.group.name}'),
          actions: [
            // QR scanner shortcut inside session
            IconButton(
              icon: const Icon(Icons.qr_code_scanner_rounded),
              tooltip: 'مسح QR',
              onPressed: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => QRScannerScreen(
                      groupName: widget.group.name,
                      sessionPrice: widget.group.monthlyPrice / 4))),
            ),
            TextButton(
              onPressed: _submitting
                  ? null
                  : () => _showSummarySheet(context,
                      state.valueOrNull ?? []),
              child: _submitting
                  ? const SizedBox(width: 16, height: 16,
                      child: CircularProgressIndicator(
                          strokeWidth: 2, color: Colors.white))
                  : const Text('حفظ',
                      style: TextStyle(color: Colors.white,
                          fontWeight: FontWeight.bold)),
            ),
          ],
        ),
        body: state.when(
          loading: () => const Center(
              child: CircularProgressIndicator(color: AppColors.primary)),
          error:   (e, _) => Center(child: Text('$e')),
          data: (students) {
            // Stage 6A: filter by in-session search
            final filtered = _query.isEmpty ? students
                : students.where((s) =>
                    s.name.toLowerCase().contains(_query.toLowerCase()))
                    .toList();

            final absentStudents = students
                .where((s) => !_markedPresent.contains(s.id))
                .toList();

            return Column(children: [
              // ── Control bar ────────────────────────────────
              Container(
                color: Theme.of(context).brightness == Brightness.dark
                    ? AppColors.bgCardDark
                    : AppColors.bgCard,
                padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
                child: Column(children: [
                  Row(children: [
                    // Counter badge
                    Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(
                        color: AppColors.success.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                            color: AppColors.success.withOpacity(0.3)),
                      ),
                      child: Text(
                        '✅ ${_markedPresent.length} / ${students.length}',
                        style: const TextStyle(fontWeight: FontWeight.bold,
                            color: AppColors.success),
                      ),
                    ),
                    const Spacer(),
                    TextButton(
                      onPressed: () => setState(() =>
                          _markedPresent.addAll(students.map((s) => s.id!))),
                      child: const Text('تحديد الكل',
                          style: TextStyle(fontSize: 12)),
                    ),
                    TextButton(
                      onPressed: () => setState(() => _markedPresent.clear()),
                      child: const Text('مسح الكل',
                          style: TextStyle(
                              fontSize: 12, color: AppColors.danger)),
                    ),
                  ]),
                  const SizedBox(height: 6),
                  // Stage 6A: in-session search bar
                  TextField(
                    controller: _search,
                    onChanged: (v) => setState(() => _query = v),
                    decoration: InputDecoration(
                      hintText: 'ابحث عن طالب...',
                      prefixIcon: const Icon(Icons.search,
                          size: 18, color: AppColors.textSecondary),
                      suffixIcon: _query.isNotEmpty
                          ? IconButton(
                              icon: const Icon(Icons.clear, size: 16),
                              onPressed: () {
                                _search.clear();
                                setState(() => _query = '');
                              })
                          : null,
                      isDense: true,
                      contentPadding: const EdgeInsets.symmetric(
                          horizontal: 12, vertical: 9),
                    ),
                  ),
                ]),
              ),

              // ── Students list ──────────────────────────────
              Expanded(
                child: filtered.isEmpty
                    ? const Center(
                        child: Text('لا توجد نتائج',
                            style: TextStyle(
                                color: AppColors.textSecondary)))
                    : NotificationListener<ScrollNotification>(
                        // Stage 6A: dismiss keyboard on scroll
                        onNotification: (n) {
                          if (n is ScrollUpdateNotification) {
                            FocusScope.of(context).unfocus();
                          }
                          return false;
                        },
                        child: ListView.builder(
                          padding:
                              const EdgeInsets.fromLTRB(14, 4, 14, 80),
                          itemCount: filtered.length,
                          itemBuilder: (_, i) {
                            final s       = filtered[i];
                            final present =
                                _markedPresent.contains(s.id);
                            final isDark  =
                                Theme.of(context).brightness ==
                                    Brightness.dark;
                            return GestureDetector(
                              onTap: () {
                                HapticFeedback.lightImpact();
                                setState(() => present
                                    ? _markedPresent.remove(s.id)
                                    : _markedPresent.add(s.id!));
                              },
                              onLongPress: () => Navigator.push(
                                  context,
                                  MaterialPageRoute(builder: (_) =>
                                      StudentProfileScreen(
                                          student: s))),
                              child: AnimatedContainer(
                                duration:
                                    const Duration(milliseconds: 180),
                                margin:
                                    const EdgeInsets.only(bottom: 8),
                                padding: const EdgeInsets.all(13),
                                decoration: BoxDecoration(
                                  color: present
                                      ? AppColors.success.withOpacity(0.07)
                                      : isDark
                                          ? AppColors.bgCardDark
                                          : AppColors.bgCard,
                                  borderRadius:
                                      BorderRadius.circular(14),
                                  border: Border.all(
                                    color: present
                                        ? AppColors.success.withOpacity(0.4)
                                        : AppColors.borderLight,
                                  ),
                                ),
                                child: Row(children: [
                                  // Avatar / check
                                  AnimatedContainer(
                                    duration: const Duration(
                                        milliseconds: 200),
                                    width: 40, height: 40,
                                    decoration: BoxDecoration(
                                      color: present
                                          ? AppColors.success
                                          : AppColors.borderLight
                                              .withOpacity(0.5),
                                      borderRadius:
                                          BorderRadius.circular(12),
                                    ),
                                    child: Center(
                                      child: present
                                          ? const Icon(
                                              Icons.check_rounded,
                                              color: Colors.white,
                                              size: 20)
                                          : Text(s.displayInitial,
                                              style: const TextStyle(
                                                  fontWeight:
                                                      FontWeight.bold,
                                                  color: AppColors
                                                      .textSecondary)),
                                    ),
                                  ),
                                  const SizedBox(width: 12),
                                  // Info
                                  Expanded(child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                    Text(s.name,
                                        style: const TextStyle(
                                            fontWeight:
                                                FontWeight.bold,
                                            fontSize: 14)),
                                    Text(
                                      '${s.levelEmoji} ${s.levelName}  •  ${s.xp} XP',
                                      style: const TextStyle(
                                          fontSize: 11,
                                          color:
                                              AppColors.textSecondary),
                                    ),
                                  ])),
                                  // WhatsApp for absent
                                  if (!present)
                                    IconButton(
                                      icon: const Icon(Icons.message,
                                          color: Color(0xFF25D366),
                                          size: 18),
                                      tooltip: 'واتساب',
                                      onPressed: () => _sendWhatsApp(s),
                                    ),
                                ]),
                              ),
                            );
                          },
                        ),
                      ),
              ),
            ]);
          },
        ),
      ),
    );
  }

  // ─── WhatsApp ─────────────────────────────────────────────────

  void _sendWhatsApp(Student s) {
    final p   = s.parentPhone.isNotEmpty ? s.parentPhone : s.phone;
    final num = p.startsWith('0') ? '2${p.substring(1)}' : p;
    launchUrl(
      Uri.parse(
          'https://wa.me/$num?text=${Uri.encodeComponent('أهلاً ولي أمر ${s.name}، لم يحضر نجلكم حصة اليوم. يُرجى التواصل معنا. معلمكم: مستر نصر علي 📚')}'),
      mode: LaunchMode.externalApplication,
    );
  }

  // ─── Session Summary Sheet (Stage 6A) ─────────────────────────

  Future<void> _showSummarySheet(
      BuildContext context, List<Student> students) async {
    if (_markedPresent.isEmpty) {
      AppUI.showToast(context, 'حدد الحاضرين أولاً', isError: true);
      return;
    }
    final absentStudents = students
        .where((s) => !_markedPresent.contains(s.id))
        .toList();
    final pricePerSession = widget.group.monthlyPrice / 4;
    final totalRevenue = _markedPresent.length * pricePerSession;

    final confirmed = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => _SessionSummarySheet(
        groupName:     widget.group.name,
        presentCount:  _markedPresent.length,
        absentStudents: absentStudents,
        pricePerSession: pricePerSession,
        totalRevenue:  totalRevenue,
        onSend: () => _sendBulkWhatsApp(absentStudents),
      ),
    );
    if (confirmed == true && mounted) {
      await _submitSession(students);
    }
  }

  // ─── Bulk WhatsApp to all absent ──────────────────────────────

  Future<void> _sendBulkWhatsApp(List<Student> absents) async {
    for (final s in absents) {
      _sendWhatsApp(s);
      await Future.delayed(const Duration(milliseconds: 800));
    }
  }

  // ─── Submit session ───────────────────────────────────────────

  Future<void> _submitSession(List<Student> students) async {
    setState(() => _submitting = true);
    try {
      for (final s in students) {
        final present = _markedPresent.contains(s.id);
        await ref.read(attendanceRepositoryProvider).addRecord(
          AttendanceRecord(
            studentId:   s.id!,
            studentName: s.name,
            groupName:   widget.group.name,
            date:        AppUI.today(),
            present:     present,
          ),
        );
        if (present) {
          final updated = s.copyWith(
            balance: s.balance - widget.group.monthlyPrice / 4,
            xp:      s.xp + 10,
          );
          await ref.read(studentRepositoryProvider).updateStudent(updated);
        }
      }
      if (!mounted) return;

      // Stage 8 undo: show 5-sec snackbar, allow reversing attendance records
      final insertedIds = <int>[];
      // Note: we log to audit
      await AuditService.log(ref,
        actionType:  'attendance',
        studentName: widget.group.name,
        description: 'تسجيل حضور ${_markedPresent.length} طالب — ${widget.group.name}',
      );

      // Show undo snackbar
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('✅ تم تسجيل حضور ${_markedPresent.length} طالب'),
        backgroundColor: AppColors.success,
        duration: const Duration(seconds: 5),
        behavior: SnackBarBehavior.floating,
        action: SnackBarAction(
          label: 'تراجع',
          textColor: Colors.white,
          onPressed: () async {
            // Undo: delete attendance records for today + this group
            final today = AppUI.today();
            for (final s in students) {
              final records = await ref.read(attendanceRepositoryProvider)
                  .getByStudent(s.id!);
              final todayRecord = records.where((r) =>
                  r.date == today && r.groupName == widget.group.name)
                  .toList();
              // We can't delete by ID via current interface.
              // Workaround: show toast informing manual action needed.
            }
            if (context.mounted) {
              AppUI.showToast(context,
                  'لإلغاء الحضور يرجى تعديل السجل يدوياً');
            }
          },
        ),
      ));
      Navigator.pop(context);
    } catch (e) {
      if (mounted) AppUI.showToast(context, 'خطأ: $e', isError: true);
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }
}

// ── Session Summary Sheet ─────────────────────────────────────

class _SessionSummarySheet extends StatelessWidget {
  final String  groupName;
  final int     presentCount;
  final List<Student> absentStudents;
  final double  pricePerSession;
  final double  totalRevenue;
  final VoidCallback onSend;

  const _SessionSummarySheet({
    required this.groupName,
    required this.presentCount,
    required this.absentStudents,
    required this.pricePerSession,
    required this.totalRevenue,
    required this.onSend,
  });

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : Colors.white,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      ),
      child: Column(mainAxisSize: MainAxisSize.min, children: [
        Container(
          width: 36, height: 4,
          margin: const EdgeInsets.only(bottom: 16),
          decoration: BoxDecoration(
              color: AppColors.borderLight,
              borderRadius: BorderRadius.circular(2)),
        ),
        Text('ملخص الحصة — $groupName',
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),

        // Stats row
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            _SummaryChip('✅ حاضر', presentCount, AppColors.success),
            _SummaryChip('❌ غائب', absentStudents.length, AppColors.danger),
            _SummaryChip('💰 إيراد',
                totalRevenue.toStringAsFixed(0) + ' ج', AppColors.accent,
                isString: true),
          ],
        ),
        const SizedBox(height: 16),

        // Price info
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
              color: AppColors.primary.withOpacity(0.05),
              borderRadius: BorderRadius.circular(12)),
          child: Text(
            'سعر الجلسة: ${pricePerSession.toStringAsFixed(0)} ج/طالب\n'
            'الإيراد المتوقع: ${totalRevenue.toStringAsFixed(0)} ج',
            style: const TextStyle(fontSize: 13, height: 1.6),
          ),
        ),
        const SizedBox(height: 16),

        // Absent list (compact)
        if (absentStudents.isNotEmpty) ...[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text('الغائبون (${absentStudents.length}):',
                  style: const TextStyle(fontWeight: FontWeight.bold,
                      fontSize: 13)),
              TextButton.icon(
                icon: const Icon(Icons.send, size: 14,
                    color: Color(0xFF25D366)),
                label: const Text('إرسال للكل',
                    style: TextStyle(fontSize: 12,
                        color: Color(0xFF25D366))),
                onPressed: () => onSend(),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Wrap(
            spacing: 6, runSpacing: 6,
            children: absentStudents.map((s) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                  color: AppColors.danger.withOpacity(0.08),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                      color: AppColors.danger.withOpacity(0.25))),
              child: Text(s.name,
                  style: const TextStyle(
                      fontSize: 11, color: AppColors.danger)),
            )).toList(),
          ),
          const SizedBox(height: 16),
        ],

        // Confirm button
        SizedBox(
          width: double.infinity,
          child: ElevatedButton.icon(
            icon: const Icon(Icons.save_rounded),
            label: const Text('تأكيد وحفظ',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.success,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 14),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12)),
            ),
            onPressed: () => Navigator.pop(context, true),
          ),
        ),
        const SizedBox(height: 10),
        SizedBox(
          width: double.infinity,
          child: OutlinedButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('مراجعة'),
          ),
        ),
      ]),
    );
  }
}

class _SummaryChip extends StatelessWidget {
  final String label;
  final dynamic value;
  final Color  color;
  final bool   isString;
  const _SummaryChip(this.label, this.value, this.color,
      {this.isString = false});

  @override
  Widget build(BuildContext context) => Column(children: [
    Text(isString ? value as String : '${value as int}',
        style: TextStyle(color: color, fontSize: 22,
            fontWeight: FontWeight.bold)),
    Text(label,
        style: const TextStyle(fontSize: 10,
            color: AppColors.textSecondary)),
  ]);
}
