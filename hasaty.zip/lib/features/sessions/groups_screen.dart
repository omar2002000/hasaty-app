// lib/features/sessions/groups_screen.dart
// Groups screen — preserved original logic, UI cleaned up.
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/ui_helpers.dart';
import '../../domain/entities/group.dart';
import '../../providers/global_providers.dart';
import 'session_screen.dart';

final _groupsProvider = FutureProvider<List<Group>>((ref) =>
    ref.read(groupRepositoryProvider).getAll());

class GroupsScreen extends ConsumerWidget {
  const GroupsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(_groupsProvider);
    final days  = ['السبت','الأحد','الإثنين','الثلاثاء','الأربعاء','الخميس','الجمعة'];

    return Scaffold(
      appBar: AppBar(title: const Text('المجموعات')),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.primary,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text('مجموعة جديدة', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        onPressed: () => _showDialog(context, ref, null, days),
      ),
      body: state.when(
        loading: () => const Center(child: CircularProgressIndicator(color: AppColors.primary)),
        error:   (e, _) => Center(child: Text('$e')),
        data: (groups) => groups.isEmpty
            ? Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                const Icon(Icons.groups_outlined, size: 64, color: AppColors.textSecondary),
                const SizedBox(height: 12),
                const Text('لا توجد مجموعات بعد', style: TextStyle(color: AppColors.textSecondary)),
              ]))
            : ListView.builder(
                padding: const EdgeInsets.all(14),
                itemCount: groups.length,
                itemBuilder: (_, i) => _GroupCard(
                  group: groups[i],
                  onEdit:    () => _showDialog(context, ref, groups[i], days),
                  onDelete:  () => _delete(context, ref, groups[i]),
                  onSession: () => Navigator.push(context, MaterialPageRoute(builder: (_) => SessionScreen(group: groups[i]))),
                ),
              ),
      ),
    );
  }

  Future<void> _delete(BuildContext context, WidgetRef ref, Group g) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('حذف المجموعة'),
        content: Text('هل أنت متأكد من حذف "${g.name}"؟'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('إلغاء')),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.danger),
            child: const Text('حذف', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
    if (ok == true) {
      await ref.read(groupRepositoryProvider).deleteGroup(g.id!);
      ref.invalidate(_groupsProvider);
    }
  }

  void _showDialog(BuildContext context, WidgetRef ref, Group? existing, List<String> allDays) {
    String name = existing?.name ?? '';
    double price = existing?.monthlyPrice ?? 0;
    String time = existing?.time ?? '';
    Set<String> selDays = existing?.days.isNotEmpty == true
        ? Set.from(existing!.days.split(',').where((d) => d.isNotEmpty))
        : {};

    showDialog(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Row(children: [
            const Icon(Icons.groups, color: AppColors.primary),
            const SizedBox(width: 8),
            Text(existing == null ? 'إضافة مجموعة' : 'تعديل المجموعة'),
          ]),
          content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextField(
              controller: TextEditingController(text: name),
              decoration: const InputDecoration(labelText: 'اسم المجموعة', prefixIcon: Icon(Icons.groups)),
              onChanged: (v) => name = v,
            ),
            const SizedBox(height: 10),
            TextField(
              controller: TextEditingController(text: price == 0 ? '' : price.toStringAsFixed(0)),
              decoration: const InputDecoration(labelText: 'الاشتراك الشهري', prefixIcon: Icon(Icons.payments), suffixText: 'ج.م'),
              keyboardType: TextInputType.number,
              onChanged: (v) => price = double.tryParse(v) ?? 0,
            ),
            const SizedBox(height: 10),
            TextField(
              controller: TextEditingController(text: time),
              decoration: const InputDecoration(labelText: 'وقت الحصة', prefixIcon: Icon(Icons.access_time), hintText: '05:00 م'),
              onChanged: (v) => time = v,
            ),
            const SizedBox(height: 10),
            const Align(alignment: Alignment.centerRight, child: Text('أيام الحصص:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13))),
            const SizedBox(height: 6),
            Wrap(
              spacing: 6, runSpacing: 6,
              children: allDays.map((d) => FilterChip(
                label: Text(d, style: const TextStyle(fontSize: 12)),
                selected: selDays.contains(d),
                selectedColor: AppColors.primary.withOpacity(0.2),
                checkmarkColor: AppColors.primary,
                onSelected: (v) => setS(() => v ? selDays.add(d) : selDays.remove(d)),
              )).toList(),
            ),
          ])),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('إلغاء')),
            ElevatedButton(
              onPressed: () async {
                if (name.isEmpty || price <= 0) return;
                final g = Group(id: existing?.id, name: name, monthlyPrice: price, days: selDays.join(','), time: time);
                if (existing == null) {
                  await ref.read(groupRepositoryProvider).addGroup(g);
                } else {
                  await ref.read(groupRepositoryProvider).updateGroup(g);
                }
                if (!context.mounted) return;
                Navigator.pop(ctx);
                ref.invalidate(_groupsProvider);
              },
              child: Text(existing == null ? 'إضافة' : 'حفظ'),
            ),
          ],
        ),
      ),
    );
  }
}

class _GroupCard extends StatelessWidget {
  final Group group;
  final VoidCallback onEdit, onDelete, onSession;
  const _GroupCard({required this.group, required this.onEdit, required this.onDelete, required this.onSession});

  @override
  Widget build(BuildContext context) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final days = group.days.isNotEmpty
        ? group.days.split(',').where((d) => d.isNotEmpty).toList()
        : <String>[];
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: isDark ? AppColors.borderDark : AppColors.borderLight),
      ),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
            child: const Icon(Icons.groups, color: AppColors.primary, size: 20),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(group.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            Text('${group.monthlyPrice.toStringAsFixed(0)} ج.م / شهر',
                style: const TextStyle(color: AppColors.textSecondary, fontSize: 12)),
          ])),
          PopupMenuButton<String>(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            onSelected: (v) { if (v == 'edit') onEdit(); if (v == 'delete') onDelete(); },
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'edit',   child: Row(children: [Icon(Icons.edit, size: 16, color: AppColors.primary), SizedBox(width: 8), Text('تعديل')])),
              const PopupMenuItem(value: 'delete', child: Row(children: [Icon(Icons.delete_outline, size: 16, color: AppColors.danger), SizedBox(width: 8), Text('حذف', style: TextStyle(color: AppColors.danger))])),
            ],
          ),
        ]),
        if (days.isNotEmpty || group.time.isNotEmpty) ...[
          const SizedBox(height: 8),
          Wrap(spacing: 6, runSpacing: 4, children: [
            ...days.map((d) => Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: AppColors.accent.withOpacity(0.12), borderRadius: BorderRadius.circular(20)),
              child: Text(d, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: AppColors.accent)),
            )),
            if (group.time.isNotEmpty) Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              decoration: BoxDecoration(color: AppColors.primary.withOpacity(0.1), borderRadius: BorderRadius.circular(20)),
              child: Text('🕐 ${group.time}', style: const TextStyle(fontSize: 10, fontWeight: FontWeight.bold, color: AppColors.primary)),
            ),
          ]),
        ],
        const SizedBox(height: 10),
        ElevatedButton.icon(
          icon: const Icon(Icons.play_circle_fill, size: 15, color: Colors.white),
          label: const Text('بدء الحصة', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.success, elevation: 0,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            minimumSize: const Size(double.infinity, 40),
          ),
          onPressed: onSession,
        ),
      ]),
    );
  }
}
