// lib/features/sessions/session_picker_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../domain/entities/group.dart';
import '../../providers/global_providers.dart';
import 'session_screen.dart';

final _pickerGroupsProvider = FutureProvider<List<Group>>((ref) =>
    ref.read(groupRepositoryProvider).getAll());

class SessionPickerScreen extends ConsumerWidget {
  const SessionPickerScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(_pickerGroupsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('اختر المجموعة'),
        backgroundColor: AppColors.success,
      ),
      body: state.when(
        loading: () => const Center(child: CircularProgressIndicator(color: AppColors.success)),
        error:   (e, _) => Center(child: Text('$e')),
        data: (groups) => groups.isEmpty
            ? const Center(
                child: Text('لا توجد مجموعات',
                    style: TextStyle(color: AppColors.textSecondary)))
            : ListView.builder(
                padding: const EdgeInsets.all(16),
                itemCount: groups.length,
                itemBuilder: (_, i) {
                  final g = groups[i];
                  return Card(
                    margin: const EdgeInsets.only(bottom: 10),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                    child: ListTile(
                      leading: CircleAvatar(
                        backgroundColor: AppColors.success.withOpacity(0.15),
                        child: const Icon(Icons.groups, color: AppColors.success),
                      ),
                      title: Text(g.name,
                          style: const TextStyle(fontWeight: FontWeight.bold)),
                      subtitle: Text('${g.monthlyPrice.toStringAsFixed(0)} ج.م / شهر'),
                      trailing: const Icon(Icons.arrow_forward_ios, size: 14),
                      onTap: () => Navigator.pushReplacement(
                        context,
                        MaterialPageRoute(builder: (_) => SessionScreen(group: g)),
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}
