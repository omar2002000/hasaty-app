// lib/features/sessions/academic_screen.dart
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../core/utils/ui_helpers.dart';
import '../../domain/entities/group.dart';
import '../../domain/entities/student.dart';
import '../../domain/entities/academic_grade.dart';
import '../../providers/global_providers.dart';

final _academicGroupsProvider = FutureProvider<List<Group>>((ref) =>
    ref.read(groupRepositoryProvider).getAll());

final _recentGradesProvider = FutureProvider<List<AcademicGrade>>((ref) =>
    ref.read(gradeRepositoryProvider).getAllGrades());

final _groupStudentsProvider = FutureProvider.family<List<Student>, String>(
    (ref, groupName) async {
  final all = await ref.read(studentRepositoryProvider).getStudents();
  return all.where((s) => s.groupName == groupName).toList();
});

class AcademicScreen extends ConsumerStatefulWidget {
  const AcademicScreen({super.key});

  @override
  ConsumerState<AcademicScreen> createState() => _AcademicScreenState();
}

class _AcademicScreenState extends ConsumerState<AcademicScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tab;

  @override
  void initState() {
    super.initState();
    _tab = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    _tab.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final groupsState = ref.watch(_academicGroupsProvider);
    final gradesState = ref.watch(_recentGradesProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('التقييم الأكاديمي'),
        bottom: TabBar(
          controller: _tab,
          labelColor: Colors.white,
          unselectedLabelColor: Colors.white60,
          indicatorColor: Colors.white,
          tabs: const [Tab(text: 'تقييم سريع'), Tab(text: 'السجل')],
        ),
      ),
      body: TabBarView(controller: _tab, children: [
        // ── Quick Grading ────────────────────────────────
        groupsState.when(
          loading: () => const Center(child: CircularProgressIndicator(color: AppColors.primary)),
          error:   (e, _) => Center(child: Text('$e')),
          data: (groups) => groups.isEmpty
              ? const Center(child: Text('لا توجد مجموعات', style: TextStyle(color: AppColors.textSecondary)))
              : ListView.builder(
                  padding: const EdgeInsets.all(14),
                  itemCount: groups.length,
                  itemBuilder: (_, i) {
                    final g = groups[i];
                    return Card(
                      margin: const EdgeInsets.only(bottom: 10),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                      child: ListTile(
                        leading: const CircleAvatar(
                          backgroundColor: Color(0x1A1E3A8A),
                          child: Icon(Icons.groups, color: AppColors.primary),
                        ),
                        title: Text(g.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text('${g.monthlyPrice.toStringAsFixed(0)} ج.م / شهر'),
                        trailing: const Icon(Icons.arrow_forward_ios, size: 14),
                        onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(builder: (_) => GroupGradingScreen(group: g)),
                        ).then((_) {
                          ref.invalidate(_recentGradesProvider);
                          ref.invalidate(_academicGroupsProvider);
                        }),
                      ),
                    );
                  },
                ),
        ),

        // ── Recent Grades Log ────────────────────────────
        gradesState.when(
          loading: () => const Center(child: CircularProgressIndicator(color: AppColors.primary)),
          error:   (e, _) => Center(child: Text('$e')),
          data: (grades) {
            final recent = grades.take(30).toList();
            return recent.isEmpty
                ? const Center(child: Text('لا يوجد سجل تقييمات', style: TextStyle(color: AppColors.textSecondary)))
                : ListView.builder(
                    padding: const EdgeInsets.all(14),
                    itemCount: recent.length,
                    itemBuilder: (_, i) {
                      final g   = recent[i];
                      final isDark = Theme.of(context).brightness == Brightness.dark;
                      final gc  = g.grade == 'excellent' ? AppColors.success
                                : g.grade == 'good'      ? AppColors.accent
                                : g.grade == 'acceptable'? AppColors.warning
                                :                          AppColors.danger;
                      return Container(
                        margin: const EdgeInsets.only(bottom: 8),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: gc.withOpacity(0.2)),
                        ),
                        child: Row(children: [
                          Container(
                            width: 38, height: 38,
                            decoration: BoxDecoration(color: gc.withOpacity(0.12), borderRadius: BorderRadius.circular(10)),
                            child: Center(child: Text(g.gradeEmoji, style: const TextStyle(fontSize: 17))),
                          ),
                          const SizedBox(width: 10),
                          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(g.studentName, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                            Text('${g.typeLabel} — ${g.groupName}', style: const TextStyle(fontSize: 11, color: AppColors.textSecondary)),
                          ])),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(color: gc.withOpacity(0.12), borderRadius: BorderRadius.circular(20)),
                            child: Text(g.gradeLabel, style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: gc)),
                          ),
                        ]),
                      );
                    },
                  );
          },
        ),
      ]),
    );
  }
}

// ─── Group Grading Screen ─────────────────────────────────────

class GroupGradingScreen extends ConsumerStatefulWidget {
  final Group group;
  const GroupGradingScreen({super.key, required this.group});

  @override
  ConsumerState<GroupGradingScreen> createState() => _GroupGradingScreenState();
}

class _GroupGradingScreenState extends ConsumerState<GroupGradingScreen> {
  final Map<int, String> _grades = {};
  String _type  = 'recitation';
  String _topic = '';
  bool   _saving = false;

  static const _types = {
    'recitation': 'تسميع 🎤',
    'homework':   'واجب 📝',
    'exam':       'اختبار 📋',
  };

  static const _opts = [
    {'key': 'excellent',  'label': 'ممتاز',  'emoji': '🌟', 'xp': 15},
    {'key': 'good',       'label': 'جيد',    'emoji': '✅', 'xp': 10},
    {'key': 'acceptable', 'label': 'مقبول',  'emoji': '⚠️', 'xp': 5},
    {'key': 'weak',       'label': 'ضعيف',   'emoji': '❌', 'xp': 0},
  ];

  static const _optColors = [
    AppColors.success, AppColors.accent, AppColors.warning, AppColors.danger,
  ];

  Future<void> _save(List<Student> students) async {
    if (_grades.isEmpty) {
      AppUI.showToast(context, 'قيّم على الأقل طالباً واحداً', isError: true);
      return;
    }
    setState(() => _saving = true);
    try {
      final now  = DateTime.now();
      final date = '${now.day}/${now.month}/${now.year}';

      for (final entry in _grades.entries) {
        final s   = students.firstWhere((st) => st.id == entry.key);
        final opt = _opts.firstWhere((o) => o['key'] == entry.value);
        final xp  = opt['xp'] as int;

        // ✅ UI → Repository — لا استدعاء مباشر
        await ref.read(gradeRepositoryProvider).addGrade(AcademicGrade(
          studentId:    s.id!,
          studentName:  s.name,
          groupName:    widget.group.name,
          type:         _type,
          grade:        entry.value,
          date:         date,
          sessionTopic: _topic,
        ));

        if (xp > 0) {
          final updated = s.copyWith(xp: s.xp + xp);
          await ref.read(studentRepositoryProvider).updateStudent(updated);
          await ref.read(coinRepositoryProvider).awardCoins(
            s.id!, s.name, xp ~/ 2, '${_types[_type]} ${opt['label']}',
          );
        }
      }
      if (!mounted) return;
      AppUI.showToast(context, '✅ تم حفظ ${_grades.length} تقييم');
      Navigator.pop(context);
    } catch (e) {
      if (mounted) AppUI.showToast(context, 'خطأ: $e', isError: true);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final studentsState = ref.watch(_groupStudentsProvider(widget.group.name));

    return Scaffold(
      appBar: AppBar(
        title: Text('تقييم — ${widget.group.name}'),
        actions: [
          studentsState.maybeWhen(
            data: (students) => TextButton(
              onPressed: _saving ? null : () => _save(students),
              child: _saving
                  ? const SizedBox(width: 16, height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                  : const Text('حفظ الكل',
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            ),
            orElse: () => const SizedBox.shrink(),
          ),
        ],
      ),
      body: studentsState.when(
        loading: () => const Center(child: CircularProgressIndicator(color: AppColors.primary)),
        error:   (e, _) => Center(child: Text('$e')),
        data: (students) => Column(children: [
          // ── Type & Topic Bar ──────────────────────────
          Container(
            padding: const EdgeInsets.all(12),
            color: AppColors.primary.withOpacity(0.04),
            child: Column(children: [
              Row(
                children: _types.entries.map((e) => Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _type = e.key),
                    child: Container(
                      margin: const EdgeInsets.symmetric(horizontal: 3),
                      padding: const EdgeInsets.symmetric(vertical: 8),
                      decoration: BoxDecoration(
                        color: _type == e.key ? AppColors.primary : Colors.transparent,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: _type == e.key ? AppColors.primary : AppColors.borderLight),
                      ),
                      child: Text(e.value,
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              fontSize: 11,
                              fontWeight: FontWeight.bold,
                              color: _type == e.key ? Colors.white : AppColors.textSecondary)),
                    ),
                  ),
                )).toList(),
              ),
              const SizedBox(height: 8),
              TextField(
                decoration: const InputDecoration(
                  hintText: 'موضوع الجلسة (اختياري)...',
                  prefixIcon: Icon(Icons.topic_outlined),
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
                onChanged: (v) => _topic = v,
              ),
            ]),
          ),

          // ── Students List ─────────────────────────────
          Expanded(
            child: students.isEmpty
                ? const Center(child: Text('لا يوجد طلاب', style: TextStyle(color: AppColors.textSecondary)))
                : ListView.builder(
                    padding: const EdgeInsets.all(12),
                    itemCount: students.length,
                    itemBuilder: (_, i) {
                      final s   = students[i];
                      final sel = _grades[s.id];
                      final isDark = Theme.of(context).brightness == Brightness.dark;
                      final selIdx = sel != null ? _opts.indexWhere((o) => o['key'] == sel) : -1;
                      final bc = selIdx >= 0 ? _optColors[selIdx] : AppColors.borderLight;

                      return Container(
                        margin: const EdgeInsets.only(bottom: 10),
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: isDark ? AppColors.bgCardDark : AppColors.bgCard,
                          borderRadius: BorderRadius.circular(14),
                          border: Border.all(color: bc.withOpacity(sel != null ? 0.35 : 1.0)),
                        ),
                        child: Column(children: [
                          Row(children: [
                            Container(
                              width: 36, height: 36,
                              decoration: BoxDecoration(
                                  color: AppColors.primary.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(10)),
                              child: Center(child: Text(s.displayInitial,
                                  style: const TextStyle(color: AppColors.primary, fontWeight: FontWeight.bold))),
                            ),
                            const SizedBox(width: 10),
                            Expanded(child: Text(s.name, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14))),
                            if (sel != null && selIdx >= 0)
                              Text(_opts[selIdx]['emoji'] as String, style: const TextStyle(fontSize: 20)),
                          ]),
                          const SizedBox(height: 8),
                          Row(
                            children: List.generate(_opts.length, (oi) {
                              final o   = _opts[oi];
                              final isS = sel == o['key'];
                              final c   = _optColors[oi];
                              return Expanded(
                                child: GestureDetector(
                                  onTap: () => setState(() => _grades[s.id!] = o['key'] as String),
                                  child: Container(
                                    margin: const EdgeInsets.symmetric(horizontal: 2),
                                    padding: const EdgeInsets.symmetric(vertical: 7),
                                    decoration: BoxDecoration(
                                      color: isS ? c : c.withOpacity(0.08),
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(color: c.withOpacity(0.3)),
                                    ),
                                    child: Column(children: [
                                      Text(o['emoji'] as String, style: const TextStyle(fontSize: 13)),
                                      Text(o['label'] as String,
                                          style: TextStyle(fontSize: 10, color: isS ? Colors.white : c, fontWeight: FontWeight.bold)),
                                    ]),
                                  ),
                                ),
                              );
                            }),
                          ),
                        ]),
                      );
                    },
                  ),
          ),

          // ── Save Button ───────────────────────────────
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: ElevatedButton.icon(
                icon: const Icon(Icons.save, color: Colors.white),
                label: Text('حفظ ${_grades.length} تقييم',
                    style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.success,
                    minimumSize: const Size(double.infinity, 50),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14))),
                onPressed: _saving
                    ? null
                    : () => studentsState.whenData((s) => _save(s)),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
