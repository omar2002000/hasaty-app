// lib/main.dart
// Stage 7: added lock gate on startup and app resume.
// Uses WidgetsBindingObserver to detect background/foreground transitions.
// Lock is only shown when lock is enabled in AuthService.

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'core/theme/app_theme.dart';
import 'core/security/auth_service.dart';
import 'features/navigation/main_navigation.dart';
import 'features/auth/lock_screen.dart';
import 'core/navigation/app_routes.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor:         Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));

  final prefs       = await SharedPreferences.getInstance();
  final isDark      = prefs.getBool('darkMode') ?? false;
  final lockEnabled = await AuthService.instance.isLockEnabled;

  runApp(
    ProviderScope(
      child: HasatyApp(isDark: isDark, lockOnStartup: lockEnabled),
    ),
  );
}

class HasatyApp extends StatefulWidget {
  final bool isDark;
  final bool lockOnStartup;

  const HasatyApp({
    super.key,
    required this.isDark,
    this.lockOnStartup = false,
  });

  static _HasatyAppState? of(BuildContext context) =>
      context.findAncestorStateOfType<_HasatyAppState>();

  @override
  State<HasatyApp> createState() => _HasatyAppState();
}

class _HasatyAppState extends State<HasatyApp> with WidgetsBindingObserver {
  late bool _isDark;

  /// Whether the app is currently showing the lock screen.
  bool _isLocked = false;

  /// True once the user has unlocked at least once this session.
  /// Prevents re-locking if they never leave the foreground.
  bool _hasUnlockedOnce = false;

  @override
  void initState() {
    super.initState();
    _isDark   = widget.isDark;
    _isLocked = widget.lockOnStartup;
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  // ── Lifecycle: lock when app goes to background ───────────────

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      // App went to background — mark as needing lock on next resume
      _hasUnlockedOnce = false;
    } else if (state == AppLifecycleState.resumed) {
      // App came back to foreground — check if lock is still enabled
      _checkLockOnResume();
    }
  }

  Future<void> _checkLockOnResume() async {
    if (_hasUnlockedOnce) return; // already authenticated this foreground session
    final enabled = await AuthService.instance.isLockEnabled;
    if (enabled && mounted) {
      setState(() => _isLocked = true);
    }
  }

  void _onUnlocked() {
    setState(() {
      _isLocked        = false;
      _hasUnlockedOnce = true;
    });
  }

  // ── Theme ─────────────────────────────────────────────────────

  Future<void> toggleTheme(bool val) async {
    setState(() => _isDark = val);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('darkMode', val);
  }

  bool get isDark => _isDark;

  // ── Build ─────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'حصتي',

      theme:     AppTheme.light(),
      darkTheme: AppTheme.dark(),
      themeMode: _isDark ? ThemeMode.dark : ThemeMode.light,

      locale: const Locale('ar', 'EG'),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child!,
      ),

      // Stage 7: show LockScreen when locked, MainNavigation otherwise
      home: _isLocked
          ? LockScreen(onUnlocked: _onUnlocked)
          : const MainNavigation(),

      onGenerateRoute: AppRoutes.onGenerateRoute,
    );
  }
}
