// lib/data/models/student_model.dart
import '../../domain/entities/student.dart';

String _today() {
  final n = DateTime.now();
  return '${n.day}/${n.month}/${n.year}';
}

class StudentModel extends Student {
  const StudentModel({
    super.id,
    required super.name,
    required super.phone,
    super.parentPhone,
    required super.groupName,
    required super.joinDate,
    super.balance,
    super.xp,
    super.coins,
    super.archived,
    super.qrToken,   // Stage 1A: QR token
  });

  factory StudentModel.fromMap(Map<String, dynamic> m) {
    return StudentModel(
      id:          m['id']          as int?,
      name:        (m['name']        as String?) ?? '',
      phone:       (m['phone']       as String?) ?? '',
      parentPhone: (m['parentPhone'] as String?) ?? '',
      groupName:   (m['groupName']   as String?) ?? '',
      joinDate:    (m['joinDate']    as String?) ?? _today(),
      balance:     ((m['balance']    as num?)    ?? 0).toDouble(),
      xp:          (m['xp']          as int?)    ?? 0,
      coins:       (m['coins']       as int?)    ?? 0,
      archived:    ((m['archived']   as int?)    ?? 0) == 1,
      // qrToken: null-safe read — returns '' for rows migrated from v1
      qrToken:     (m['qrToken']    as String?)  ?? '',
    );
  }

  Map<String, dynamic> toMap() {
    return {
      if (id != null) 'id': id,
      'name':        name,
      'phone':       phone,
      'parentPhone': parentPhone,
      'groupName':   groupName,
      'joinDate':    joinDate,
      'balance':     balance,
      'xp':          xp,
      'coins':       coins,
      'archived':    archived ? 1 : 0,
      'qrToken':     qrToken,   // Stage 1A: persisted to DB
    };
  }

  factory StudentModel.fromEntity(Student s) {
    return StudentModel(
      id:          s.id,
      name:        s.name,
      phone:       s.phone,
      parentPhone: s.parentPhone,
      groupName:   s.groupName,
      joinDate:    s.joinDate,
      balance:     s.balance,
      xp:          s.xp,
      coins:       s.coins,
      archived:    s.archived,
      qrToken:     s.qrToken,   // Stage 1A: carried through
    );
  }
}
