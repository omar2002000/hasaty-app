// lib/data/models/app_models.dart
// ─────────────────────────────────────────────────────────────
// Data-layer models for all domain entities.
// Each model adds DB serialization (fromMap / toMap).
// ─────────────────────────────────────────────────────────────

import '../../domain/entities/group.dart';
import '../../domain/entities/subscription.dart';
import '../../domain/entities/payment.dart';
import '../../domain/entities/attendance_record.dart';
import '../../domain/entities/academic_grade.dart';
import '../../domain/entities/app_notification.dart';

String _today() {
  final n = DateTime.now();
  return '${n.day}/${n.month}/${n.year}';
}

// ─── GroupModel ───────────────────────────────────────────────

class GroupModel extends Group {
  const GroupModel({
    super.id,
    required super.name,
    required super.monthlyPrice,
    super.days,
    super.time,
  });

  factory GroupModel.fromMap(Map<String, dynamic> m) => GroupModel(
        id:           m['id'] as int?,
        name:         (m['name'] as String?) ?? '',
        monthlyPrice: ((m['monthlyPrice'] ?? m['price']) as num? ?? 0).toDouble(),
        days:         (m['days'] as String?) ?? '',
        time:         (m['time'] as String?) ?? '',
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'name':         name,
        'monthlyPrice': monthlyPrice,
        'days':         days,
        'time':         time,
      };

  factory GroupModel.fromEntity(Group g) => GroupModel(
        id: g.id, name: g.name, monthlyPrice: g.monthlyPrice, days: g.days, time: g.time,
      );
}

// ─── SubscriptionModel ────────────────────────────────────────

class SubscriptionModel extends Subscription {
  const SubscriptionModel({
    super.id,
    required super.studentId,
    required super.groupId,
    required super.studentName,
    required super.groupName,
    required super.month,
    required super.year,
    required super.amount,
    super.status,
    super.paidAmount,
    super.paidDate,
  });

  factory SubscriptionModel.fromMap(Map<String, dynamic> m) => SubscriptionModel(
        id:          m['id'] as int?,
        studentId:   m['studentId'] as int?,
        groupId:     m['groupId'] as int?,
        studentName: (m['studentName'] as String?) ?? '',
        groupName:   (m['groupName']   as String?) ?? '',
        month:       (m['month'] as int?) ?? 1,
        year:        (m['year']  as int?) ?? DateTime.now().year,
        amount:      ((m['amount']     as num?) ?? 0).toDouble(),
        status:      (m['status']      as String?) ?? 'unpaid',
        paidAmount:  ((m['paidAmount'] as num?) ?? 0).toDouble(),
        paidDate:    m['paidDate'] as String?,
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'studentId':  studentId,
        'groupId':    groupId,
        'studentName': studentName,
        'groupName':  groupName,
        'month':      month,
        'year':       year,
        'amount':     amount,
        'status':     status,
        'paidAmount': paidAmount,
        'paidDate':   paidDate,
      };

  factory SubscriptionModel.fromEntity(Subscription s) => SubscriptionModel(
        id: s.id, studentId: s.studentId, groupId: s.groupId,
        studentName: s.studentName, groupName: s.groupName,
        month: s.month, year: s.year, amount: s.amount,
        status: s.status, paidAmount: s.paidAmount, paidDate: s.paidDate,
      );
}

// ─── PaymentModel ─────────────────────────────────────────────

class PaymentModel extends Payment {
  const PaymentModel({
    super.id,
    required super.studentId,
    required super.studentName,
    required super.amount,
    required super.date,
    super.note,
    super.type,
  });

  factory PaymentModel.fromMap(Map<String, dynamic> m) => PaymentModel(
        id:          m['id'] as int?,
        studentId:   m['studentId'] as int?,
        studentName: (m['studentName'] as String?) ?? '',
        amount:      ((m['amount'] as num?) ?? 0).toDouble(),
        date:        (m['date'] as String?) ?? _today(),
        note:        (m['note'] as String?) ?? '',
        type:        (m['type'] as String?) ?? 'charge',
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'studentId':   studentId,
        'studentName': studentName,
        'amount':      amount,
        'date':        date,
        'note':        note,
        'type':        type,
      };

  factory PaymentModel.fromEntity(Payment p) => PaymentModel(
        id: p.id, studentId: p.studentId, studentName: p.studentName,
        amount: p.amount, date: p.date, note: p.note, type: p.type,
      );
}

// ─── AttendanceModel ──────────────────────────────────────────

class AttendanceModel extends AttendanceRecord {
  const AttendanceModel({
    super.id,
    required super.studentId,
    required super.studentName,
    required super.groupName,
    required super.date,
    required super.present,
  });

  factory AttendanceModel.fromMap(Map<String, dynamic> m) => AttendanceModel(
        id:          m['id'] as int?,
        studentId:   m['studentId'] as int?,
        studentName: (m['studentName'] as String?) ?? '',
        groupName:   (m['groupName']   as String?) ?? '',
        date:        (m['date']        as String?) ?? _today(),
        present:     ((m['present'] as int?) ?? 1) == 1,
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'studentId':   studentId,
        'studentName': studentName,
        'groupName':   groupName,
        'date':        date,
        'present':     present ? 1 : 0,
      };

  factory AttendanceModel.fromEntity(AttendanceRecord r) => AttendanceModel(
        id: r.id, studentId: r.studentId, studentName: r.studentName,
        groupName: r.groupName, date: r.date, present: r.present,
      );
}

// ─── AcademicGradeModel ───────────────────────────────────────

class AcademicGradeModel extends AcademicGrade {
  const AcademicGradeModel({
    super.id,
    required super.studentId,
    required super.studentName,
    required super.groupName,
    required super.type,
    required super.grade,
    super.score,
    super.note,
    required super.date,
    super.sessionTopic,
  });

  factory AcademicGradeModel.fromMap(Map<String, dynamic> m) => AcademicGradeModel(
        id:           m['id'] as int?,
        studentId:    m['studentId'] as int?,
        studentName:  (m['studentName']  as String?) ?? '',
        groupName:    (m['groupName']    as String?) ?? '',
        type:         (m['type']         as String?) ?? '',
        grade:        (m['grade']        as String?) ?? '',
        score:        ((m['score'] as num?) ?? 0).toInt(),
        note:         (m['note']         as String?) ?? '',
        date:         (m['date']         as String?) ?? _today(),
        sessionTopic: (m['sessionTopic'] as String?) ?? '',
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'studentId':   studentId,
        'studentName': studentName,
        'groupName':   groupName,
        'type':        type,
        'grade':       grade,
        'score':       score,
        'note':        note,
        'date':        date,
        'sessionTopic': sessionTopic,
      };

  factory AcademicGradeModel.fromEntity(AcademicGrade g) => AcademicGradeModel(
        id: g.id, studentId: g.studentId, studentName: g.studentName,
        groupName: g.groupName, type: g.type, grade: g.grade,
        score: g.score, note: g.note, date: g.date, sessionTopic: g.sessionTopic,
      );
}

// ─── NotificationModel ────────────────────────────────────────

class NotificationModel extends AppNotification {
  const NotificationModel({
    super.id,
    super.studentId,
    required super.title,
    required super.body,
    required super.type,
    required super.date,
    super.isRead,
  });

  factory NotificationModel.fromMap(Map<String, dynamic> m) => NotificationModel(
        id:        m['id'] as int?,
        studentId: m['studentId'] as int?,
        title:     (m['title'] as String?) ?? '',
        body:      (m['body']  as String?) ?? '',
        type:      (m['type']  as String?) ?? '',
        date:      (m['date']  as String?) ?? _today(),
        isRead:    ((m['isRead'] as int?) ?? 0) == 1,
      );

  Map<String, dynamic> toMap() => {
        if (id != null) 'id': id,
        'studentId': studentId,
        'title':     title,
        'body':      body,
        'type':      type,
        'date':      date,
        'isRead':    isRead ? 1 : 0,
      };
}
