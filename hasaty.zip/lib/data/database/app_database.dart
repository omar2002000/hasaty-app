// lib/data/database/app_database.dart
// ─────────────────────────────────────────────────────────────
// Single database instance — the ONLY class that touches SQLite.
// Contains ALL tables. Never used directly from UI.
//
// v1 → v2: ALTER TABLE students ADD COLUMN qrToken (Stage 1A)
// v2 → v3: CREATE TABLE audit_logs (Stage 8)
//   Safe: new table only, no existing data touched.
// ─────────────────────────────────────────────────────────────

import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class AppDatabase {
  static final AppDatabase instance = AppDatabase._init();
  static Database? _database;

  AppDatabase._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('hasaty_v4.db');
    return _database!;
  }

  Future<Database> _initDB(String fileName) async {
    final dbPath = await getDatabasesPath();
    final path   = join(dbPath, fileName);
    return await openDatabase(
      path,
      version:   3,           // v3: audit_logs table
      onCreate:  _createDB,
      onUpgrade: _upgradeDB,
    );
  }

  // ─── Schema (fresh install) ───────────────────────────────────
  Future<void> _createDB(Database db, int version) async {
    const id   = 'INTEGER PRIMARY KEY AUTOINCREMENT';
    const txt  = 'TEXT NOT NULL';
    const intN = 'INTEGER NOT NULL';
    const real = 'REAL NOT NULL';

    await db.execute('''
      CREATE TABLE students (
        id          $id,
        name        $txt,
        phone       $txt,
        parentPhone TEXT DEFAULT '',
        groupName   $txt,
        joinDate    $txt,
        balance     $real DEFAULT 0.0,
        xp          $intN DEFAULT 0,
        coins       $intN DEFAULT 0,
        archived    $intN DEFAULT 0,
        qrToken     TEXT DEFAULT ''
      )
    ''');
    await db.execute('''
      CREATE TABLE groups (
        id           $id,
        name         $txt,
        monthlyPrice $real DEFAULT 0.0,
        days         TEXT DEFAULT '',
        time         TEXT DEFAULT ''
      )
    ''');
    await db.execute('''
      CREATE TABLE payments (
        id          $id,
        studentId   $intN,
        studentName $txt,
        amount      $real,
        date        $txt,
        note        TEXT DEFAULT '',
        type        $txt DEFAULT 'charge'
      )
    ''');
    await db.execute('''
      CREATE TABLE subscriptions (
        id          $id,
        studentId   $intN,
        groupId     $intN,
        studentName $txt,
        groupName   $txt,
        month       $intN,
        year        $intN,
        amount      $real,
        paidAmount  $real DEFAULT 0.0,
        status      $txt DEFAULT 'unpaid',
        paidDate    TEXT
      )
    ''');
    await db.execute('''
      CREATE TABLE attendance (
        id          $id,
        studentId   $intN,
        studentName $txt,
        groupName   $txt,
        date        $txt,
        present     $intN DEFAULT 1
      )
    ''');
    await db.execute('''
      CREATE TABLE grades (
        id           $id,
        studentId    $intN,
        studentName  $txt,
        groupName    $txt,
        type         $txt,
        grade        $txt,
        score        $real DEFAULT 0.0,
        note         TEXT DEFAULT '',
        date         $txt,
        sessionTopic TEXT DEFAULT ''
      )
    ''');
    await db.execute('''
      CREATE TABLE notifications (
        id        $id,
        title     $txt,
        body      $txt,
        type      $txt,
        date      $txt,
        studentId INTEGER,
        isRead    $intN DEFAULT 0
      )
    ''');
    await db.execute('''
      CREATE TABLE coin_transactions (
        id          $id,
        studentId   $intN,
        studentName $txt,
        amount      $intN,
        reason      $txt,
        date        $txt,
        type        $txt DEFAULT 'earned'
      )
    ''');
    await db.execute('''
      CREATE TABLE student_achievements (
        id            $id,
        studentId     $intN,
        achievementId $txt,
        date          $txt
      )
    ''');

    // Stage 8: audit_logs table
    await _createAuditTable(db);
  }

  // ─── Safe incremental migrations ─────────────────────────────
  Future<void> _upgradeDB(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < 2) {
      await db.execute(
        "ALTER TABLE students ADD COLUMN qrToken TEXT DEFAULT ''",
      );
    }
    if (oldVersion < 3) {
      // Stage 8: create audit_logs table for existing installs
      await _createAuditTable(db);
    }
    // Add if (oldVersion < 4) { ... } for future migrations
  }

  /// Creates audit_logs table. Called by both _createDB and _upgradeDB.
  Future<void> _createAuditTable(Database db) async {
    await db.execute('''
      CREATE TABLE IF NOT EXISTS audit_logs (
        id          INTEGER PRIMARY KEY AUTOINCREMENT,
        actionType  TEXT    NOT NULL,
        studentId   INTEGER,
        studentName TEXT    NOT NULL DEFAULT '',
        description TEXT    NOT NULL,
        timestamp   TEXT    NOT NULL
      )
    ''');
  }

  Future<void> close() async {
    final db = await instance.database;
    db.close();
    _database = null;
  }
}
