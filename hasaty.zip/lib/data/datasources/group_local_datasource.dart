// lib/data/datasources/group_local_datasource.dart
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/app_models.dart';
import '../../domain/entities/group.dart';

abstract class GroupLocalDataSource {
  Future<List<Group>> getAll();
  Future<int> insert(Group g);
  Future<void> update(Group g);
  Future<int> delete(int id);
}

class GroupLocalDataSourceImpl implements GroupLocalDataSource {
  Future<Database> get _db async => AppDatabase.instance.database;

  @override
  Future<List<Group>> getAll() async {
    final db   = await _db;
    final rows = await db.query('groups', orderBy: 'name ASC');
    return rows.map(GroupModel.fromMap).toList();
  }

  @override
  Future<int> insert(Group g) async {
    final db = await _db;
    return db.insert('groups', GroupModel.fromEntity(g).toMap());
  }

  @override
  Future<void> update(Group g) async {
    final db = await _db;
    await db.update('groups', GroupModel.fromEntity(g).toMap(),
        where: 'id = ?', whereArgs: [g.id]);
  }

  @override
  Future<int> delete(int id) async {
    final db = await _db;
    return db.delete('groups', where: 'id = ?', whereArgs: [id]);
  }
}
