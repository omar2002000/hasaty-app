// lib/data/datasources/notification_local_datasource.dart
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/app_models.dart';
import '../../domain/entities/app_notification.dart';

abstract class NotificationLocalDataSource {
  Future<void> insert(AppNotification n);
  Future<List<AppNotification>> getAll();
  Future<int> getUnreadCount();
  Future<void> markAllRead();
}

class NotificationLocalDataSourceImpl implements NotificationLocalDataSource {
  Future<Database> get _db async => AppDatabase.instance.database;

  @override
  Future<void> insert(AppNotification n) async {
    final db = await _db;
    await db.insert('notifications', NotificationModel(
      studentId: n.studentId, title: n.title, body: n.body,
      type: n.type, date: n.date, isRead: n.isRead,
    ).toMap());
  }

  @override
  Future<List<AppNotification>> getAll() async {
    final db   = await _db;
    final rows = await db.query('notifications', orderBy: 'id DESC', limit: 100);
    return rows.map(NotificationModel.fromMap).toList();
  }

  @override
  Future<int> getUnreadCount() async {
    final db   = await _db;
    final rows = await db.query('notifications', where: 'isRead = 0');
    return rows.length;
  }

  @override
  Future<void> markAllRead() async {
    final db = await _db;
    await db.update('notifications', {'isRead': 1});
  }
}
