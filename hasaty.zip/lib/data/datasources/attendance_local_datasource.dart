// lib/data/datasources/attendance_local_datasource.dart
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/app_models.dart';
import '../../domain/entities/attendance_record.dart';

abstract class AttendanceLocalDataSource {
  Future<void> insertRecord(AttendanceRecord r);
  Future<List<AttendanceRecord>> getByStudent(int studentId);
  Future<bool> recordExistsToday(int studentId, String groupName, String date);

  /// Stage 1C: group-agnostic duplicate check.
  /// Used when scanner has no group context (launched from dashboard).
  Future<bool> recordExistsTodayForStudent(int studentId, String date);
}

class AttendanceLocalDataSourceImpl implements AttendanceLocalDataSource {
  Future<Database> get _db async => AppDatabase.instance.database;

  @override
  Future<void> insertRecord(AttendanceRecord r) async {
    final db = await _db;
    await db.insert('attendance', AttendanceModel.fromEntity(r).toMap());
  }

  @override
  Future<List<AttendanceRecord>> getByStudent(int studentId) async {
    final db   = await _db;
    final rows = await db.query('attendance',
        where: 'studentId = ?', whereArgs: [studentId], orderBy: 'id DESC');
    return rows.map(AttendanceModel.fromMap).toList();
  }

  @override
  Future<bool> recordExistsToday(
      int studentId, String groupName, String date) async {
    final db   = await _db;
    final rows = await db.query('attendance',
        where:     'studentId = ? AND date = ? AND groupName = ?',
        whereArgs: [studentId, date, groupName]);
    return rows.isNotEmpty;
  }

  /// Stage 1C: checks ANY present record for this student today,
  /// regardless of group. Prevents double-marking in QR scanner
  /// sessions that have no specific group context.
  @override
  Future<bool> recordExistsTodayForStudent(int studentId, String date) async {
    final db   = await _db;
    final rows = await db.query('attendance',
        where:     'studentId = ? AND date = ? AND present = 1',
        whereArgs: [studentId, date],
        limit:     1);
    return rows.isNotEmpty;
  }
}
