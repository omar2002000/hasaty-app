// lib/data/datasources/student_local_datasource.dart
// Pure CRUD. No business logic allowed here.
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/student_model.dart';
import '../../domain/entities/student.dart';

abstract class StudentLocalDataSource {
  Future<List<Student>> getAll({bool includeArchived = false});
  Future<Student?> getById(int id);
  Future<int> insert(Student student);
  Future<int> update(Student student);
  Future<void> archive(int id);
  Future<void> restore(int id);
  Future<List<Student>> getWithDebt();
  Future<List<Student>> getArchived();
  /// Stage 2B: permanent hard delete — removes all student data.
  Future<void> hardDelete(int id);
}

class StudentLocalDataSourceImpl implements StudentLocalDataSource {
  Future<Database> get _db async => AppDatabase.instance.database;

  @override
  Future<List<Student>> getAll({bool includeArchived = false}) async {
    final db   = await _db;
    final rows = includeArchived
        ? await db.query('students', orderBy: 'xp DESC')
        : await db.query('students', where: 'archived = 0', orderBy: 'xp DESC');
    return rows.map(StudentModel.fromMap).toList();
  }

  @override
  Future<Student?> getById(int id) async {
    final db   = await _db;
    final rows = await db.query('students', where: 'id = ?', whereArgs: [id]);
    if (rows.isEmpty) return null;
    return StudentModel.fromMap(rows.first);
  }

  @override
  Future<int> insert(Student student) async {
    final db    = await _db;
    final model = StudentModel.fromEntity(student);
    return db.insert('students', model.toMap());
  }

  @override
  Future<int> update(Student student) async {
    final db    = await _db;
    final model = StudentModel.fromEntity(student);
    return db.update('students', model.toMap(),
        where: 'id = ?', whereArgs: [student.id]);
  }

  @override
  Future<void> archive(int id) async {
    final db = await _db;
    await db.update('students', {'archived': 1},
        where: 'id = ?', whereArgs: [id]);
  }

  @override
  Future<void> restore(int id) async {
    final db = await _db;
    await db.update('students', {'archived': 0},
        where: 'id = ?', whereArgs: [id]);
  }

  @override
  Future<List<Student>> getWithDebt() async {
    final db   = await _db;
    final rows = await db.query('students',
        where: 'balance < 0 AND archived = 0', orderBy: 'balance ASC');
    return rows.map(StudentModel.fromMap).toList();
  }

  @override
  Future<List<Student>> getArchived() async {
    final db   = await _db;
    final rows = await db.query('students',
        where: 'archived = 1', orderBy: 'name ASC');
    return rows.map(StudentModel.fromMap).toList();
  }

  /// Stage 2B: hard delete — removes student row and all related records.
  /// Called only after explicit user confirmation ("تأكيد الحذف النهائي").
  @override
  Future<void> hardDelete(int id) async {
    final db = await _db;
    // Remove all related data in correct order (no FK constraints in SQLite by default)
    await db.delete('attendance',          where: 'studentId = ?', whereArgs: [id]);
    await db.delete('payments',            where: 'studentId = ?', whereArgs: [id]);
    await db.delete('subscriptions',       where: 'studentId = ?', whereArgs: [id]);
    await db.delete('grades',              where: 'studentId = ?', whereArgs: [id]);
    await db.delete('coin_transactions',   where: 'studentId = ?', whereArgs: [id]);
    await db.delete('student_achievements',where: 'studentId = ?', whereArgs: [id]);
    await db.delete('notifications',       where: 'studentId = ?', whereArgs: [id]);
    await db.delete('students',            where: 'id = ?',        whereArgs: [id]);
  }
}
