// lib/data/datasources/achievement_local_datasource.dart
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';

abstract class AchievementLocalDataSource {
  Future<List<String>> getByStudent(int studentId);
  Future<void> grant(int studentId, String achievementId, String date);
  Future<bool> hasAchievement(int studentId, String achievementId);
}

class AchievementLocalDataSourceImpl implements AchievementLocalDataSource {
  Future<Database> get _db async => AppDatabase.instance.database;

  @override
  Future<List<String>> getByStudent(int studentId) async {
    final db   = await _db;
    final rows = await db.query('student_achievements',
        where: 'studentId = ?', whereArgs: [studentId]);
    return rows.map((e) => e['achievementId'] as String).toList();
  }

  @override
  Future<void> grant(int studentId, String achievementId, String date) async {
    final db = await _db;
    await db.insert('student_achievements', {
      'studentId':     studentId,
      'achievementId': achievementId,
      'date':          date,
    });
  }

  @override
  Future<bool> hasAchievement(int studentId, String achievementId) async {
    final db   = await _db;
    final rows = await db.query('student_achievements',
        where:     'studentId = ? AND achievementId = ?',
        whereArgs: [studentId, achievementId]);
    return rows.isNotEmpty;
  }
}
