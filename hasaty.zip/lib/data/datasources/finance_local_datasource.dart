// lib/data/datasources/finance_local_datasource.dart
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/app_models.dart';
import '../../domain/entities/subscription.dart';
import '../../domain/entities/payment.dart';

abstract class FinanceLocalDataSource {
  Future<int> insertPayment(Payment p);
  Future<List<Payment>> getAllPayments();
  Future<List<Payment>> getStudentPayments(int studentId);
  Future<int> insertSubscription(Subscription s);
  Future<List<Subscription>> getSubscriptions({int? month, int? year, int? studentId});
  Future<bool> subscriptionExists(int studentId, int groupId, int month, int year);
  Future<void> updateSubscription(Subscription s);
}

class FinanceLocalDataSourceImpl implements FinanceLocalDataSource {
  Future<Database> get _db async => AppDatabase.instance.database;

  @override
  Future<int> insertPayment(Payment p) async {
    final db = await _db;
    return db.insert('payments', PaymentModel.fromEntity(p).toMap());
  }

  @override
  Future<List<Payment>> getAllPayments() async {
    final db   = await _db;
    final rows = await db.query('payments', orderBy: 'id DESC');
    return rows.map(PaymentModel.fromMap).toList();
  }

  @override
  Future<List<Payment>> getStudentPayments(int studentId) async {
    final db   = await _db;
    final rows = await db.query('payments',
        where: 'studentId = ?', whereArgs: [studentId], orderBy: 'id DESC');
    return rows.map(PaymentModel.fromMap).toList();
  }

  @override
  Future<int> insertSubscription(Subscription s) async {
    final db = await _db;
    return db.insert('subscriptions', SubscriptionModel.fromEntity(s).toMap());
  }

  @override
  Future<List<Subscription>> getSubscriptions(
      {int? month, int? year, int? studentId}) async {
    final db = await _db;
    String? where;
    List<dynamic>? args;
    if (month != null && year != null) {
      where = 'month = ? AND year = ?';
      args  = [month, year];
    } else if (studentId != null) {
      where = 'studentId = ?';
      args  = [studentId];
    }
    final rows = await db.query('subscriptions',
        where: where, whereArgs: args, orderBy: 'year DESC, month DESC');
    return rows.map(SubscriptionModel.fromMap).toList();
  }

  @override
  Future<bool> subscriptionExists(
      int studentId, int groupId, int month, int year) async {
    final db   = await _db;
    final rows = await db.query('subscriptions',
        where:     'studentId = ? AND groupId = ? AND month = ? AND year = ?',
        whereArgs: [studentId, groupId, month, year]);
    return rows.isNotEmpty;
  }

  @override
  Future<void> updateSubscription(Subscription s) async {
    final db = await _db;
    await db.update('subscriptions', SubscriptionModel.fromEntity(s).toMap(),
        where: 'id = ?', whereArgs: [s.id]);
  }
}
