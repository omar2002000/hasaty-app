// lib/data/datasources/coin_local_datasource.dart
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';

abstract class CoinLocalDataSource {
  Future<void> award(int studentId, String name, int amount, String reason, String date);
  Future<void> spend(int studentId, String name, int amount, String reason, String date);
  Future<int> getCoins(int studentId);
}

class CoinLocalDataSourceImpl implements CoinLocalDataSource {
  Future<Database> get _db async => AppDatabase.instance.database;

  @override
  Future<void> award(int studentId, String name, int amount, String reason, String date) async {
    final db = await _db;
    await db.rawUpdate('UPDATE students SET coins = COALESCE(coins,0) + ? WHERE id = ?',
        [amount, studentId]);
    await db.insert('coin_transactions', {
      'studentId': studentId, 'studentName': name,
      'amount': amount, 'reason': reason, 'date': date, 'type': 'earned',
    });
  }

  @override
  Future<void> spend(int studentId, String name, int amount, String reason, String date) async {
    final db = await _db;
    await db.rawUpdate('UPDATE students SET coins = COALESCE(coins,0) - ? WHERE id = ?',
        [amount, studentId]);
    await db.insert('coin_transactions', {
      'studentId': studentId, 'studentName': name,
      'amount': -amount, 'reason': reason, 'date': date, 'type': 'spent',
    });
  }

  @override
  Future<int> getCoins(int studentId) async {
    final db   = await _db;
    final rows = await db.query('students',
        columns: ['coins'], where: 'id = ?', whereArgs: [studentId]);
    return rows.isEmpty ? 0 : (rows.first['coins'] as int? ?? 0);
  }
}
