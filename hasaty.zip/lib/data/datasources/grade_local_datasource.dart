// lib/data/datasources/grade_local_datasource.dart
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/app_models.dart';
import '../../domain/entities/academic_grade.dart';

abstract class GradeLocalDataSource {
  Future<int> insert(AcademicGrade g);
  Future<List<AcademicGrade>> getAll();
  Future<List<AcademicGrade>> getByStudent(int studentId);
}

class GradeLocalDataSourceImpl implements GradeLocalDataSource {
  Future<Database> get _db async => AppDatabase.instance.database;

  @override
  Future<int> insert(AcademicGrade g) async {
    final db = await _db;
    return db.insert('grades', AcademicGradeModel.fromEntity(g).toMap());
  }

  @override
  Future<List<AcademicGrade>> getAll() async {
    final db   = await _db;
    final rows = await db.query('grades', orderBy: 'id DESC');
    return rows.map(AcademicGradeModel.fromMap).toList();
  }

  @override
  Future<List<AcademicGrade>> getByStudent(int studentId) async {
    final db   = await _db;
    final rows = await db.query('grades',
        where: 'studentId = ?', whereArgs: [studentId], orderBy: 'id DESC');
    return rows.map(AcademicGradeModel.fromMap).toList();
  }
}
