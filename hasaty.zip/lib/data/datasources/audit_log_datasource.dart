// lib/data/datasources/audit_log_datasource.dart
// Stage 8 — CRUD for audit_logs table. No business logic.
import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../../domain/entities/audit_log.dart';

abstract class AuditLogLocalDataSource {
  Future<void> insert(AuditLog log);
  Future<List<AuditLog>> getAll({int limit = 200});
  Future<List<AuditLog>> getByStudent(int studentId);
  Future<void> clearOlderThan(int days);
}

class AuditLogLocalDataSourceImpl implements AuditLogLocalDataSource {
  Future<Database> get _db async => AppDatabase.instance.database;

  @override
  Future<void> insert(AuditLog log) async {
    final db = await _db;
    await db.insert('audit_logs', {
      'actionType':  log.actionType,
      'studentId':   log.studentId,
      'studentName': log.studentName,
      'description': log.description,
      'timestamp':   log.timestamp,
    });
  }

  @override
  Future<List<AuditLog>> getAll({int limit = 200}) async {
    final db   = await _db;
    final rows = await db.query(
      'audit_logs',
      orderBy: 'id DESC',
      limit:   limit,
    );
    return rows.map(_fromMap).toList();
  }

  @override
  Future<List<AuditLog>> getByStudent(int studentId) async {
    final db   = await _db;
    final rows = await db.query(
      'audit_logs',
      where:     'studentId = ?',
      whereArgs: [studentId],
      orderBy:   'id DESC',
      limit:     100,
    );
    return rows.map(_fromMap).toList();
  }

  /// Auto-cleanup: delete logs older than [days] to avoid unbounded growth.
  @override
  Future<void> clearOlderThan(int days) async {
    // Logs use 'dd/MM/yyyy HH:mm' format — we compare by row ID offset
    // (simpler than parsing dates). Keep the last 1000 entries.
    final db    = await _db;
    final count = Sqflite.firstIntValue(
        await db.rawQuery('SELECT COUNT(*) FROM audit_logs'));
    if ((count ?? 0) > 1000) {
      await db.rawDelete('''
        DELETE FROM audit_logs WHERE id NOT IN (
          SELECT id FROM audit_logs ORDER BY id DESC LIMIT 1000
        )
      ''');
    }
  }

  static AuditLog _fromMap(Map<String, dynamic> m) => AuditLog(
    id:          m['id'] as int?,
    actionType:  (m['actionType']  as String?) ?? '',
    studentId:   m['studentId'] as int?,
    studentName: (m['studentName'] as String?) ?? '',
    description: (m['description'] as String?) ?? '',
    timestamp:   (m['timestamp']   as String?) ?? '',
  );
}
