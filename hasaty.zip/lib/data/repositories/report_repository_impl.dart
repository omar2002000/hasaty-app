// lib/data/repositories/report_repository_impl.dart
// ملاحظة: منطق التقارير مُعالَج في GetSmartReportUseCase.
// هذا الملف محفوظ للتوافق — لا يُستخدم مباشرة.
// استخدم: domain/usecases/finance/get_smart_report_usecase.dart
