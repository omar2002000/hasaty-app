// lib/data/repositories/achievement_repository_impl.dart
import '../../domain/repositories/achievement_repository.dart';
import '../datasources/achievement_local_datasource.dart';
import '../datasources/student_local_datasource.dart';
import '../datasources/attendance_local_datasource.dart';
import '../datasources/finance_local_datasource.dart';

String _today() { final n = DateTime.now(); return '${n.day}/${n.month}/${n.year}'; }

class AchievementRepositoryImpl implements AchievementRepository {
  final AchievementLocalDataSource _ds;
  final StudentLocalDataSource     _studentDs;
  final AttendanceLocalDataSource  _attendanceDs;
  final FinanceLocalDataSource     _financeDs;

  AchievementRepositoryImpl(this._ds, this._studentDs, this._attendanceDs, this._financeDs);

  @override
  Future<List<String>> getStudentAchievements(int studentId) => _ds.getByStudent(studentId);

  @override
  Future<void> checkAndGrantAchievements(int studentId) async {
    final s = await _studentDs.getById(studentId);
    if (s == null) return;
    final today   = _today();
    final records = await _attendanceDs.getByStudent(studentId);
    final subs    = await _financeDs.getSubscriptions(studentId: studentId);

    Future<void> grant(String id) async {
      if (!await _ds.hasAchievement(studentId, id)) await _ds.grant(studentId, id, today);
    }
    if (s.xp >= 50)  await grant('xp_50');
    if (s.xp >= 200) await grant('xp_200');
    if (s.xp >= 500) await grant('xp_500');
    if (s.balance >= 0) await grant('regular_payment');
    if (records.length >= 10 && records.take(10).every((r) => r.present)) await grant('attend_10');
    if (subs.where((x) => x.status == 'paid').length >= 3) await grant('sub_paid_3');
  }
}
