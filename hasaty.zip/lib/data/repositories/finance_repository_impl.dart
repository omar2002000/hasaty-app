// lib/data/repositories/finance_repository_impl.dart
import '../../domain/entities/payment.dart';
import '../../domain/entities/subscription.dart';
import '../../domain/entities/student.dart';
import '../../domain/repositories/finance_repository.dart';
import '../datasources/finance_local_datasource.dart';
import '../datasources/student_local_datasource.dart';
import '../datasources/group_local_datasource.dart';

String _today() { final n = DateTime.now(); return '${n.day}/${n.month}/${n.year}'; }

class FinanceRepositoryImpl implements FinanceRepository {
  final FinanceLocalDataSource _ds;
  final StudentLocalDataSource _studentDs;
  final GroupLocalDataSource   _groupDs;

  FinanceRepositoryImpl(this._ds, this._studentDs, this._groupDs);

  @override
  Future<int> addPayment(Payment p) => _ds.insertPayment(p);

  @override
  Future<List<Payment>> getAllPayments() => _ds.getAllPayments();

  @override
  Future<List<Payment>> getStudentPayments(int studentId) =>
      _ds.getStudentPayments(studentId);

  @override
  Future<double> getTotalThisMonth() async {
    final now      = DateTime.now();
    final suffix   = '/${now.month}/${now.year}';
    final payments = await _ds.getAllPayments();
    return payments
        .where((p) => p.date.endsWith(suffix))
        .fold<double>(0.0, (s, p) => s + p.amount);
  }

  @override
  Future<int> addSubscription(Subscription s) => _ds.insertSubscription(s);

  @override
  Future<List<Subscription>> getSubscriptions(
          {int? month, int? year, int? studentId}) =>
      _ds.getSubscriptions(month: month, year: year, studentId: studentId);

  @override
  Future<bool> subscriptionExists(
          int studentId, int groupId, int month, int year) =>
      _ds.subscriptionExists(studentId, groupId, month, year);

  @override
  Future<void> updateSubscription(Subscription s) =>
      _ds.updateSubscription(s);

  // ─── Monthly Engine ───────────────────────────────────────────
  // Preserves exact logic from original FinanceService.runMonthlyEngine
  @override
  Future<Map<String, int>> runMonthlyEngine(int month, int year) async {
    final students = await _studentDs.getAll();
    final groups   = await _groupDs.getAll();
    int created = 0, skipped = 0;

    for (final s in students) {
      try {
        final g = groups.firstWhere((g) => g.name == s.groupName);
        if (await _ds.subscriptionExists(s.id!, g.id!, month, year)) {
          skipped++;
          continue;
        }
        double amount = g.monthlyPrice;
        // Half price if joined after 15th of that month
        try {
          final parts = s.joinDate.split('/');
          if (int.parse(parts[2]) == year &&
              int.parse(parts[1]) == month &&
              int.parse(parts[0]) > 15) {
            amount /= 2;
          }
        } catch (_) {}

        await _ds.insertSubscription(Subscription(
          studentId:   s.id!,
          groupId:     g.id!,
          studentName: s.name,
          groupName:   g.name,
          month:       month,
          year:        year,
          amount:      amount,
        ));
        final updated = s.copyWith(balance: s.balance - amount);
        await _studentDs.update(updated);
        created++;
      } catch (_) {
        skipped++;
      }
    }
    return {'created': created, 'skipped': skipped};
  }

  // ─── Pay Subscription ─────────────────────────────────────────
  // Preserves exact logic from FinanceService.paySubscription
  Future<void> paySubscription(
      Subscription sub, double amount, Student student) async {
    final paid   = amount > sub.remainingAmount ? sub.remainingAmount : amount;
    final newPaid = sub.paidAmount + paid;
    final newStatus = newPaid >= sub.amount ? 'paid' : 'partial';

    final updatedSub = sub.copyWith(
      paidAmount: newPaid,
      status:     newStatus,
      paidDate:   _today(),
    );
    await _ds.updateSubscription(updatedSub);

    final updatedStudent = student.copyWith(balance: student.balance + paid);
    await _studentDs.update(updatedStudent);

    await _ds.insertPayment(Payment(
      studentId:   student.id!,
      studentName: student.name,
      amount:      paid,
      date:        _today(),
      note:        'اشتراك ${updatedSub.monthName} ${sub.year}',
      type:        'subscription',
    ));
  }
}
