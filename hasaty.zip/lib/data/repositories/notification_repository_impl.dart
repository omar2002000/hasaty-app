// lib/data/repositories/notification_repository_impl.dart
// Stage 3C: added payment reminders (3 days before due + overdue).
import '../../domain/entities/app_notification.dart';
import '../../domain/repositories/notification_repository.dart';
import '../datasources/notification_local_datasource.dart';
import '../datasources/student_local_datasource.dart';
import '../datasources/attendance_local_datasource.dart';
import '../datasources/finance_local_datasource.dart';

String _today() { final n = DateTime.now(); return '${n.day}/${n.month}/${n.year}'; }

class NotificationRepositoryImpl implements NotificationRepository {
  final NotificationLocalDataSource _ds;
  final StudentLocalDataSource      _studentDs;
  final AttendanceLocalDataSource   _attendanceDs;
  final FinanceLocalDataSource      _financeDs;

  NotificationRepositoryImpl(
      this._ds, this._studentDs, this._attendanceDs, this._financeDs);

  @override Future<void>                  addNotification(AppNotification n) => _ds.insert(n);
  @override Future<List<AppNotification>> getAllNotifications()               => _ds.getAll();
  @override Future<int>                   getUnreadCount()                   => _ds.getUnreadCount();
  @override Future<void>                  markAllRead()                      => _ds.markAllRead();

  @override
  Future<void> generateSmartNotifications() async {
    final students = await _studentDs.getAll();
    final today    = _today();
    final now      = DateTime.now();

    for (final s in students) {
      // 1. Attendance alerts
      final records = await _attendanceDs.getByStudent(s.id!);
      final pct = records.isEmpty ? 0.0
          : records.where((r) => r.present).length / records.length * 100;

      if (s.balance < -200) {
        await _ds.insert(AppNotification(
          title: 'دين متراكم — ${s.name}',
          body:  'رصيد ${s.name} أصبح ${s.balance.toStringAsFixed(0)} ج.م',
          type:  'debt', date: today, studentId: s.id));
      }
      if (pct < 50 && pct > 0) {
        await _ds.insert(AppNotification(
          title: 'غياب متكرر — ${s.name}',
          body:  'نسبة حضور ${s.name}: ${pct.toStringAsFixed(0)}%',
          type:  'absence', date: today, studentId: s.id));
      }

      // 2. Stage 3C: payment due reminders
      // Check subscriptions for current + next month
      for (int delta = 0; delta <= 1; delta++) {
        final targetMonth = now.month + delta > 12
            ? now.month + delta - 12 : now.month + delta;
        final targetYear  = now.month + delta > 12 ? now.year + 1 : now.year;

        final subs = await _financeDs.getSubscriptions(
            studentId: s.id, month: targetMonth, year: targetYear);

        for (final sub in subs) {
          if (sub.status == 'unpaid' || sub.status == 'partial') {
            // Due date: last day of target month
            final lastDay = DateTime(targetYear,
                targetMonth < 12 ? targetMonth + 1 : 1, 0).day;
            final dueDate = DateTime(targetYear, targetMonth, lastDay);
            final daysLeft = dueDate.difference(now).inDays;

            if (daysLeft <= 3 && daysLeft >= 0) {
              // 3-day reminder
              await _ds.insert(AppNotification(
                title: 'تذكير دفع — ${s.name}',
                body:  'اشتراك ${sub.monthName} ${sub.year} يستحق خلال $daysLeft يوم',
                type:  'payment_due', date: today, studentId: s.id));
            } else if (daysLeft < 0) {
              // Overdue
              await _ds.insert(AppNotification(
                title: 'دفعة متأخرة — ${s.name}',
                body:  'اشتراك ${sub.monthName} ${sub.year} متأخر ${(-daysLeft)} يوم',
                type:  'overdue', date: today, studentId: s.id));
            }
          }
        }
      }
    }
  }
}
