// lib/data/repositories/student_repository_impl.dart
import '../../domain/entities/student.dart';
import '../../domain/repositories/student_repository.dart';
import '../datasources/student_local_datasource.dart';
import '../../features/qr/qr_token_generator.dart'; // Stage 1A

class StudentRepositoryImpl implements StudentRepository {
  final StudentLocalDataSource _ds;
  StudentRepositoryImpl(this._ds);

  @override
  Future<List<Student>> getStudents({bool includeArchived = false}) =>
      _ds.getAll(includeArchived: includeArchived);

  @override
  Future<Student?> getStudentById(int id) => _ds.getById(id);

  /// Stage 1A: auto-generate QR token after DB insert.
  @override
  Future<int> addStudent(Student student) async {
    final newId = await _ds.insert(student);
    final token = QrTokenGenerator.generate(newId);
    await _ds.update(student.copyWith(id: newId, qrToken: token));
    return newId;
  }

  @override
  Future<int> updateStudent(Student student) => _ds.update(student);

  @override
  Future<void> archiveStudent(int id) => _ds.archive(id);

  @override
  Future<void> restoreStudent(int id) => _ds.restore(id);

  @override
  Future<List<Student>> getStudentsWithDebt() => _ds.getWithDebt();

  @override
  Future<List<Student>> getArchivedStudents() => _ds.getArchived();

  /// Stage 2B: permanent hard delete — cascades to all related tables.
  @override
  Future<void> hardDeleteStudent(int id) => _ds.hardDelete(id);
}
