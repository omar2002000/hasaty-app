// lib/data/repositories/attendance_repository_impl.dart
// Stage 6C: invalidates AttendanceCache on every write operation.
import '../../domain/entities/attendance_record.dart';
import '../../domain/entities/student.dart';
import '../../domain/repositories/attendance_repository.dart';
import '../../core/cache/attendance_cache.dart';
import '../datasources/attendance_local_datasource.dart';
import '../datasources/student_local_datasource.dart';
import '../datasources/achievement_local_datasource.dart';

String _today() {
  final n = DateTime.now();
  return '${n.day}/${n.month}/${n.year}';
}

class AttendanceRepositoryImpl implements AttendanceRepository {
  final AttendanceLocalDataSource  _ds;
  final StudentLocalDataSource     _studentDs;
  final AchievementLocalDataSource _achievementDs;

  AttendanceRepositoryImpl(this._ds, this._studentDs, this._achievementDs);

  @override
  Future<void> addRecord(AttendanceRecord r) async {
    await _ds.insertRecord(r);
    // Stage 6C: invalidate cache so next read is fresh
    if (r.studentId != null) {
      AttendanceCache.instance.invalidate(r.studentId!);
    }
  }

  @override
  Future<List<AttendanceRecord>> getByStudent(int studentId) =>
      _ds.getByStudent(studentId);

  @override
  Future<double> getAttendancePercentage(int studentId) async {
    final records = await _ds.getByStudent(studentId);
    if (records.isEmpty) return 0;
    return records.where((r) => r.present).length / records.length * 100;
  }

  /// Stage 1C — QR scan attendance mark.
  /// Duplicate check: group-specific when groupName provided, else student-wide.
  @override
  Future<Map<String, dynamic>> markByQR(
      int studentId, String groupName, double price) async {
    final student = await _studentDs.getById(studentId);
    if (student == null) {
      return {'success': false, 'message': 'الطالب غير موجود'};
    }

    final today = _today();

    final bool alreadyMarked;
    if (groupName.isNotEmpty) {
      alreadyMarked =
          await _ds.recordExistsToday(studentId, groupName, today);
    } else {
      alreadyMarked =
          await _ds.recordExistsTodayForStudent(studentId, today);
    }

    if (alreadyMarked) {
      return {
        'success': false,
        'message': 'تم تسجيل ${student.name} اليوم مسبقاً',
        'student': student,
      };
    }

    await _ds.insertRecord(AttendanceRecord(
      studentId:   student.id!,
      studentName: student.name,
      groupName:   groupName,
      date:        today,
      present:     true,
    ));

    final updated = student.copyWith(
      balance: student.balance - price,
      xp:      student.xp + 10,
    );
    await _studentDs.update(updated);
    await _checkAchievements(updated);

    // Stage 6C: invalidate cache after successful mark
    AttendanceCache.instance.invalidate(studentId);

    return {
      'success': true,
      'message': 'أهلاً ${student.name}! ✅',
      'student': updated,
    };
  }

  Future<void> _checkAchievements(Student s) async {
    final today   = _today();
    final records = await _ds.getByStudent(s.id!);

    Future<void> grant(String id) async {
      final has = await _achievementDs.hasAchievement(s.id!, id);
      if (!has) await _achievementDs.grant(s.id!, id, today);
    }

    if (s.xp >= 50)  await grant('xp_50');
    if (s.xp >= 200) await grant('xp_200');
    if (s.xp >= 500) await grant('xp_500');
    if (s.balance >= 0) await grant('regular_payment');
    if (records.length >= 10 &&
        records.take(10).every((r) => r.present)) {
      await grant('attend_10');
    }
  }
}
