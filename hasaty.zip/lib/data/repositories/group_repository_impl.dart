// lib/data/repositories/group_repository_impl.dart
import '../../domain/entities/group.dart';
import '../../domain/repositories/group_repository.dart';
import '../datasources/group_local_datasource.dart';

class GroupRepositoryImpl implements GroupRepository {
  final GroupLocalDataSource _ds;
  GroupRepositoryImpl(this._ds);

  @override Future<List<Group>> getAll()            => _ds.getAll();
  @override Future<int>         addGroup(Group g)   => _ds.insert(g);
  @override Future<void>        updateGroup(Group g) => _ds.update(g);
  @override Future<int>         deleteGroup(int id)  => _ds.delete(id);
}
