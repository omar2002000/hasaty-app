// lib/data/repositories/audit_log_repository_impl.dart
// Stage 8 — Thin repository: passes calls to datasource.
import '../../domain/entities/audit_log.dart';
import '../datasources/audit_log_datasource.dart';

class AuditLogRepository {
  final AuditLogLocalDataSource _ds;
  AuditLogRepository(this._ds);

  Future<void> log(AuditLog entry) async {
    await _ds.insert(entry);
    // Housekeeping: trim old entries silently (fire-and-forget)
    _ds.clearOlderThan(90);
  }

  Future<List<AuditLog>> getAll({int limit = 200}) =>
      _ds.getAll(limit: limit);

  Future<List<AuditLog>> getByStudent(int studentId) =>
      _ds.getByStudent(studentId);
}
