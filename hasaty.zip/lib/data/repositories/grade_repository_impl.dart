// lib/data/repositories/grade_repository_impl.dart
import '../../domain/entities/academic_grade.dart';
import '../../domain/repositories/grade_repository.dart';
import '../datasources/grade_local_datasource.dart';

class GradeRepositoryImpl implements GradeRepository {
  final GradeLocalDataSource _ds;
  GradeRepositoryImpl(this._ds);

  @override Future<int>                    addGrade(AcademicGrade g) => _ds.insert(g);
  @override Future<List<AcademicGrade>>    getAllGrades()             => _ds.getAll();
  @override Future<List<AcademicGrade>>    getStudentGrades(int sid)  => _ds.getByStudent(sid);

  @override
  Future<Map<String, dynamic>> getGradeSummary(int sid) async {
    final grades = await _ds.getByStudent(sid);
    if (grades.isEmpty) return {'total': 0, 'excellent': 0, 'weak': 0, 'average': 0.0};
    final total = grades.fold<double>(0.0, (s, g) => s + g.score);
    return {
      'total':     grades.length,
      'excellent': grades.where((g) => g.grade == 'excellent').length,
      'weak':      grades.where((g) => g.grade == 'weak').length,
      'average':   total / grades.length,
    };
  }
}
