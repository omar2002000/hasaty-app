// lib/data/repositories/coin_repository_impl.dart
import '../../domain/repositories/coin_repository.dart';
import '../datasources/coin_local_datasource.dart';

String _today() { final n = DateTime.now(); return '${n.day}/${n.month}/${n.year}'; }

class CoinRepositoryImpl implements CoinRepository {
  final CoinLocalDataSource _ds;
  CoinRepositoryImpl(this._ds);

  @override Future<void> awardCoins(int id, String name, int amt, String r) => _ds.award(id, name, amt, r, _today());
  @override Future<void> spendCoins(int id, String name, int amt, String r) => _ds.spend(id, name, amt, r, _today());
  @override Future<int>  getStudentCoins(int id)                            => _ds.getCoins(id);
}
