// lib/data/services/backup_service.dart
import 'dart:io';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:share_plus/share_plus.dart';
import 'package:file_picker/file_picker.dart';
import '../database/app_database.dart';

class BackupService {
  static final BackupService instance = BackupService._();
  BackupService._();

  Future<bool> exportDatabase() async {
    try {
      final dbPath = await getDatabasesPath();
      final path   = join(dbPath, 'hasaty_v4.db');
      if (await File(path).exists()) {
        await Share.shareXFiles(
          [XFile(path)],
          text: 'نسخة احتياطية — تطبيق حصتي v4.0',
        );
        return true;
      }
      return false;
    } catch (_) {
      return false;
    }
  }

  Future<bool> importDatabase() async {
    try {
      final result = await FilePicker.platform.pickFiles(type: FileType.any);
      if (result != null && result.files.single.path != null) {
        final dbPath = await getDatabasesPath();
        final path   = join(dbPath, 'hasaty_v4.db');
        await AppDatabase.instance.close();
        await File(result.files.single.path!).copy(path);
        return true;
      }
      return false;
    } catch (_) {
      return false;
    }
  }
}
