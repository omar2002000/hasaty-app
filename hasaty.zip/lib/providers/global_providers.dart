// lib/providers/global_providers.dart
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../data/datasources/student_local_datasource.dart';
import '../data/datasources/finance_local_datasource.dart';
import '../data/datasources/attendance_local_datasource.dart';
import '../data/datasources/group_local_datasource.dart';
import '../data/datasources/grade_local_datasource.dart';
import '../data/datasources/notification_local_datasource.dart';
import '../data/datasources/achievement_local_datasource.dart';
import '../data/datasources/coin_local_datasource.dart';

import '../data/repositories/student_repository_impl.dart';
import '../data/repositories/finance_repository_impl.dart';
import '../data/repositories/attendance_repository_impl.dart';
import '../data/repositories/group_repository_impl.dart';
import '../data/repositories/grade_repository_impl.dart';
import '../data/repositories/notification_repository_impl.dart';
import '../data/repositories/achievement_repository_impl.dart';
import '../data/repositories/coin_repository_impl.dart';

import '../domain/repositories/student_repository.dart';
import '../domain/repositories/finance_repository.dart';
import '../domain/repositories/attendance_repository.dart';
import '../domain/repositories/group_repository.dart';
import '../domain/repositories/grade_repository.dart';
import '../domain/repositories/notification_repository.dart';
import '../domain/repositories/achievement_repository.dart';
import '../domain/repositories/coin_repository.dart';
import '../data/datasources/audit_log_datasource.dart'; // Stage 8
import '../data/repositories/audit_log_repository_impl.dart'; // Stage 8

// ── DataSources ──────────────────────────────────────────────
final studentDsProvider      = Provider<StudentLocalDataSource>  ((_) => StudentLocalDataSourceImpl());
final financeDsProvider      = Provider<FinanceLocalDataSource>  ((_) => FinanceLocalDataSourceImpl());
final attendanceDsProvider   = Provider<AttendanceLocalDataSource>((_) => AttendanceLocalDataSourceImpl());
final groupDsProvider        = Provider<GroupLocalDataSource>    ((_) => GroupLocalDataSourceImpl());
final gradeDsProvider        = Provider<GradeLocalDataSource>    ((_) => GradeLocalDataSourceImpl());
final notificationDsProvider = Provider<NotificationLocalDataSource>((_) => NotificationLocalDataSourceImpl());
final achievementDsProvider  = Provider<AchievementLocalDataSource>((_) => AchievementLocalDataSourceImpl());
final coinDsProvider         = Provider<CoinLocalDataSource>    ((_) => CoinLocalDataSourceImpl());

// ── Repositories ─────────────────────────────────────────────
final studentRepositoryProvider = Provider<StudentRepository>((ref) =>
    StudentRepositoryImpl(ref.read(studentDsProvider)));

final financeRepositoryProvider = Provider<FinanceRepository>((ref) =>
    FinanceRepositoryImpl(ref.read(financeDsProvider),
        ref.read(studentDsProvider), ref.read(groupDsProvider)));

final financeRepoImplProvider = Provider<FinanceRepositoryImpl>((ref) =>
    FinanceRepositoryImpl(ref.read(financeDsProvider),
        ref.read(studentDsProvider), ref.read(groupDsProvider)));

final attendanceRepositoryProvider = Provider<AttendanceRepository>((ref) =>
    AttendanceRepositoryImpl(ref.read(attendanceDsProvider),
        ref.read(studentDsProvider), ref.read(achievementDsProvider)));

final groupRepositoryProvider = Provider<GroupRepository>((ref) =>
    GroupRepositoryImpl(ref.read(groupDsProvider)));

final gradeRepositoryProvider = Provider<GradeRepository>((ref) =>
    GradeRepositoryImpl(ref.read(gradeDsProvider)));

final notificationRepositoryProvider = Provider<NotificationRepository>((ref) =>
    NotificationRepositoryImpl(ref.read(notificationDsProvider),
        ref.read(studentDsProvider), ref.read(attendanceDsProvider),
        ref.read(financeDsProvider))); // Stage 3C: payment due reminders

final achievementRepositoryProvider = Provider<AchievementRepository>((ref) =>
    AchievementRepositoryImpl(ref.read(achievementDsProvider),
        ref.read(studentDsProvider), ref.read(attendanceDsProvider),
        ref.read(financeDsProvider)));

final coinRepositoryProvider = Provider<CoinRepository>((ref) =>
    CoinRepositoryImpl(ref.read(coinDsProvider)));

// ── Stage 8: Audit Log ────────────────────────────────────────
final auditLogDsProvider = Provider<AuditLogLocalDataSource>(
    (_) => AuditLogLocalDataSourceImpl());

final auditLogRepositoryProvider = Provider<AuditLogRepository>(
    (ref) => AuditLogRepository(ref.read(auditLogDsProvider)));
